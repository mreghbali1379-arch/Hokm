package com.example.hokm

import com.example.hokm.Cards.SN
import com.example.hokm.Cards.cname
import com.example.hokm.Cards.fa
import com.example.hokm.Cards.lab
import com.example.hokm.Cards.shuf
import com.example.hokm.Cards.sortH
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONArray
import org.json.JSONObject

/**
 * The flow of the four-player game against the bots: dealing, trump choice, turns, tricks, end of hand.
 * Ported from newHand / setTrump / next / botPlay / play / endHand / read* of the page. The screen is
 * reached through [Ui4]; the rules and the bots' brain are in [Engine4].
 */
interface Ui4 {
    fun render()
    fun say(t: String)
    fun logNow(t: String)
    fun clearLog()
    fun clearCtl()
    fun showPick()
    fun renderHandOnly()
    fun focusFirst(what: String)
    fun showNewGameButton(text: String)
    fun keepMsg(on: Boolean)
}

class Flow4(private val ui: Ui4) {
    val e = Engine4()

    // names around the table: 0 you, 1 left opponent, 2 partner, 3 right opponent
    val NM = arrayOf("شما", "حریف ۱", "یار", "حریف ۲")

    var phase = ""
    var busy = false
    var waiting = false
    var winSeat = -1
    var lastTrick: List<TC> = ArrayList()
    var shown: List<TC> = ArrayList()

    private fun A11Y() = Prefs.a11y

    /** end of the current announcement queue (SPKQ.end) */
    fun spkEnd(): Long = Spk.end
    fun resetSpk() { Spk.reset() }

    private fun spkSlot(t: String, min: Long): Long = Spk.slot(t, min)

    fun log(t: String, min: Long = 0) {
        val d = spkSlot(t, min)
        if (d > 0) Sched.later(d) { ui.logNow(t) } else ui.logNow(t)
    }

    // ---- multi-phone (host side): publishing to the remote players ----
    private fun isHost4() = MP.role == "host" && MP.mode == 4
    private fun srt(h: List<Card>) = h.sortedWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }
    private fun cjs(c: Card) = JSONObject().put("s", c.s).put("r", c.r)

    /** show f(0) here and send f(seat) to every remote player (skip = the seat that must not get it; 0 = not even here) */
    fun pub(f: (Int) -> String, clr: Boolean = false, min: Long = 0, skip: Int = -1, tag: String = "") {
        if (skip != 0) log(f(0), min)
        if (isHost4()) MP.each { cid, c -> if (c.seat != skip) MP.send(cid, JSONObject().put("t", "log").put("x", f(c.seat!!)).put("clr", clr).put("w", tag)) }
    }

    fun pubR(f: (Int) -> String, clr: Boolean = false, tag: String = "") {
        if (isHost4()) MP.each { cid, c -> MP.send(cid, JSONObject().put("t", "log").put("x", f(c.seat!!)).put("clr", clr).put("w", tag)) }
    }

    private fun mpHands4() {
        if (isHost4()) MP.each { cid, c -> MP.send(cid, JSONObject().put("t", "log").put("x", "کارت‌های شما: " + Cards.handText(e.H[c.seat!!]) + ".").put("w", "deal")) }
    }

    private fun mpNames4() {
        if (!isHost4()) return
        for (c in MP.cl.values) { val s0 = c.seat; if (s0 != null) NM[s0] = c.name + (if (s0 == 2) " (یار)" else "") }
    }

    private fun mpShuf() {
        if (MP.role == "host" && MP.mode == 4) MP.each { cid, _ -> MP.send(cid, JSONObject().put("t", "shf")) }
    }

    private fun sendDraw4(D: Draw.D) {
        if (!isHost4()) return
        try {
            MP.each { cid, c ->
                val s = c.seat!!
                val rl = { p: Int -> (p - s + 4) % 4 }
                val o = JSONObject().put("t", "drw").put("n", 4).put("f", Anim.f)
                o.put("seq", JSONArray().also { a -> D.seq.forEach { a.put(JSONObject().put("p", rl(it.p)).put("c", cjs(it.c))) } })
                o.put("h", rl(D.h)).put("pt", if (D.pt == null) JSONObject.NULL else rl(D.pt)).put("i1", D.i1).put("i2", D.i2)
                o.put("mv", JSONArray().also { a -> for (r in 0 until 4) a.put((D.mv[(s + r) % 4] - D.mv[s] + 4) % 4) })
                o.put("nm", JSONArray().also { a -> for (r in 0 until 4) a.put(who((s + r) % 4, s)) })
                MP.send(cid, o)
            }
        } catch (ex: Exception) { }
    }

    /** the full state for each remote player, sent after every redraw (mpSnap4) */
    fun mpSnap4() {
        if (!isHost4() || phase == "") return
        val dt = if (e.trick.isNotEmpty()) e.trick else shown
        MP.each { cid, c ->
            val s = c.seat!!
            val o = JSONObject().put("t", "st")
            o.put("status", "حکم: " + (if (e.trump < 0) "—" else Cards.SU[e.trump] + " " + SN[e.trump]) + " | حاکم: " + who(e.hakem, s) +
                " | دست‌ها: تیم شما " + e.tk[s % 2] + " حریف " + e.tk[1 - s % 2] + " | امتیاز: تیم شما " + e.sc[s % 2] + " حریف " + e.sc[1 - s % 2] + "")
            o.put("table", JSONArray().also { a -> dt.forEach { a.put(JSONObject().put("n", who(it.seat, s)).put("c", cjs(it.c)).put("r", (it.seat - s + 4) % 4)) } })
            val hideHand = phase == "pick" && s != e.hakem
            o.put("hand", JSONArray().also { a -> if (!hideHand) srt(e.H[s]).forEach { a.put(cjs(it)) } })
            o.put("bk", if (hideHand) e.H[s].size else 0)
            o.put("tr", if (e.trump < 0) JSONObject.NULL else e.trump)
            o.put("hkn", who(e.hakem, s))
            o.put("tk", JSONArray().put(e.tk[s % 2]).put(e.tk[1 - s % 2]))
            o.put("hr", (e.hakem - s + 4) % 4)
            o.put("tn", (e.turn - s + 4) % 4)
            val showWin = e.trick.isEmpty() && shown.isNotEmpty() && winSeat >= 0
            o.put("wr", if (showWin) (winSeat - s + 4) % 4 else JSONObject.NULL)
            o.put("fan", JSONArray().also { a -> for (r in 1..3) a.put(JSONObject().put("r", r).put("n", e.H[(s + r) % 4].size).put("t", who((s + r) % 4, s))) })
            o.put("win", if (showWin) who(winSeat, s) else JSONObject.NULL)
            o.put("sc", JSONArray().put(e.sc[s % 2]).put(e.sc[1 - s % 2]))
            o.put("ph", phase)
            o.put("wm", winSeat >= 0 && winSeat % 2 == s % 2)
            MP.send(cid, o)
        }
    }

    fun mpOver() { if (MP.role == "host") MP.each { cid, _ -> MP.send(cid, JSONObject().put("t", "over")) } }

    fun who(s: Int, p: Int): String {
        val b = if (s == 0 && MP.role == "host") MP.hostName else NM[s].replace(" (یار)", "")
        return if (s == p) "شما" else if ((s + 2) % 4 == p) "$b (یار)" else b
    }

    // ---- reading the state aloud (screen-reader buttons) ----
    private fun handText(): String = Cards.handText(e.H[0])
    fun readHand() = ui.logNow("کارت‌های شما: " + handText() + ".")
    fun readTrump() {
        ui.logNow(if (e.trump < 0) "حکم هنوز انتخاب نشده. " else "حکم: " + SN[e.trump] + ". ")
        ui.logNow("حاکم: " + NM[e.hakem] + ".")
    }
    fun readTable() {
        val dt = if (e.trick.isNotEmpty()) e.trick else shown
        ui.logNow(if (dt.isNotEmpty()) "روی زمین: " + dt.joinToString("، ") { NM[it.seat] + " " + cname(it.c) } + "." else "روی زمین کارتی نیست.")
    }
    fun readLed() = ui.logNow(if (e.trick.isNotEmpty()) "خال زمین: " + SN[e.trick[0].c.s] + "." else "کسی هنوز کارتی نیاورده، هر خالی می‌توانید بیاورید.")
    fun readLegal() {
        if (phase == "play" && e.turn == 0 && !waiting) {
            val L = e.legal(0).sortedWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }
            ui.logNow("کارت‌های مجاز شما: " + L.joinToString("، ") { cname(it) } + ".")
        } else ui.logNow("الان نوبت شما نیست.")
    }
    fun readTurn() = ui.logNow(if (phase != "play") "بازی در حال انجام نیست." else if (e.turn == 0) "نوبت شماست." else "نوبت " + NM[e.turn] + " است.")
    fun readTricks() = ui.logNow("دست‌های این دور: تیم شما " + e.tk[0] + "، حریف " + e.tk[1] + ".")
    fun readScore() = ui.logNow("امتیاز بازی: تیم شما " + e.sc[0] + "، حریف " + e.sc[1] + ". هر تیم زودتر به ۷ برسد برنده است.")
    fun readAll() { readTrump(); readTricks(); readScore(); readTable(); readHand(); readTurn() }
    fun showLast() {
        if (lastTrick.isEmpty()) { ui.logNow("هنوز دستی بازی نشده."); return }
        ui.logNow("دست قبل: " + lastTrick.joinToString("، ") { NM[it.seat] + " " + cname(it.c) } + ". برنده: " + NM[winSeat] + ".")
    }

    // ---- start of a game ----
    /** start4: choose the first hakem (first ace), pick bot names and begin the first hand */
    fun start4() {
        busy = false
        ui.keepMsg(false)
        val D4 = Draw.genDraw(4, !(MP.role == "host" && !MP.pdraw))
        e.hakem = D4.h
        val r = Names.pickNames(3)
        NM[1] = r[0]; NM[2] = r[1] + " (یار)"; NM[3] = r[2]
        mpNames4()
        e.sc = intArrayOf(0, 0)
        val g4 = Sched.GEN
        sendDraw4(D4)
        Fx.drawScene(D4, listOf(0, 1, 2, 3).map { who(it, 0) }, {
            if (g4 == Sched.GEN) { applyReseat4(D4.mv); newHand() }
        }, null) { t, q -> ui.say(t); if (!q) ui.logNow(t) }
    }

    private fun applyReseat4(to: IntArray?) {
        if (to == null) return
        var same = true
        for (o in 0 until 4) if (to[o] != o) same = false
        if (same) return
        val nm = NM.copyOf(); val rem = MP.rem.copyOf()
        for (o in 0 until 4) { NM[to[o]] = nm[o].replace(" (یار)", ""); MP.rem[to[o]] = rem[o] }
        NM[2] = NM[2].replace(" (یار)", "") + " (یار)"
        if (MP.role == "host") for ((k, c) in MP.cl) {
            val s0 = c.seat
            if (s0 != null) { c.seat = to[s0]; MP.send(k, JSONObject().put("t", "seat").put("seat", c.seat)) }
        }
        e.hakem = to[e.hakem]
    }

    private var nxtT: Runnable? = null

    fun newHand() {
        if (Hold.hold("newHand", "[]") { newHand() }) return
        val g = Sched.GEN
        Fx.shufThen({
            Sound.psnd("shuffle", true) {
                if (e.sc[0] + e.sc[1] != 0) pub({ p -> "دور جدید. حاکم: " + who(e.hakem, p) + "." }, true, 0, -1, "snd")
                mpShuf()
            }
        }) {
            if (g == Sched.GEN) { Fx.hn++; Fx.deal4 = true; Fx.first5 = null; dealHand() }
        }
    }

    private fun dealHand() {
        ui.clearLog()
        e.deck = ArrayList()
        for (s in 0 until 4) for (r in 2..14) e.deck.add(Card(s, r))
        shuf(e.deck)
        e.H = Array(4) { ArrayList<Card>() }
        e.trump = -1; e.trick = ArrayList(); e.tk = intArrayOf(0, 0); e.kt = -1
        e.seen = HashSet(); e.voids = Array(4) { HashSet<Int>() }
        winSeat = -1; lastTrick = ArrayList(); shown = ArrayList(); e.plays = ArrayList(); waiting = false
        ui.clearCtl()
        for (i in 0 until 4) for (k in 0 until 5) e.H[i].add(e.deck.removeAt(e.deck.size - 1))
        phase = "pick"; ui.render(); ui.clearLog()
        if (e.hakem == 0) {
            ui.showPick()
            ui.say("")
            log("شما حاکم هستید. پنج کارت اول شما: " + handText() + ". حکم را انتخاب کنید.")
            ui.focusFirst(".pick button")
        } else if (MP.rem[e.hakem] && MP.cidOf(e.hakem) != null) {
            remPick(e.hakem)
        } else {
            ui.say(NM[e.hakem] + " حاکم است و حکم را انتخاب می‌کند...")
            Sched.later(1200) {
                if (phase == "pick" && e.trump < 0) setTrump(e.chooseTrump(e.hakem))
            }
        }
    }

    fun setTrump(s: Int) {
        if (Hold.hold("setTrump", "[$s]", e.hakem == 0) { setTrump(s) }) return
        run {
            val w = Deal.wait()
            if (phase == "pick" && e.trump < 0 && w > 0) {
                if (Deal.stq) return
                Deal.stq = true
                val g = Sched.GEN
                Sched.laterRaw(w) { Deal.stq = false; if (g == Sched.GEN && phase == "pick" && e.trump < 0) setTrump(s) }
                return
            }
        }
        e.trump = s
        for (i in 0 until 4) while (e.H[i].size < 13) e.H[i].add(e.deck.removeAt(e.deck.size - 1))
        e.H.forEach { sortH(it) }
        phase = "play"; e.turn = e.hakem; e.trick = ArrayList(); ui.render()
        pub({ p -> "حکم: " + SN[s] + (if (e.hakem == p) "." else " (انتخاب " + who(e.hakem, p) + ").") }, false, 0, -1, "deal")
        log("کارت‌های شما: " + handText() + ".")
        mpHands4()
        next()
    }

    // ---- turns ----
    fun next() {
        if (Hold.hold("next", "[]") { next() }) return
        run {
            val w = Deal.wait()
            if (phase == "play" && w > 0) {
                Sched.cancel(nxtT)
                nxtT = Sched.later(w) { next() }
                return
            }
        }
        ui.render(); MP.onSync?.invoke()
        if (phase != "play") return
        if (e.turn == 0) {
            val pr = {
                ui.say("نوبت شماست.")
                log("نوبت شماست. " + (if (e.trick.isNotEmpty()) "خال زمین: " + SN[e.trick[0].c.s] + "." else "شما شروع می‌کنید."))
                ui.focusFirst("#hand button.ok")
            }
            val wd = Math.max(Sound.TBU, Spk.end) - Sched.now()
            if (wd > 0) {
                val g = Sched.GEN
                busy = true
                Sched.later(wd + Anim.ad(150)) {
                    busy = false
                    if (g == Sched.GEN && phase == "play" && e.turn == 0) pr()
                }
            } else pr()
            return
        }
        if (MP.rem[e.turn] && MP.cidOf(e.turn) != null) {
            val s0 = e.turn; val L0 = e.legal(s0)
            ui.say("")
            val g_ = Sched.GEN
            val go_ = {
                if (g_ == Sched.GEN && phase == "play" && e.turn == s0) {
                    if (MP.cidOf(s0) == null) next()
                    else MP.gate {
                        MP.ask(s0, "play", JSONObject().put("cards", JSONArray().also { a -> L0.forEach { a.put(cjs(it)) } })
                            .put("led", if (e.trick.isNotEmpty()) e.trick[0].c.s else -1)) { v ->
                            val o = v as? JSONObject
                            val c = if (o == null) null else L0.firstOrNull { it.s == o.optInt("s", -9) && it.r == o.optInt("r", -9) }
                            if (c != null && e.turn == s0 && phase == "play") play(s0, c)
                            else if (phase == "play" && e.turn == s0) next()
                        }
                    }
                }
            }
            val wd = Math.max(Sound.TBU, Spk.end) - Sched.now()
            if (wd > 0) Sched.later(wd + Anim.ad(150)) { go_() } else go_()
            return
        }
        ui.say("")
        busy = true
        val d = Math.max(
            if (shown.isNotEmpty()) 1000L else 600L,
            Math.max(Sound.TBU - Sched.now() + Anim.ad(250), Spk.end - Sched.now() + Anim.ad(100))
        )
        Sched.later(d) { MP.gate { busy = false; botPlay(e.turn) } }
    }

    private fun botPlay(s: Int) {
        if (Hold.hold("botPlay", "[$s]") { botPlay(s) }) return
        if (MP.rem[s] && MP.cidOf(s) != null && e.turn == s) { next(); return }
        val pick = e.botMove(s)
        play(s, pick!!)
    }

    /** a player (you or a bot) plays card c */
    fun play(s: Int, c: Card) {
        if (Hold.hold("play", "[$s,${c.s},${c.r}]", s == 0) { play(s, c) }) return
        if (s == 0 && Deal.wait() > 0) return
        shown = ArrayList()
        val clr = e.trick.isEmpty()
        if (clr) ui.clearLog()
        pub({ p -> who(s, p) + " " + cname(c) + (if (s == p) " بازی کردید" else " بازی کرد") + (if (c.s == e.trump) " (حکم)." else ".") },
            clr, Math.max(0L, Anim.ad(360) - Sound.CSO.toLong()), s, "card")
        Sched.later(Math.max(0, Anim.ad(340) - Sound.CSO)) { Sound.cardSnd() }
        run {
            val bb = if (e.trick.isNotEmpty()) e.bestOf(e.trick) else null
            e.plays.add(Play(s, c, e.trick.size, if (e.trick.isNotEmpty()) e.trick[0].c.s else -1, bb?.seat ?: -1, bb?.c))
        }
        if (e.trick.isNotEmpty() && c.s != e.trick[0].c.s) e.voids[s].add(e.trick[0].c.s)
        e.seen.add(c.s * 20 + c.r)
        e.H[s] = ArrayList(e.H[s].filter { it !== c })
        e.trick.add(TC(s, c))
        ui.render()
        if (e.trick.size < 4) { e.turn = (s + 1) % 4; next(); return }
        val w = e.bestOf(e.trick).seat
        e.tk[w % 2]++; winSeat = w; lastTrick = ArrayList(e.trick); shown = ArrayList(e.trick); e.trick = ArrayList(); e.turn = w
        ui.render()
        run {
            val hs = if (e.tk[0] >= 7) 0 else if (e.tk[1] >= 7) 1 else -1
            if (hs >= 0) {
                if (e.tk[1 - hs] == 0 && e.kt < 0) e.kt = hs
                if (e.tk[1 - hs] > 0 || e.tk[hs] == 13) { endHand(); return }
            }
        }
        Sound.TBU = Sched.now() + Anim.ad(1000) + (if (Sound.on) (if (w % 2 == 0) Sound.EST["trick"]!! else Sound.EST["tlose"]!!).toLong() else Anim.ad(400).toLong())
        Sched.later(Anim.ad(1000)) { Sound.psnd(if (w % 2 == 0) "trick" else "tlose", true) }
        ui.render()
        val wf = { p: Int -> who(w, p) + (if (w == p) " دست را بردید. تیم شما " else " دست را برد. تیم شما ") + e.tk[p % 2] + "، حریف " + e.tk[1 - p % 2] + "." }
        val wmin = Anim.ad(1000)
        Sched.later(wmin) { ui.say(wf(0)) }
        pub(wf, false, wmin.toLong(), -1, "snd")
        next()
    }

    private fun endHand() {
        val t = if (e.tk[0] >= 7) 0 else 1
        val hk = e.hakem % 2
        val bam = e.tk[t] == 13
        val bn = if (t == hk) "بام" else "پر بام"
        val kot = bam || e.kt == t
        val pts = if (kot) (if (t == hk) 2 else 3) else 1
        e.sc[t] += pts
        if (bam) e.sc[t] = Math.max(e.sc[t], 7)
        phase = "end"; ui.render()
        val gm = e.sc[t] >= 7
        val mf = { p: Int ->
            if (bam) (if (t == p % 2) "تیم شما $bn کرد و بازی را برد!" else "تیم حریف $bn کرد و بازی را برد.")
            else if (gm) (if (t == p % 2) "تیم شما بازی را برد!" else "تیم حریف بازی را برد.")
            else ((if (t == p % 2) "تیم شما" else "تیم حریف") + " این دست را برد" +
                (if (kot) (if (t == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)") else " (۱ امتیاز)") + ". ")
        }
        if (t != hk) e.hakem = (e.hakem + 1) % 4
        MP.onSync?.invoke()
        pubR(mf, false, "snd")
        if (gm) {
            mpOver()
            Sound.endSnd(t, kot, gm) { log(mf(0)) }
            Sound.afterSnd {
                ui.keepMsg(true)
                ui.showNewGameButton(if (Prefs.a11y) mf(0) else "")
                ui.focusFirst("#msg button")
            }
        } else {
            Sound.endSnd(t, kot, gm) { ui.say(mf(0)); log(mf(0)) }
            Sched.later(if (Sound.on) 4600 else 3300) { newHand() }
        }
    }

    /** ask the remote hakem for the trump (remPick) */
    private fun remPick(h0: Int) {
        ui.say(NM[h0] + " حاکم است و حکم را انتخاب می‌کند...")
        MP.ask(h0, "trump", JSONObject().put("hand", JSONArray().also { a -> srt(e.H[h0]).forEach { a.put(cjs(it)) } })) { v ->
            if (phase == "pick" && e.trump < 0) {
                val t = (v as? Int) ?: -1
                setTrump(if (t in 0..3) t else e.chooseTrump(h0))
            }
        }
    }

    /** a player came back (or was added): he takes his seat again (seatIn of the page, four-player case) */
    fun seatIn4(cid: Int, seat: Int, nm: String, t: String) {
        MP.rem[seat] = true
        NM[seat] = nm + (if (seat == 2) " (یار)" else "")
        MP.each { id, _ -> MP.send(id, JSONObject().put("t", "log").put("x", t)) }
        log(t); ui.render()
        MP.send(cid, JSONObject().put("t", "log").put("x", "کارت‌های شما: " + handText(e.H[seat]) + "."))
        if (phase == "pick" && e.trump < 0 && e.hakem == seat) remPick(seat)
        else if (phase == "play" && e.turn == seat && !busy) next()
    }

    /** a remote player left (or was removed): a bot takes the seat (mpDrop of the page, four-player case) */
    fun remDrop(c: Peer, hadAsk: Boolean, kick: Boolean) {
        val s0 = c.seat ?: return
        MP.rem[s0] = false
        NM[s0] = NM[s0].replace(" (یار)", "") + " (ربات)" + (if (s0 == 2) " (یار)" else "")
        val t = c.name + (if (kick) " از بازی حذف شد و ربات جای او بازی می‌کند." else " قطع شد و ربات تا اتصال دوباره جای او بازی می‌کند.")
        log(t)
        MP.each { id, _ -> MP.send(id, JSONObject().put("t", "log").put("x", t)) }
        if (phase == "pick" && e.trump < 0 && e.hakem == s0) setTrump(e.chooseTrump(s0))
        else if (phase == "play" && e.turn == s0 && hadAsk) next()
    }

    /** you chose card c from your hand */
    fun humanPlay(c: Card) {
        if (e.turn == 0 && !busy && !waiting && phase == "play") play(0, c)
    }

    // ---------------------------------------------------------------- save / resume (soloSnap / resumeSolo)

    private fun cj(c: Card) = JSONObject().put("s", c.s).put("r", c.r)
    private fun cl(l: List<Card>): JSONArray { val a = JSONArray(); for (c in l) a.put(cj(c)); return a }
    private fun tcl(l: List<TC>): JSONArray {
        val a = JSONArray(); for (t in l) a.put(JSONObject().put("seat", t.seat).put("c", cj(t.c))); return a
    }
    private fun jc(o: JSONObject) = Card(o.getInt("s"), o.getInt("r"))
    private fun jtcl(a: JSONArray?): MutableList<TC> {
        val l = ArrayList<TC>()
        if (a != null) for (i in 0 until a.length()) { val o = a.getJSONObject(i); l.add(TC(o.getInt("seat"), jc(o.getJSONObject("c")))) }
        return l
    }

    /** the state of the game as saved data (null when there is nothing to save) */
    fun snap(): JSONObject? {
        if (phase.isEmpty()) return null
        val o = JSONObject()
        o.put("m", 4)
        val h = JSONArray(); for (x in e.H) h.put(cl(x)); o.put("H", h)
        o.put("trump", if (e.trump < 0) JSONObject.NULL else e.trump)
        o.put("hakem", e.hakem); o.put("turn", e.turn)
        o.put("trick", tcl(e.trick))
        o.put("tk", JSONArray().put(e.tk[0]).put(e.tk[1]))
        o.put("sc", JSONArray().put(e.sc[0]).put(e.sc[1]))
        o.put("phase", phase)
        o.put("seen", JSONArray(e.seen.toList()))
        val v = JSONArray(); for (x in e.voids) v.put(JSONArray(x.toList())); o.put("voids", v)
        o.put("lastTrick", tcl(lastTrick)); o.put("shown", tcl(shown))
        val pl = JSONArray()
        for (p in e.plays) pl.put(JSONObject().put("seat", p.seat).put("c", cj(p.c)).put("len", p.len).put("led", p.led)
            .put("bs", p.bs).put("bc", if (p.bc == null) JSONObject.NULL else cj(p.bc)))
        o.put("plays", pl)
        o.put("kt", if (e.kt < 0) JSONObject.NULL else e.kt)
        o.put("winSeat", winSeat)
        val nm = JSONArray(); for (n in NM) nm.put(n); o.put("NM", nm)
        return o
    }

    /** puts a saved game back (does not draw or start anything: the caller continues according to [phase]) */
    fun restore(x: JSONObject, hum: List<String?>? = null) {
        val hs = x.getJSONArray("H")
        e.H = Array(4) { i ->
            val a = hs.getJSONArray(i); val l = ArrayList<Card>()
            for (k in 0 until a.length()) l.add(jc(a.getJSONObject(k)))
            l
        }
        e.trump = if (x.isNull("trump")) -1 else x.getInt("trump")
        e.hakem = x.getInt("hakem"); e.turn = x.getInt("turn")
        e.trick = jtcl(x.optJSONArray("trick"))
        lastTrick = jtcl(x.optJSONArray("lastTrick")); shown = jtcl(x.optJSONArray("shown"))
        val pl = ArrayList<Play>()
        val pa = x.optJSONArray("plays")
        if (pa != null) for (i in 0 until pa.length()) {
            val o = pa.getJSONObject(i)
            pl.add(Play(o.getInt("seat"), jc(o.getJSONObject("c")), o.getInt("len"), o.getInt("led"), o.getInt("bs"),
                if (o.isNull("bc")) null else jc(o.getJSONObject("bc"))))
        }
        e.plays = pl
        val ws = x.optInt("winSeat", -1); winSeat = if (ws >= 0) ws else -1
        val tk = x.getJSONArray("tk"); e.tk = intArrayOf(tk.getInt(0), tk.getInt(1))
        val sc = x.getJSONArray("sc"); e.sc = intArrayOf(sc.getInt(0), sc.getInt(1))
        e.kt = if (x.isNull("kt")) -1 else x.getInt("kt")
        val sn = x.getJSONArray("seen"); val seen = HashSet<Int>(); for (i in 0 until sn.length()) seen.add(sn.getInt(i)); e.seen = seen
        val vs = x.getJSONArray("voids")
        e.voids = Array(4) { i ->
            val a = vs.getJSONArray(i); val st = HashSet<Int>(); for (k in 0 until a.length()) st.add(a.getInt(k)); st
        }
        phase = x.getString("phase"); busy = false; waiting = false; e.deck = ArrayList()
        val nm = x.optJSONArray("NM")
        if (nm != null) for (i in 0 until Math.min(4, nm.length())) NM[i] = nm.getString(i)
        if (hum != null) {
            val old = NM.copyOf()
            for (n in 0 until 4) {
                val base = hum.getOrNull(n) ?: old[n].replace(" (یار)", "").replace(" (ربات)", "")
                NM[n] = if (n == 0) "شما" else base + (if (MP.away.containsKey(n)) " (ربات)" else "") + (if (n == 2) " (یار)" else "")
            }
        }
    }

    /** the score text shown by the score buttons */
    fun scoreText(): String = "امتیاز بازی: تیم شما " + fa(e.sc[0]) + "، حریف " + fa(e.sc[1])



    @Suppress("unused")
    private fun unusedLab(c: Card) = lab(c)
}
