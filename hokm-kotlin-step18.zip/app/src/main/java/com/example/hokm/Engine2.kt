package com.example.hokm

import com.example.hokm.Cards.allCards
import com.example.hokm.Cards.idc
import com.example.hokm.Cards.shuf

/** Trump suit + the three cards kept (two-player). */
class Choice2(@JvmField val T: Int, @JvmField val keep: List<Card>)

/**
 * Two-player Hokm: state, rules and the bot's brain.
 * Ported 1:1 from the game script (v2/g2/choose2Heur/playFull2/mc2Trump/choose2Hakem/draw2Face/
 * legal2/beats2/pts2/rp2/roll2/sv2/exact2/bot2Play_). Player 0 = you, 1 = the bot. trump/kt: -1 = none.
 */
class Engine2 {
    // ----- state (the Q object of the original) -----
    var sc = intArrayOf(0, 0)
    var hk = 0
    var hands: Array<MutableList<Card>> = arrayOf(ArrayList(), ArrayList())
    var tk = intArrayOf(0, 0)
    var trick: MutableList<TP> = ArrayList()
    var shown: MutableList<TP> = ArrayList()
    var played: MutableSet<Int> = HashSet()
    var gone: MutableSet<Int> = HashSet()
    var known: MutableList<Card> = ArrayList()
    var vo: Array<MutableSet<Int>> = arrayOf(HashSet(), HashSet())
    var trump = -1
    var kt = -1
    var deck: MutableList<Card> = ArrayList()

    companion object {
        var BOT2_MS = 450L

        fun v2(c: Card, T: Int): Double =
            if (c.s == T) 2 + c.r / 7.0 else (if (c.r >= 12) (c.r - 9) / 1.2 else c.r / 25.0)

        fun g2(c: Card, T: Int, h: List<Card>): Double {
            var v = v2(c, T)
            if (c.s == T) {
                v += 0.3 * Math.min(h.count { it.s == T }, 6)
            } else {
                val ns = h.count { it.s == c.s }
                if (ns >= 4) v -= 0.2 * (ns - 3)
                if (c.r == 14) v += 0.4
            }
            return v
        }

        // ===== انتخاب حکم/کارت‌های نگه‌داشتنی (توابع خالص) =====
        fun choose2Heur(h: List<Card>): Choice2 {
            var bT = 0; var bv = -1.0
            for (T in 0 until 4) {
                val v = h.map { v2(it, T) }.sortedDescending().take(3).fold(0.0) { a, b -> a + b }
                if (v > bv) { bv = v; bT = T }
            }
            val fT = bT
            return Choice2(bT, h.map { Pair(it, v2(it, fT)) }.sortedByDescending { it.second }.take(3).map { it.first })
        }

        private fun mn(a: List<Card>): Card = a.reduce { m, c -> if (c.r < m.r) c else m }

        // بازی کامل یک دور با سیاست ساده برای هر دو طرف؛ نتیجه: [برنده، امتیاز]
        fun playFull2(hh: Array<List<Card>>, hk: Int, T: Int): IntArray {
            val H = arrayOf(ArrayList(hh[0]), ArrayList(hh[1]))
            val t = intArrayOf(0, 0, -1); var turn = hk; var trick = ArrayList<TP>()
            val pol = { hand: List<Card>, led: Card? ->
                if (led == null) {
                    var b: Card? = null; var bv = -99
                    for (c in hand) { val v = c.r + (if (c.s == T) -50 else 0); if (v > bv) { bv = v; b = c } }
                    b!!
                } else {
                    val L = hand.filter { it.s == led.s }
                    if (L.isNotEmpty()) {
                        val w = L.filter { it.r > led.r }
                        mn(if (w.isNotEmpty()) w else L)
                    } else {
                        val tr = hand.filter { it.s == T }
                        if (tr.isNotEmpty() && led.s != T) mn(tr)
                        else hand.reduce { m, c -> if ((if (c.s == T) 100 + c.r else c.r) < (if (m.s == T) 100 + m.r else m.r)) c else m }
                    }
                }
            }
            while (true) {
                val c = pol(H[turn], if (trick.isNotEmpty()) trick[0].c else null)
                H[turn].remove(c); trick.add(TP(turn, c))
                if (trick.size < 2) { turn = 1 - turn; continue }
                val a = trick[0]; val b = trick[1]
                val wn = if (if (b.c.s == a.c.s) b.c.r > a.c.r else b.c.s == T) b.p else a.p
                t[wn]++
                if (t[2] < 0 && t[wn] >= 7 && t[1 - wn] == 0) t[2] = wn
                trick = ArrayList(); turn = wn
                val w = if (t[0] >= 7) 0 else if (t[1] >= 7) 1 else -1
                if (w >= 0 && (t[1 - w] > 0 || t[w] == 13)) {
                    val bam = t[w] == 13
                    return intArrayOf(w, if (bam) 7 else (if (t[2] == w) (if (w == hk) 2 else 3) else 1))
                }
            }
        }

        // حکم و سه کارت نگه‌داشتنی را با هم و با شبیه‌سازی مونت‌کارلو انتخاب می‌کند
        fun mc2Trump(h5: List<Card>, hk: Int, gone: Set<Int>): Choice2? {
            val mine = HashSet<Int>(); for (c in h5) mine.add(idc(c))
            val pool = allCards().filter { !mine.contains(idc(it)) && !gone.contains(idc(it)) }
            if (pool.size < 33) return null
            val opts = ArrayList<Choice2>()
            for (T in 0 until 4) for (i in 0 until 5) for (j in i + 1 until 5) for (k in j + 1 until 5)
                opts.add(Choice2(T, listOf(h5[i], h5[j], h5[k])))
            val sum = DoubleArray(opts.size)
            val t0 = System.currentTimeMillis()
            var n = 0
            while (n < 600 && (n < 40 || System.currentTimeMillis() - t0 < BOT2_MS * 2)) {
                val pi = shuf(ArrayList(pool)); val opp = pi.subList(0, 13).toList()
                for (o in opts.indices) {
                    val T = opts[o].T; val hand = ArrayList(opts[o].keep)
                    for (k in 0 until 10) {
                        val a = pi[13 + 2 * k]; val b = pi[14 + 2 * k]
                        hand.add(if (g2(a, T, hand) >= g2(b, T, hand)) a else b)
                    }
                    val r = playFull2(arrayOf(opp, hand), hk, T)
                    sum[o] += (if (r[0] == 1) r[1] else -r[1]).toDouble()
                }
                n++
            }
            var b = 0
            sum.forEachIndexed { i, v -> if (v > sum[b]) b = i }
            return opts[b]
        }

        fun choose2Hakem(h: List<Card>, hk: Int, gone: Set<Int>): Choice2 {
            var r = choose2Heur(h)
            try {
                if (h.size == 5) {
                    val m = mc2Trump(h, hk, gone)
                    if (m != null) r = m
                }
            } catch (e: Exception) { }
            return r
        }

        fun draw2Face(h: List<Card>, T: Int, up: Card, gone: Set<Int>): Boolean {
            val unk = allCards().filter { c -> !h.any { idc(it) == idc(c) } && !gone.contains(idc(c)) && idc(c) != idc(up) }
            val E = unk.fold(0.0) { a, c -> a + g2(c, T, h) } / unk.size
            return g2(up, T, h) >= E + 0.05
        }
    }

    // ----- rules -----
    fun legal2(p: Int): List<Card> {
        val h = hands[p]
        if (trick.isNotEmpty()) {
            val f = h.filter { it.s == trick[0].c.s }
            if (f.isNotEmpty()) return f
        }
        return h
    }

    fun beats2(c: Card, b: Card): Boolean = if (c.s == b.s) c.r > b.r else c.s == trump

    // ----- bot -----
    private val BAMV = Engine4.BAMV

    fun pts2(t: IntArray, team: Int): Int? {
        val w = if (t[0] >= 7) 0 else if (t[1] >= 7) 1 else -1
        if (w < 0) return null
        if (t[1 - w] == 0) {
            if (t[w] < 13) return null
            return if (w == team) BAMV else -BAMV
        }
        val p = if (t[2] == w) (if (w == hk) 2 else 3) else 1
        return if (w == team) p else -p
    }

    fun rp2(hand: List<Card>, led: Card?): Card {
        val T = trump
        if (led == null) {
            var b: Card? = null; var bv = -99
            for (c in hand) { val v = c.r + (if (c.s == T) -50 else 0); if (v > bv) { bv = v; b = c } }
            return b!!
        }
        val L = hand.filter { it.s == led.s }
        val mn = { a: List<Card> -> a.reduce { m, c -> if (c.r < m.r) c else m } }
        if (L.isNotEmpty()) {
            val w = L.filter { it.r > led.r }
            return mn(if (w.isNotEmpty()) w else L)
        }
        val tr = hand.filter { it.s == T }
        if (tr.isNotEmpty() && led.s != T) return mn(tr)
        return hand.reduce { m, c -> if ((if (c.s == T) 100 + c.r else c.r) < (if (m.s == T) 100 + m.r else m.r)) c else m }
    }

    private fun roll2(h0: Array<List<Card>>, p: Int, c0: Card): Double {
        val hh = arrayOf(ArrayList(h0[0]), ArrayList(h0[1])); val t = intArrayOf(tk[0], tk[1], kt)
        var trk = ArrayList<TP>(); for (x in trick) trk.add(TP(x.p, x.c))
        hh[p].remove(c0); trk.add(TP(p, c0)); var turn = 1 - p
        while (true) {
            if (trk.size == 2) {
                val w = if (beats2(trk[1].c, trk[0].c)) trk[1].p else trk[0].p
                Engine4.adv(t, w); trk = ArrayList(); turn = w
                val q = pts2(t, 1)
                if (q != null) return q.toDouble()
            }
            val pc = rp2(hh[turn], if (trk.isNotEmpty()) trk[0].c else null)
            hh[turn].remove(pc); trk.add(TP(turn, pc))
            if (trk.size < 2) turn = 1 - turn
        }
    }

    private class TI2(val p: Int, val id: Int)

    private var n2 = 0
    private var l2 = 0
    private var exLim = 8000

    private fun bt2(a: Int, b: Int): Boolean = if (a / 20 == b / 20) a % 20 > b % 20 else a / 20 == trump

    private fun sv2(hh: Array<IntArray>, trk0: List<TI2>, turn0: Int, t0: IntArray, al0: Double, be0: Double): Double {
        var al = al0; var be = be0; var trk = trk0; var turn = turn0; var t = t0
        if (++n2 > l2) throw Abort()
        if (trk.size == 2) {
            val w = if (bt2(trk[1].id, trk[0].id)) trk[1].p else trk[0].p
            val t2 = t.copyOf(); Engine4.adv(t2, w)
            val q = pts2(t2, 1)
            if (q != null) return q.toDouble()
            t = t2; turn = w; trk = ArrayList()
        }
        val hand = hh[turn]; val ls = if (trk.isNotEmpty()) trk[0].id / 20 else -1
        var L: List<Int> = hand.toList()
        if (ls >= 0) {
            val f = hand.filter { it / 20 == ls }
            if (f.isNotEmpty()) L = f
        }
        if (L.isEmpty()) return 0.0
        val vv = { i: Int -> (if (i / 20 == trump) 100 else 0) + i % 20 }
        L = L.sortedWith { a, b -> vv(b) - vv(a) }
        val mx = turn == 1
        var best = if (mx) -9.0 else 9.0
        for (id in L) {
            hh[turn] = hand.filter { it != id }.toIntArray()
            val nt = ArrayList<TI2>(trk); nt.add(TI2(turn, id))
            val v = sv2(hh, nt, 1 - turn, t, al, be)
            hh[turn] = hand
            if (mx) { if (v > best) best = v; if (best > al) al = best }
            else { if (v < best) best = v; if (best < be) be = best }
            if (al >= be) break
        }
        return best
    }

    private fun exact2(hs: Array<List<Card>>, c0: Card): Double? {
        val hh = arrayOf(hs[0].map { idc(it) }.toIntArray(), hs[1].map { idc(it) }.toIntArray())
        val id = idc(c0)
        hh[1] = hh[1].filter { it != id }.toIntArray()
        val trk = ArrayList<TI2>()
        for (x in trick) trk.add(TI2(x.p, idc(x.c)))
        trk.add(TI2(1, id))
        n2 = 0; l2 = exLim
        return try {
            sv2(hh, trk, 0, intArrayOf(tk[0], tk[1], kt), -9.0, 9.0)
        } catch (e: Abort) {
            null
        }
    }

    /** bot2Play: the card the bot plays (falls back to its lowest legal card on any error). */
    fun bot2Pick(): Card {
        return try {
            bot2PickInner()
        } catch (e: Exception) {
            val L = legal2(1)
            L.reduce { m, c -> if (c.r < m.r) c else m }
        }
    }

    private fun bot2PickInner(): Card {
        val h = hands[1]; val T = trump; val L = legal2(1)
        val bamZone = kt >= 0 || (Math.min(tk[0], tk[1]) == 0 && Math.max(tk[0], tk[1]) >= 5)
        exLim = if (bamZone) 40000 else 15000
        val unseen = { x: Int, r: Int -> !h.any { it.s == x && it.r == r } && !played.contains(x * 20 + r) && !gone.contains(x * 20 + r) }
        var C: List<Card> = L.toList()
        run {
            val inTr = HashSet<Int>(); for (x in trick) inTr.add(idc(x.c))
            val cc = C
            C = cc.filter { c ->
                !cc.any { d ->
                    d.s == c.s && d.r < c.r && run {
                        var ok = true
                        var r = d.r + 1
                        while (r < c.r) { if (unseen(c.s, r) || inTr.contains(c.s * 20 + r)) { ok = false; break }; r++ }
                        ok
                    }
                }
            }
        }
        if (C.size == 1) return C[0]
        val cand = C.sortedBy { if (it.s == T) 100 + it.r else it.r }
        val sc3 = DoubleArray(cand.size)
        val N = if (h.size <= (if (bamZone) 8 else 6)) 150 else 700
        val t0b = System.currentTimeMillis()
        val kl = known.filter { !played.contains(idc(it)) }
        val need = hands[0].size - kl.size
        var pool: List<Card> = allCards().filter { unseen(it.s, it.r) && !kl.any { k -> idc(k) == idc(it) } }
        val pf = pool.filter { !vo[0].contains(it.s) }
        if (pf.size >= need) pool = pf
        var n = 0
        while (n < N && (n < 12 || System.currentTimeMillis() - t0b < BOT2_MS)) {
            val pp = ArrayList(pool)
            for (i in pp.size - 1 downTo 1) {
                val j = Math.floor(Math.random() * (i + 1)).toInt()
                val x = pp[i]; pp[i] = pp[j]; pp[j] = x
            }
            val mine0 = ArrayList(kl); mine0.addAll(pp.subList(0, need))
            val hs: Array<List<Card>> = arrayOf(mine0, h)
            cand.forEachIndexed { i, c ->
                var v: Double? = null
                if (h.size <= (if (bamZone) 8 else 6)) v = exact2(hs, c)
                if (v == null) v = roll2(hs, 1, c)
                sc3[i] += v - 0.1 * (c.r / 14.0 + (if (c.s == T) 0.3 else 0.0))
            }
            n++
        }
        var bi = 0
        sc3.forEachIndexed { i, v -> if (v > sc3[bi]) bi = i }
        return cand[bi]
    }
}
