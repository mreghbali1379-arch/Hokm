package com.example.hokm

import com.example.hokm.Cards.shuf

/**
 * Four-player Hokm: state, rules and the bots' brain (Monte-Carlo + exact search).
 * Ported 1:1 from the game script (functions beats/bestOf/legal/adv/pts/setLV/sv/evalExact/weightOf/
 * sampleWorld/full/chooseTrump/rp/rollout/safePick/choose). "No value" (JS null) is -1 for trump and kt.
 */
class Engine4 {
    // ----- game state (globals of the original) -----
    var H: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    var trump = -1
    var hakem = Math.floor(Math.random() * 4).toInt()
    var turn = 0
    var trick: MutableList<TC> = ArrayList()
    var tk = intArrayOf(0, 0)
    var sc = intArrayOf(0, 0)
    var kt = -1
    var seen: MutableSet<Int> = HashSet()
    var voids: Array<MutableSet<Int>> = Array(4) { HashSet<Int>() }
    var plays: MutableList<Play> = ArrayList()
    var deck: MutableList<Card> = ArrayList()

    companion object {
        const val BAMV = 7
        var TRUMP_MS = 150L
        var BOT_MS = 150L
        var EX_CARDS = 5
        var EX_NODES = 15000
        var MIN_N = 16
        var FIX_N = 0
        var USE_LR = true
        var USE_MW = true
        var USE_BIAS = true

        // نسبت درست‌نمایی تعداد خال حکم در دست حاکم (جدول از شبیه‌سازی ۳۰۰هزار پخش)
        val HK_LR = doubleArrayOf(0.15, 0.2, 0.3, 0.78, 1.37, 2.0, 2.6, 3.1, 3.5, 4.0, 3.0, 2.0, 1.5, 1.5)

        /** probability of winning the whole game (race to 7) as the value of each hand's result */
        val MW: Array<DoubleArray> = run {
            val w = Array(8) { a -> DoubleArray(8) { b -> if (a >= 7) 1.0 else 0.0 } }
            for (a in 6 downTo 0) for (b in 6 downTo 0) w[a][b] = 0.5 * w[a + 1][b] + 0.5 * w[a][b + 1]
            w
        }

        fun adv(t: IntArray, w: Int) {
            t[w]++
            if (t[2] < 0 && t[w] >= 7 && t[1 - w] == 0) t[2] = w
        }
    }

    // ----- basic rules -----
    fun v(c: Card): Int = c.r + (if (c.s == trump) 100 else 0)
    fun beats(c: Card, b: Card): Boolean = if (c.s == b.s) c.r > b.r else c.s == trump
    fun bestOf(t: List<TC>): TC {
        var b = t[0]
        for (x in t) if (beats(x.c, b.c)) b = x
        return b
    }

    fun legal(s: Int): List<Card> {
        val h = H[s]
        if (trick.isEmpty()) return h
        val l = trick[0].c.s
        val f = h.filter { it.s == l }
        return if (f.isNotEmpty()) f else h
    }

    // ----- scoring of a hand -----
    private fun sid(i: Int) = i / 20
    private fun beatsI(a: Int, b: Int): Boolean = if (sid(a) == sid(b)) a % 20 > b % 20 else sid(a) == trump

    /** points of the hand for [team], or null while it is not decided. t = [tricks0, tricks1, kotWinner] */
    fun pts(t: IntArray, team: Int): Int? {
        val w = if (t[0] >= 7) 0 else if (t[1] >= 7) 1 else -1
        if (w < 0) return null
        if (t[1 - w] == 0) {
            if (t[w] < 13) return null
            return if (w == team) BAMV else -BAMV
        }
        val p = if (t[2] == w) (if (w == hakem % 2) 2 else 3) else 1
        return if (w == team) p else -p
    }

    private val LV = DoubleArray(15) { 0.5 }
    fun setLV(me: Int) {
        if (!USE_MW) {
            for (p in -7..7) LV[p + 7] = 0.5 + p / 14.0
            return
        }
        val a = Math.min(7, sc[me]); val b = Math.min(7, sc[1 - me])
        for (p in -7..7) {
            val vv: Double = if (p > 0) MW[Math.min(7, a + p)][b]
            else if (p < 0) MW[a][Math.min(7, b - p)]
            else MW[a][b]
            LV[p + 7] = vv + 0.004 * p
        }
    }

    // ----- exact search (alpha-beta with transposition table) -----
    private class Ent(var lo: Double, var hi: Double)
    private class TI(val seat: Int, val id: Int)

    private var nodes = 0
    private var lim = 0
    private val exLim = 8000
    private var U = IntArray(4)
    private val TT = HashMap<String, Ent>()
    private var DEADLINE = 0.0

    private fun ttKey(hh: Array<IntArray>, turn: Int, t: IntArray): String {
        val sb = StringBuilder()
        sb.append(turn).append('|').append(t[0]).append('|').append(t[1]).append('|')
        sb.append(if (t[2] < 0) "n" else t[2].toString())
        for (p in 0 until 4) {
            val m = IntArray(4)
            for (i in hh[p]) m[sid(i)] = m[sid(i)] or (1 shl (i % 20))
            sb.append('|').append(m[0]).append(',').append(m[1]).append(',').append(m[2]).append(',').append(m[3])
        }
        return sb.toString()
    }

    private fun sv(hh: Array<IntArray>, trk: ArrayList<TI>, turn: Int, t: IntArray, team: Int, al0In: Double, be0In: Double): Double {
        var al = al0In
        var be = be0In
        if (++nodes > lim || ((nodes and 255) == 0 && System.currentTimeMillis() > DEADLINE)) throw Abort()
        if (trk.size == 4) {
            var b = trk[0]
            for (x in trk) if (beatsI(x.id, b.id)) b = x
            val t2 = t.copyOf(); adv(t2, b.seat % 2)
            val p = pts(t2, team)
            if (p != null) return LV[p + 7]
            val u0 = U[0]; val u1 = U[1]; val u2 = U[2]; val u3 = U[3]
            for (x in trk) U[sid(x.id)] = U[sid(x.id)] and (1 shl (x.id % 20)).inv()
            val r = sv(hh, ArrayList(), b.seat, t2, team, al, be)
            U[0] = u0; U[1] = u1; U[2] = u2; U[3] = u3
            return r
        }
        var key: String? = null
        var ent: Ent? = null
        val al0 = al; val be0 = be
        if (trk.isEmpty() && hh[turn].size > 1) {
            key = ttKey(hh, turn, t); ent = TT[key]
            if (ent != null) {
                if (ent.lo >= be) return ent.lo
                if (ent.hi <= al) return ent.hi
                if (ent.lo > al) al = ent.lo
                if (ent.hi < be) be = ent.hi
                if (al >= be) return if (ent.lo >= be0) ent.lo else ent.hi
            }
        }
        val hand = hh[turn]
        val led = if (trk.isNotEmpty()) sid(trk[0].id) else -1
        var L: IntArray = hand
        if (led >= 0) {
            val f = hand.filter { sid(it) == led }
            if (f.isNotEmpty()) L = f.toIntArray()
        }
        if (L.isEmpty()) return LV[7]
        val vv = { i: Int -> (if (sid(i) == trump) 100 else 0) + i % 20 }
        var bid = -1
        if (trk.isNotEmpty()) {
            bid = trk[0].id
            for (x in trk) if (beatsI(x.id, bid)) bid = x.id
        }
        val sorted: List<Int> = if (bid >= 0) {
            val bb = bid
            L.toList().sortedWith { a, b ->
                (if (beatsI(b, bb)) 2000 - vv(b) else -vv(b)) - (if (beatsI(a, bb)) 2000 - vv(a) else -vv(a))
            }
        } else {
            L.toList().sortedWith { a, b -> vv(b) - vv(a) }
        }
        val mx = turn % 2 == team
        var best = if (mx) -9.0 else 9.0
        val prev = intArrayOf(-1, -1, -1, -1)
        for (id in sorted) {
            val sd = sid(id); val pv = prev[sd]; prev[sd] = id
            if (pv >= 0) {
                val lo = Math.min(pv, id) % 20; val hi = Math.max(pv, id) % 20
                if ((U[sd] and (((1 shl hi) - 1) and ((1 shl (lo + 1)) - 1).inv())) == 0) continue
            }
            hh[turn] = hand.filter { it != id }.toIntArray()
            trk.add(TI(turn, id))
            val r = sv(hh, trk, (turn + 1) % 4, t, team, al, be)
            trk.removeAt(trk.size - 1)
            hh[turn] = hand
            if (mx) { if (r > best) best = r; if (best > al) al = best }
            else { if (r < best) best = r; if (best < be) be = best }
            if (al >= be) break
        }
        if (key != null) {
            val e = ent ?: Ent(-9.0, 9.0)
            if (best <= al0) e.hi = Math.min(e.hi, best)
            else if (best >= be0) e.lo = Math.max(e.lo, best)
            else { e.lo = best; e.hi = best }
            TT[key] = e
        }
        return best
    }

    private fun evalExact(hs: Array<List<Card>>, s: Int, c: Card, limit: Int): Double? {
        val hh: Array<IntArray> = Array(4) { p -> hs[p].map { it.s * 20 + it.r }.toIntArray() }
        val id = c.s * 20 + c.r
        hh[s] = hh[s].filter { it != id }.toIntArray()
        val trk = ArrayList<TI>()
        for (t in trick) trk.add(TI(t.seat, t.c.s * 20 + t.c.r))
        trk.add(TI(s, id))
        U = IntArray(4)
        for (a in hh) for (i in a) U[sid(i)] = U[sid(i)] or (1 shl (i % 20))
        for (x in trk) U[sid(x.id)] = U[sid(x.id)] or (1 shl (x.id % 20))
        nodes = 0; lim = limit; TT.clear()
        return try {
            sv(hh, trk, (s + 1) % 4, intArrayOf(tk[0], tk[1], kt), s % 2, -9.0, 9.0)
        } catch (e: Abort) {
            null
        }
    }

    // ----- inference about the unseen cards -----
    private fun weightOf(hs: Array<MutableList<Card>>, s: Int): Double {
        var w = 1.0
        for (i in plays.indices) {
            val e = plays[i]; val X = e.seat
            if (X == s || e.len == 0) continue
            val hand = ArrayList<Card>(hs[X])
            for (k in i until plays.size) if (plays[k].seat == X) hand.add(plays[k].c)
            if (e.c.s == e.led) {
                val pwin = (X + 2) % 4 == e.bs
                val wins = !pwin && beats(e.c, e.bc!!)
                if (hand.any { it.s == e.led && it.r < e.c.r && (if (wins) beats(it, e.bc!!) else true) })
                    w *= if (X == 0) 0.6 else 0.3
            } else if (e.c.s != trump && (X + 2) % 4 != e.bs && hand.any { it.s == trump && beats(it, e.bc!!) }) {
                w *= if (X == 0) 0.5 else 0.2
            }
        }
        return w
    }

    private class Item(val c: Card, val al: List<Int>)

    // پخش تصادفی کارت‌های دیده‌نشده بین سه نفر دیگر، با رعایت «خالی بودن خال» (قطع کردن) هر نفر
    private fun sampleWorld(s: Int, un: List<Card>, others: List<Int>, useVoids: Boolean): Array<MutableList<Card>>? {
        for (at in 0 until (if (useVoids) 8 else 1)) {
            val need = IntArray(4)
            for (o in others) need[o] = H[o].size
            val hs: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
            hs[s] = ArrayList(H[s])
            val items = ArrayList<Item>()
            for (c in shuf(ArrayList(un))) {
                items.add(Item(c, if (useVoids) others.filter { !voids[it].contains(c.s) } else others))
            }
            if (useVoids) items.sortWith { a, b -> a.al.size - b.al.size }
            var ok = true
            for (item in items) {
                var tot = 0
                for (o in item.al) if (need[o] > 0) tot += need[o]
                if (tot <= 0) { ok = false; break }
                var r = Math.random() * tot
                var pk = -1
                for (o in item.al) if (need[o] > 0) { r -= need[o]; if (r < 0) { pk = o; break } }
                if (pk < 0) pk = item.al.first { need[it] > 0 }
                hs[pk].add(item.c); need[pk]--
            }
            if (ok) return hs
        }
        return null
    }

    // ----- playout policy and simulations -----
    fun rp(hand: List<Card>, seat: Int, trk: List<TC>): Card {
        val led = if (trk.isNotEmpty()) trk[0].c.s else -1
        var L: List<Card> = hand
        if (led >= 0) {
            val f = hand.filter { it.s == led }
            if (f.isNotEmpty()) L = f
        }
        if (trk.isEmpty()) {
            var b: Card? = null; var bv = -99
            for (c in hand) {
                val vv = c.r + (if (c.s == trump) -50 else 0)
                if (vv > bv) { bv = vv; b = c }
            }
            return b!!
        }
        val b = bestOf(trk)
        var lc = L[0]
        for (c in L) if (v(c) < v(lc)) lc = c
        if (b.seat % 2 == seat % 2) return lc
        var w: Card? = null
        for (c in L) if (beats(c, b.c) && (w == null || v(c) < v(w))) w = c
        return w ?: lc
    }

    private fun full(h0: Array<MutableList<Card>>, hk: Int): Double {
        val hh = Array(4) { ArrayList(h0[it]) }
        val t = intArrayOf(0, 0, -1)
        var trk = ArrayList<TC>(); var turn = hk
        while (true) {
            if (trk.size == 4) {
                val w = bestOf(trk).seat; adv(t, w % 2); trk = ArrayList(); turn = w
                val p = pts(t, hk % 2)
                if (p != null) return LV[p + 7]
            }
            val pc = rp(hh[turn], turn, trk)
            hh[turn].remove(pc); trk.add(TC(turn, pc))
            if (trk.size < 4) turn = (turn + 1) % 4
        }
    }

    fun chooseTrump(hk: Int): Int {
        val mine = ArrayList(H[hk]); val own = HashSet<Int>(); for (c in mine) own.add(c.s * 20 + c.r)
        val un = ArrayList<Card>()
        for (x in 0 until 4) for (r in 2..14) if (!own.contains(x * 20 + r)) un.add(Card(x, r))
        val sc3 = DoubleArray(4)
        val old = trump; val t0 = System.currentTimeMillis()
        try {
            setLV(hk % 2)
            var n = 0
            while (n < 600 && (n < 150 || System.currentTimeMillis() - t0 < TRUMP_MS)) {
                val pool = shuf(ArrayList(un))
                val hs: Array<MutableList<Card>> = Array(4) { o ->
                    val take = if (o == hk) 8 else 13
                    val part = ArrayList<Card>()
                    if (o == hk) part.addAll(mine)
                    repeat(take) { part.add(pool.removeAt(0)) }
                    part
                }
                for (x in 0 until 4) { trump = x; sc3[x] += full(hs, hk) }
                n++
            }
        } finally {
            trump = old
        }
        var b = 0
        sc3.forEachIndexed { i, vv -> if (vv > sc3[b]) b = i }
        return b
    }

    private fun rollout(h0: Array<MutableList<Card>>, s: Int, c: Card): Double {
        val hh = Array(4) { ArrayList(h0[it]) }
        hh[s].remove(c)
        val t = intArrayOf(tk[0], tk[1], kt)
        var trk = ArrayList<TC>(trick); trk.add(TC(s, c)); var turn = (s + 1) % 4
        while (true) {
            if (trk.size == 4) {
                val w = bestOf(trk).seat; adv(t, w % 2); trk = ArrayList(); turn = w
                val pp = pts(t, s % 2)
                if (pp != null) return LV[pp + 7]
            }
            if (hh[turn].isEmpty()) break
            val pc = rp(hh[turn], turn, trk)
            hh[turn].remove(pc); trk.add(TC(turn, pc))
            if (trk.size < 4) turn = (turn + 1) % 4
        }
        return LV[(pts(t, s % 2) ?: 0) + 7]
    }

    fun safePick(s: Int): Card? {
        val L = legal(s)
        if (L.isEmpty()) return null
        try {
            val c = rp(H[s], s, trick)
            if (L.contains(c)) return c
        } catch (e: Exception) { }
        return L.reduce { m, c -> if (v(c) < v(m)) c else m }
    }

    /** The bot's decision for seat s (null when it cannot decide: the caller then uses safePick). */
    fun choose(s: Int): Card? {
        val h = H[s]; val L = legal(s)
        if (L.size == 1) return L[0]
        setLV(s % 2)
        val inTrick = HashSet<Int>(); for (t in trick) inTrick.add(t.c.s * 20 + t.c.r)
        val inert = { x: Int, r: Int -> h.any { it.s == x && it.r == r } || (seen.contains(x * 20 + r) && !inTrick.contains(x * 20 + r)) }
        val eqv = { d: Card, c: Card ->
            var ok = true
            var r = d.r + 1
            while (r < c.r) { if (!inert(c.s, r)) { ok = false; break }; r++ }
            ok
        }
        val cand = L.filter { c -> !L.any { d -> d.s == c.s && d.r < c.r && eqv(d, c) } }.sortedBy { v(it) }
        if (cand.size == 1) return cand[0]
        val un = ArrayList<Card>()
        for (x in 0 until 4) for (r in 2..14) if (!seen.contains(x * 20 + r) && !h.any { it.s == x && it.r == r }) un.add(Card(x, r))
        val others = (0 until 4).filter { it != s }
        if (un.size != others.sumOf { H[it].size }) return null
        val cnt = h.size
        val bamZone = kt >= 0 || (Math.min(tk[0], tk[1]) == 0 && Math.max(tk[0], tk[1]) >= 5)
        val exact = cnt <= (if (bamZone) EX_CARDS + 1 else EX_CARDS)
        val budget = BOT_MS * (if (bamZone) 1.5 else 1.0)
        val t0 = System.currentTimeMillis()
        // جریمهٔ کوچک برای سه الگوی تقریباً همیشه غلط در نفر آخر دست
        val lastSeat = trick.size == 3
        val bb0 = if (trick.isNotEmpty()) bestOf(trick) else null
        val pwin = bb0 != null && bb0.seat == (s + 2) % 4
        val bias = { c: Card ->
            if (!USE_BIAS || !lastSeat) 0.0 else {
                val cw = beats(c, bb0!!.c)
                var p = 0.0
                if (pwin && cw) p += 0.012
                if (pwin && c.s == trump && bb0.c.s != trump) p += 0.012
                if (!pwin && !cw && c.s == trick[0].c.s && L.any { beats(it, bb0.c) }) p += 0.012
                p
            }
        }
        val sc2 = DoubleArray(cand.size)
        var W = 0.0
        DEADLINE = t0 + budget * 2.5
        if (FIX_N != 0) DEADLINE = 1e18
        var n = 0
        while (n < 4000 && (if (FIX_N != 0) n < FIX_N else
                ((n < MIN_N || System.currentTimeMillis() - t0 < budget) && (n < 3 || System.currentTimeMillis() - t0 < budget * 2.5)))) {
            val hs = sampleWorld(s, un, others, true) ?: sampleWorld(s, un, others, false) ?: return null
            val lr = if (USE_LR && s != hakem && trump >= 0)
                HK_LR[Math.min(13, hs[hakem].count { it.s == trump })] else 1.0
            val w = weightOf(hs, s) * lr
            W += w
            for (i in cand.indices) {
                val c = cand[i]
                var vv: Double? = null
                if (exact) vv = evalExact(Array<List<Card>>(4) { hs[it] }, s, c, EX_NODES)
                if (vv == null) vv = rollout(hs, s, c)
                sc2[i] += w * (vv - 0.0008 * (c.r / 14.0 + (if (c.s == trump) 0.3 else 0.0)) - bias(c))
            }
            n++
        }
        var bi = 0
        sc2.forEachIndexed { i, vv -> if (vv > sc2[bi]) bi = i }
        return cand[bi]
    }

    /** What botPlay does before playing: choose, fall back to safePick. */
    fun botMove(s: Int): Card? {
        var pick: Card? = try { choose(s) } catch (e: Exception) { null }
        val L = legal(s)
        if (pick == null || !L.contains(pick)) pick = safePick(s)
        return pick
    }
}
