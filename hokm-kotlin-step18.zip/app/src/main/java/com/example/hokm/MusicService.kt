package com.example.hokm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/**
 * Plays the background music as a foreground service (type mediaPlayback), so Android keeps it
 * running when the screen is locked. The game only tells it "on/off" and the volume.
 */
class MusicService : Service() {

    companion object {
        private const val CHANNEL = "hokm_music_quiet"
        private const val NOTIF_ID = 41
        private val TRACKS = arrayOf("bidad", "kordy", "santur", "ayene", "tamanna", "feragh", "dargham")

        // wanted state; lives in statics so that it survives while the service is (re)starting
        @Volatile private var inst: MusicService? = null
        @Volatile private var enabled = false   // music switch of the game is on
        @Volatile private var held = false      // player left the game screen (not a lock) -> paused
        @Volatile private var volume = 0.5f

        // ---------- called from MainActivity ----------
        fun apply(ctx: Context, on: Boolean, vol: Float) {
            volume = Math.max(0f, Math.min(1f, vol))
            enabled = on
            val s = inst
            if (s != null) {
                s.handler.post { s.refresh() }
            } else if (on) {
                try {
                    val i = Intent(ctx, MusicService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i)
                    else ctx.startService(i)
                } catch (ignored: Exception) {
                    // not allowed to start from the background; the next call from the foreground will do it
                }
            }
        }

        fun hold(h: Boolean) {
            held = h
            val s = inst
            if (s != null) {
                s.handler.post { s.refresh() }
            }
        }

        fun stopNow() {
            enabled = false
            val s = inst
            if (s != null) s.handler.post { s.refresh() }
        }
    }

    // ---------- service ----------
    private lateinit var handler: Handler
    private var am: AudioManager? = null
    private lateinit var nm: NotificationManager
    private var mp: MediaPlayer? = null
    private var focusReq: AudioFocusRequest? = null
    private var hasFocus = false
    private var transientLoss = false
    private var lastNotifState = -1
    private var errorsInRow = 0
    private var dead = false
    private val queue = ArrayList<String>()
    private var lastTrack = ""

    override fun onCreate() {
        super.onCreate()
        inst = this
        handler = Handler(Looper.getMainLooper())
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "موسیقی بازی", NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_SECRET
            nm.createNotificationChannel(ch)
        }
        startFg()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg() // every startForegroundService() call must be answered with startForeground()
        refresh()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        enabled = false
        finish()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if (inst === this) inst = null
        handler.removeCallbacksAndMessages(null)
        destroyPlayer()
        abandonFocus()
        super.onDestroy()
    }

    // ---------- notification ----------
    private fun startFg() {
        try {
            val n = buildNotification(isPlaying())
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            // the system refused to make us a foreground service
            enabled = false
            stopSelf()
        }
    }

    private fun buildNotification(playing: Boolean): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val open = packageManager.getLaunchIntentForPackage(packageName)
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        if (open != null) b.setContentIntent(PendingIntent.getActivity(this, 0, open, fl))
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("حکم")
            .setContentText(if (playing) "موسیقی در حال پخش است" else "موسیقی تا بازگشت به بازی متوقف است")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    private fun updateNotification(playing: Boolean) {
        val st = if (playing) 1 else 0
        if (st == lastNotifState) return
        lastNotifState = st
        try { nm.notify(NOTIF_ID, buildNotification(playing)) } catch (ignored: Exception) { }
    }

    // ---------- playback ----------
    private fun shouldPlay(): Boolean = enabled && !held && !transientLoss

    private fun isPlaying(): Boolean =
        try { mp != null && mp!!.isPlaying } catch (e: Exception) { false }

    private fun refresh() {
        if (dead) return
        if (!enabled) { finish(); return }
        try {
            if (shouldPlay()) {
                if (mp == null && !loadNext()) { finish(); return }
                if (!mp!!.isPlaying) {
                    requestFocus()
                    mp!!.start()
                }
                applyVolume()
            } else {
                if (mp != null && mp!!.isPlaying) mp!!.pause()
                if (held) abandonFocus()
            }
            updateNotification(isPlaying())
        } catch (e: Exception) {
            // the player got into a bad state: drop it, the next refresh builds a new one
            destroyPlayer()
            lastNotifState = -1
            handler.postDelayed({ refresh() }, 500)
        }
    }

    private fun applyVolume() {
        val p = mp ?: return
        val v = volume
        try { p.setVolume(v, v) } catch (ignored: Exception) { }
    }

    private fun nextTrack(): String {
        if (queue.isEmpty()) {
            queue.addAll(TRACKS)
            queue.shuffle()
            if (queue.size > 1 && queue[0] == lastTrack) queue.add(queue.removeAt(0))
        }
        lastTrack = queue.removeAt(0)
        return lastTrack
    }

    /** Prepares the next track that can be opened. A fresh MediaPlayer per track keeps its state simple. */
    private fun loadNext(): Boolean {
        for (tries in 0 until TRACKS.size) {
            destroyPlayer()
            val name = nextTrack()
            val p = MediaPlayer()
            try {
                p.setAudioAttributes(attrs())
                p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) // keep the CPU awake while the screen is off
                val afd = assets.openFd("sounds/$name.mp3")
                try {
                    p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                } finally {
                    afd.close()
                }
                p.setOnCompletionListener { errorsInRow = 0; handler.post { trackEnded() } }
                p.setOnErrorListener { _, _, _ ->
                    errorsInRow++ // give up after a few failures in a row instead of spinning
                    handler.post { trackEnded() }
                    true
                }
                p.prepare()
                mp = p
                applyVolume()
                return true
            } catch (e: Exception) {
                try { p.release() } catch (ignored: Exception) { }
            }
        }
        return false
    }

    private fun trackEnded() {
        if (dead || !enabled) return
        if (errorsInRow > 4 || !loadNext()) { finish(); return }
        refresh()
    }

    private fun destroyPlayer() {
        val p = mp
        mp = null
        if (p != null) {
            try { p.setOnCompletionListener(null); p.setOnErrorListener(null) } catch (ignored: Exception) { }
            try { p.release() } catch (ignored: Exception) { }
        }
    }

    private fun finish() {
        dead = true
        if (inst === this) inst = null // a new start request must create a fresh service
        destroyPlayer()
        abandonFocus()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (ignored: Exception) { }
        stopSelf()
    }

    // ---------- audio focus (phone calls, other players) ----------
    private fun attrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

    // Only a real phone call / ringing pauses the music. Other sounds (the game's own effects, TalkBack speech,
    // notification sounds, other apps) must NOT cut it: their focus changes are ignored and the music just mixes.
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_GAIN) {
            transientLoss = false
            refresh()
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            val m = am!!.mode
            if (m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_RINGTONE || m == AudioManager.MODE_IN_COMMUNICATION) {
                transientLoss = true
                refresh()
            }
        }
    }

    private fun requestFocus() {
        val a = am
        if (hasFocus || a == null) return
        val r: Int
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusReq == null) {
                focusReq = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs())
                    .setOnAudioFocusChangeListener(focusListener, handler)
                    .build()
            }
            r = a.requestAudioFocus(focusReq!!)
        } else {
            @Suppress("DEPRECATION")
            r = a.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
        hasFocus = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED // if refused we still play, like a normal game
    }

    private fun abandonFocus() {
        val a = am
        if (a == null || !hasFocus) return
        hasFocus = false
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq?.let { a.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                a.abandonAudioFocus(focusListener)
            }
        } catch (ignored: Exception) { }
    }
}
