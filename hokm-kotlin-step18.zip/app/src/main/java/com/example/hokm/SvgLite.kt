package com.example.hokm

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF

/** A tiny SVG drawer for the player faces: svg, g, rect, circle, ellipse and path (M L Q Z, absolute and relative). */
object SvgLite {
    private val TAG = Regex("<(/?)(\\w+)([^>]*?)(/?)>")
    private val ATT = Regex("([\\w:-]+)=\"([^\"]*)\"")
    private val NUM = Regex("-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?")

    private fun color(s: String?): Int? {
        if (s == null || s == "none") return null
        return try {
            if (s.startsWith("#")) {
                val h = s.substring(1)
                val full = if (h.length == 3) "" + h[0] + h[0] + h[1] + h[1] + h[2] + h[2] else h
                Color.parseColor("#$full")
            } else Color.parseColor(s)
        } catch (e: Exception) { null }
    }

    private fun path(d: String): Path {
        val p = Path()
        val tok = Regex("[MLQZmlqz]|-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?").findAll(d).map { it.value }.toList()
        var i = 0; var cmd = ' '; var cx = 0f; var cy = 0f
        fun num(): Float = tok[i++].toFloat()
        while (i < tok.size) {
            val t = tok[i]
            if (t.length == 1 && t[0].isLetter()) { cmd = t[0]; i++; if (cmd == 'Z' || cmd == 'z') { p.close(); continue } }
            when (cmd) {
                'M' -> { cx = num(); cy = num(); p.moveTo(cx, cy); cmd = 'L' }
                'm' -> { cx += num(); cy += num(); p.moveTo(cx, cy); cmd = 'l' }
                'L' -> { cx = num(); cy = num(); p.lineTo(cx, cy) }
                'l' -> { cx += num(); cy += num(); p.lineTo(cx, cy) }
                'Q' -> { val x1 = num(); val y1 = num(); val x = num(); val y = num(); p.quadTo(x1, y1, x, y); cx = x; cy = y }
                'q' -> { val x1 = cx + num(); val y1 = cy + num(); val x = cx + num(); val y = cy + num(); p.quadTo(x1, y1, x, y); cx = x; cy = y }
                else -> i++
            }
        }
        return p
    }

    /** draws the SVG text into a bitmap of [px] x [ph] pixels (square when [ph] is left out) */
    fun render(svg: String, px: Int, ph: Int = px): Bitmap {
        val bmp = Bitmap.createBitmap(px, ph, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val vb = Regex("viewBox=\"([^\"]*)\"").find(svg)?.groupValues?.get(1)?.trim()?.split(Regex("\\s+"))?.map { it.toFloat() }
        val vw = vb?.getOrNull(2) ?: 100f; val vh = vb?.getOrNull(3) ?: 100f
        c.scale(px / vw, ph / vh)
        for (m in TAG.findAll(svg)) {
            if (m.groupValues[1] == "/") continue
            val name = m.groupValues[2]
            if (name == "svg" || name == "g") continue
            val at = HashMap<String, String>()
            for (a in ATT.findAll(m.groupValues[3])) at[a.groupValues[1]] = a.groupValues[2]
            fun f(k: String, d: Float = 0f) = at[k]?.toFloatOrNull() ?: d
            val op = f("opacity", 1f)
            val fill = if (at.containsKey("fill")) color(at["fill"]) else Color.BLACK
            val stroke = color(at["stroke"])
            val sw = f("stroke-width", 1f)
            fun paint(fillP: Boolean): Paint {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                if (fillP) { p.style = Paint.Style.FILL; p.color = fill ?: 0 }
                else {
                    p.style = Paint.Style.STROKE; p.color = stroke ?: 0; p.strokeWidth = sw
                    if (at["stroke-linecap"] == "round") p.strokeCap = Paint.Cap.ROUND
                    if (at["stroke-linejoin"] == "round") p.strokeJoin = Paint.Join.ROUND
                }
                p.alpha = Math.round(p.alpha * op)
                return p
            }
            val tr = at["transform"]
            val rot = if (tr != null) Regex("rotate\\(([^)]*)\\)").find(tr)?.groupValues?.get(1)?.trim()?.split(Regex("[\\s,]+"))?.map { it.toFloat() } else null
            if (rot != null) { c.save(); c.rotate(rot[0], rot.getOrElse(1) { 0f }, rot.getOrElse(2) { 0f }) }
            when (name) {
                "rect" -> {
                    val r = RectF(f("x"), f("y"), f("x") + f("width"), f("y") + f("height")); val rx = f("rx")
                    if (fill != null) c.drawRoundRect(r, rx, rx, paint(true))
                    if (stroke != null) c.drawRoundRect(r, rx, rx, paint(false))
                }
                "circle" -> {
                    if (fill != null) c.drawCircle(f("cx"), f("cy"), f("r"), paint(true))
                    if (stroke != null) c.drawCircle(f("cx"), f("cy"), f("r"), paint(false))
                }
                "ellipse" -> {
                    val r = RectF(f("cx") - f("rx"), f("cy") - f("ry"), f("cx") + f("rx"), f("cy") + f("ry"))
                    if (fill != null) c.drawOval(r, paint(true))
                    if (stroke != null) c.drawOval(r, paint(false))
                }
                "path" -> {
                    val p = path(at["d"] ?: "")
                    if (fill != null) c.drawPath(p, paint(true))
                    if (stroke != null) c.drawPath(p, paint(false))
                }
            }
            if (rot != null) c.restore()
        }
        return bmp
    }

    @Suppress("unused")
    private val unusedNum = NUM
}
