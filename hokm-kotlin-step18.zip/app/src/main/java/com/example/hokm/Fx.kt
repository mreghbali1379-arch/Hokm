package com.example.hokm

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.PointF
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.AccelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Motion effects: a played card flies to the table, the trick's cards are collected by the winner,
 * the result banner and the trump flash (fly / takeAway / banner / trumpFlash of the page).
 */
object Fx {
    private lateinit var act: MainActivity
    private lateinit var box: FrameLayout

    private val BNT = mapOf(
        "win" to "✅ امتیاز این دست برای شماست", "lose" to "❌ حریف امتیاز این دست را گرفت",
        "kwin" to "🔥 کوت!", "klose" to "حریف کوت کرد",
        "fwin" to "🏆 شما بازی را بردید!", "flose" to "حریف بازی را برد"
    )
    private val BDU = mapOf("win" to 2950, "lose" to 3350, "kwin" to 3500, "klose" to 3500, "fwin" to 5000, "flose" to 3400)

    /** call once after the root view exists: adds the transparent layer the banners are drawn on */
    fun init(a: MainActivity) {
        act = a
        box = FrameLayout(a)
        box.layoutDirection = View.LAYOUT_DIRECTION_LTR   // positions below are measured from the left edge
        box.isClickable = false
        box.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        a.root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun rotOf(k: Int): Float = (((k * 37) % 30) - 15).toFloat()

    /** centre of a view in root coordinates, or null when it has no size yet (rc) */
    fun center(v: View?): PointF? {
        if (v == null || !::act.isInitialized) return null
        if (v.width == 0 && v.height == 0) return null
        val a = IntArray(2); val b = IntArray(2)
        v.getLocationInWindow(a); act.root.getLocationInWindow(b)
        return PointF(a[0] - b[0] + v.width / 2f, a[1] - b[1] + v.height / 2f)
    }

    private class Rec(val t0: Long, val delay: Long, val dur: Long)
    private val fl = HashMap<String, Rec>()

    /** true while a flight with this id is known (ANI.fl[id]) */
    fun has(id: String): Boolean = fl.containsKey(id)

    /** counter that makes the ids of one hand's cards different from the next hand's (ANI.hn) */
    @JvmField var hn = 0
    /** a four-player hand is being dealt now / the keys of the first five cards (ANI.deal4 / first5) */
    @JvmField var deal4 = false
    @JvmField var first5: Set<Int>? = null

    /**
     * The view appears to come from [src]: small and faint at first, then moves to its own place (fly).
     * The flight is remembered by [id], so when the screen is redrawn while it is in the air, the new view
     * carries on from where the old one was instead of jumping.
     */
    fun fly(id: String, v: View?, src: PointF?, dur: Long, s: Float = 0.55f, rot: Float = 0f, o: Float = 0.35f,
            delay: Long = 0, flip: Boolean = false, snd: Boolean = false) {
        val now = Sched.now()
        val it = fl.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (e.key != id && now - e.value.t0 > 7000) it.remove() }
        var rec = fl[id]
        if (rec == null && (snd || (v != null && src != null))) {
            rec = Rec(now, delay, dur); fl[id] = rec
            if (snd) Sched.later(Math.max(0L, delay + dur - Sound.CSO)) { Sound.cardSnd() }
        }
        if (v == null || src == null || rec == null) return
        val el = now - rec.t0; val total = rec.delay + rec.dur
        if (el >= total) return
        val r = rec
        v.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (v.viewTreeObserver.isAlive) v.viewTreeObserver.removeOnPreDrawListener(this)
                val c = center(v) ?: return true
                val ease = PathInterpolator(0.2f, 0.8f, 0.2f, 1f)
                fun apply(p: Float) {
                    val q = 1f - p
                    if (flip) { v.scaleX = 0.05f + 0.95f * p; v.alpha = 0.6f + 0.4f * p }
                    else {
                        v.translationX = (src.x - c.x) * q; v.translationY = (src.y - c.y) * q
                        v.scaleX = s + (1f - s) * p; v.scaleY = v.scaleX; v.rotation = rot * q; v.alpha = o + (1f - o) * p
                    }
                }
                apply(0f)
                val an = ValueAnimator.ofFloat(0f, 1f)
                an.duration = Math.max(1L, total - el)
                an.interpolator = android.view.animation.LinearInterpolator()
                an.addUpdateListener { a ->
                    val tt = el + a.currentPlayTime
                    apply(if (tt < r.delay) 0f else ease.getInterpolation(((tt - r.delay).toFloat() / r.dur).coerceIn(0f, 1f)))
                }
                an.addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) { apply(1f) }
                })
                an.start()
                return true
            }
        })
    }

    private val handDone = HashSet<String>()

    /** the player's hand brings the card from his place, puts it on the table and goes back (handFx) */
    fun handFx(id: String, from: PointF?, to: PointF?, nm: String) {
        try {
            if (from == null || to == null || !::box.isInitialized || handDone.contains(id)) return
            handDone.add(id)
            if (handDone.size > 400) handDone.clear()
            val v = android.widget.ImageView(act)
            v.setImageBitmap(Av.handBitmap(Av.clean(nm)))
            v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val w = Px.dp(34); val h = Px.dp(51)
            box.addView(v, FrameLayout.LayoutParams(w, h))
            val dx = to.x - from.x; val dy = to.y - from.y
            val ang = (Math.atan2(dy.toDouble(), dx.toDouble()) * 180 / Math.PI + 90).toFloat()
            val du = Anim.ad(780).toLong()
            val off = floatArrayOf(0f, 0.25f, 0.45f, 0.55f, 1f)
            val fx = floatArrayOf(0f, dx * 0.55f, dx, dx, 0f); val fy = floatArrayOf(0f, dy * 0.55f, dy, dy, 0f)
            val sc = floatArrayOf(0.8f, 1f, 1f, 1f, 0.8f); val al = floatArrayOf(0f, 1f, 1f, 1f, 0f)
            val ease = PathInterpolator(0.42f, 0f, 0.58f, 1f)
            v.rotation = ang
            val an = ValueAnimator.ofFloat(0f, 1f)
            an.duration = du; an.interpolator = android.view.animation.LinearInterpolator()
            an.addUpdateListener { a ->
                val t = a.animatedValue as Float
                var k = 0
                while (k < off.size - 2 && t > off[k + 1]) k++
                val p = ease.getInterpolation(((t - off[k]) / (off[k + 1] - off[k])).coerceIn(0f, 1f))
                fun L(a1: FloatArray) = a1[k] + (a1[k + 1] - a1[k]) * p
                v.translationX = from.x - w / 2f + L(fx); v.translationY = from.y - h / 2f + L(fy)
                v.scaleX = L(sc); v.scaleY = L(sc); v.alpha = L(al)
            }
            an.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { box.removeView(v) }
            })
            v.alpha = 0f
            an.start()
        } catch (e: Exception) { }
    }

    /** the trick's cards shrink and fly to the winner, one after the other (takeAway) */
    fun takeAway(views: List<View?>, t: PointF?, dur: Long) {
        if (t == null) return
        views.forEachIndexed { i, v ->
            if (v == null) return@forEachIndexed
            val c = center(v) ?: return@forEachIndexed
            v.animate().translationX(t.x - c.x).translationY(t.y - c.y).scaleX(0.3f).scaleY(0.3f)
                .rotation((i - 1.5f) * 18f).alpha(0f)
                .setStartDelay(i * Math.round(dur / 9.0)).setDuration(dur).setInterpolator(AccelerateInterpolator()).start()
        }
    }

    /** scale/alpha through keyframes (offset, scale, alpha), each piece eased out, like the page's element.animate */
    private fun keyframes(v: View, du: Long, off: FloatArray, sc: FloatArray, al: FloatArray, then: () -> Unit) {
        val ease = PathInterpolator(0f, 0f, 0.58f, 1f)
        val an = ValueAnimator.ofFloat(0f, 1f)
        an.duration = du
        an.interpolator = android.view.animation.LinearInterpolator()
        an.addUpdateListener { a ->
            val t = a.animatedValue as Float
            var k = 0
            while (k < off.size - 2 && t > off[k + 1]) k++
            val p = ease.getInterpolation(((t - off[k]) / (off[k + 1] - off[k])).coerceIn(0f, 1f))
            val s = sc[k] + (sc[k + 1] - sc[k]) * p
            v.scaleX = s; v.scaleY = s; v.alpha = al[k] + (al[k + 1] - al[k]) * p
        }
        an.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) { then() }
        })
        an.start()
    }

    /** the big message at the end of a hand or game (banner); n = win | lose | kwin | klose | fwin | flose */
    fun banner(n: String) {
        if (!::box.isInitialized) return
        val t = BNT[n] ?: return
        val du = Anim.ad(if (Sound.on) (BDU[n] ?: 2300) else if (n == "fwin" || n == "flose") 3300 else 2300).toLong()
        val e = TextView(act)
        e.text = t; e.textSize = 24f; e.setTextColor(0xFFFFE36B.toInt()); e.setTypeface(e.typeface, Typeface.BOLD)
        e.gravity = Gravity.CENTER
        e.setPadding(Px.dp(20), Px.dp(12), Px.dp(20), Px.dp(12))
        e.background = Px.rounded(0xCC000000.toInt(), 16, 2, Px.GOLD)
        e.maxWidth = (act.resources.displayMetrics.widthPixels * 0.9f).toInt()
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        e.alpha = 0f
        box.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.translationY = -act.root.height * 0.12f
        keyframes(e, du, floatArrayOf(0f, 0.18f, 0.82f, 1f), floatArrayOf(0.4f, 1.08f, 1f, 1f), floatArrayOf(0f, 1f, 1f, 0f)) { box.removeView(e) }
    }

    /** the chosen trump suit shown large for a moment (trumpFlash) */
    fun trumpFlash(s: Int) {
        if (!::box.isInitialized) return
        val e = LinearLayout(act)
        e.orientation = LinearLayout.VERTICAL; e.gravity = Gravity.CENTER_HORIZONTAL
        val b = TextView(act)
        b.text = Cards.SU[s]; b.textSize = 92f; b.setTextColor(if (s == 1 || s == 2) 0xFFFF6B6B.toInt() else Color.WHITE)
        b.setTypeface(b.typeface, Typeface.BOLD); b.setShadowLayer(12f, 0f, 2f, Color.BLACK); b.gravity = Gravity.CENTER
        val t = TextView(act)
        t.text = "حکم: " + Cards.SN[s]; t.textSize = 18f; t.setTextColor(Color.WHITE); t.setTypeface(t.typeface, Typeface.BOLD)
        t.setShadowLayer(12f, 0f, 2f, Color.BLACK); t.gravity = Gravity.CENTER
        e.addView(b); e.addView(t)
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        e.alpha = 0f
        box.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.translationY = -act.root.height * 0.10f
        keyframes(e, Anim.ad(1400).toLong(), floatArrayOf(0f, 0.25f, 0.8f, 1f), floatArrayOf(0.3f, 1.15f, 1f, 1.3f), floatArrayOf(0f, 1f, 1f, 0f)) { box.removeView(e) }
    }

    // ---------------------------------------------------------------- shuffling

    /** time (ms since epoch) when the shuffle picture ends (ANI.shufEnd) */
    @JvmField var shufEnd = 0L

    /** the shuffle picture: 14 cards riffled together three times (shufVisual) */
    fun shuffle(d: Long) {
        hn++
        if (!::box.isInitialized) { shufEnd = Sched.now() + d + 250; return }
        val T = d + 250
        val panel = FrameLayout(act)
        panel.background = Px.rounded(0x66000000, 16)
        panel.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        val w = Px.dp(46); val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back))
        val N = 14
        val cards = ArrayList<android.widget.ImageView>()
        for (j in 0 until N) {
            val im = android.widget.ImageView(act)
            im.setImageBitmap(bmp); im.adjustViewBounds = true
            panel.addView(im, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
            cards.add(im)
        }
        box.addView(panel, FrameLayout.LayoutParams(Px.dp(190), Px.dp(150), Gravity.CENTER))
        val R = 3; val Rd = T / R.toFloat()
        val ease = PathInterpolator(0.42f, 0f, 0.58f, 1f)
        val an = ValueAnimator.ofFloat(0f, T.toFloat())
        an.duration = T
        an.interpolator = android.view.animation.LinearInterpolator()
        an.addUpdateListener { a ->
            val t = a.animatedValue as Float
            val r = Math.min(R - 1, (t / Rd).toInt()); val u = (t - r * Rd) / Rd
            for (j in 0 until N) {
                val sd = if (j % 2 == 1) 1 else -1
                val e1 = Math.min(0.95f, 0.5f + j * 0.03f); val m1 = Math.min(0.9f, e1 - 0.2f)
                // key positions: centre, apart, apart, centre, centre at offsets 0, .22, m1, e1, 1
                val off = floatArrayOf(0f, 0.22f, m1, e1, 1f); val ap = floatArrayOf(0f, 1f, 1f, 0f, 0f)
                var k = 0
                while (k < 3 && u > off[k + 1]) k++
                val seg = (off[k + 1] - off[k]).let { if (it <= 0f) 1f else it }
                val p = ease.getInterpolation(((u - off[k]) / seg).coerceIn(0f, 1f))
                val f = ap[k] + (ap[k + 1] - ap[k]) * p
                cards[j].translationX = Px.dp(sd * 52).toFloat() * f
                cards[j].translationY = (-(j shr 1) * f - j * 0.8f * (1f - f)) * Px.d
                cards[j].rotation = sd * -6f * f
            }
        }
        an.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                panel.animate().alpha(0f).setDuration(280).withEndAction { box.removeView(panel) }.start()
            }
        })
        shufEnd = Sched.now() + T
        an.start()
    }

    /** runs [snd] (which starts the shuffle sound) and calls [cb] when the shuffle picture is over (shufThen) */
    fun shufThen(snd: () -> Unit, cb: () -> Unit) {
        val g = Sched.GEN
        shufEnd = 0
        snd()
        var k = 0
        fun w() {
            if (g != Sched.GEN) return
            if ((shufEnd != 0L && Sched.now() >= shufEnd) || ++k > 130) { cb(); return }
            Sched.laterRaw(60) { w() }
        }
        w()
    }

    // ---------------------------------------------------------------- the draw for hakem (drawScene)

    /**
     * Cards are dealt one by one, face up, until the first ace (the hakem) and, in a four-player game, the second ace
     * to somebody else (his partner); then the seats move so the partner sits across. names[r] = who sits at seat r
     * (r = 0 is you, 1 left, 2 across, 3 right; with two players 0 and 1). cb is called when the scene is over.
     */
    fun drawScene(D: Draw.D, names: List<String>, cb: (() -> Unit)?, fx: Double?, sayf: ((String, Boolean) -> Unit)?) {
        val g = Sched.GEN
        val f = fx ?: Anim.f
        val A = { ms: Int -> Math.round(ms * f).toInt() }
        val n = D.n
        val pos = { r: Int -> if (n == 2) (if (r == 0) 0 else 2) else r }
        val lab = names.map { Av.clean(it) }
        val ids = names.map { if (Av.clean(it) == "شما") Av.me() else Av.clean(it) }
        if (!::box.isInitialized) { cb?.invoke(); return }
        val o = FrameLayout(act)
        o.setBackgroundColor(0x99000000.toInt()); o.isClickable = true
        o.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        val dm = act.resources.displayMetrics
        val bx = FrameLayout(act)
        bx.background = Px.rounded(Px.FELT, 16)
        o.addView(bx, FrameLayout.LayoutParams(Math.min((dm.widthPixels * 0.92f).toInt(), Px.dp(400)), Math.min((dm.heightPixels * 0.76f).toInt(), Px.dp(460)), Gravity.CENTER))
        box.addView(o, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val ti = TextView(act)
        ti.text = "تعیین حاکم: اولین آس"; ti.textSize = 15f; ti.setTextColor(Color.WHITE); ti.setTypeface(ti.typeface, Typeface.BOLD)
        ti.gravity = Gravity.CENTER; ti.setShadowLayer(4f, 0f, 1f, Color.BLACK)
        bx.addView(ti, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).also { it.topMargin = Px.dp(46) * 2 })
        // the deck in the middle
        val dk = FrameLayout(act)
        val back = Assets.bitmap(act, Assets.backPath(Prefs.back))
        for (i in 0 until 4) {
            val im = android.widget.ImageView(act); im.setImageBitmap(back); im.adjustViewBounds = true
            dk.addView(im, FrameLayout.LayoutParams(Px.dp(46), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = Px.dp(i); it.topMargin = -Px.dp(1.5f * i) })
        }
        bx.addView(dk, FrameLayout.LayoutParams(Px.dp(50), Px.dp(70), Gravity.CENTER))
        // the seats
        val Z = ArrayList<FrameLayout>(); val Lb = ArrayList<TextView>(); val moods = ArrayList<(String) -> Unit>(); val SW = ArrayList<LinearLayout>()
        for (r in 0 until n) {
            val w = LinearLayout(act); w.orientation = LinearLayout.VERTICAL; w.gravity = Gravity.CENTER_HORIZONTAL
            val si = LinearLayout(act); si.orientation = LinearLayout.VERTICAL; si.gravity = Gravity.CENTER_HORIZONTAL
            val (av, setM) = Av.viewMood(act, ids[r], 46, "wait")
            si.addView(av, LinearLayout.LayoutParams(Px.dp(46), Px.dp(46)))
            val l = TextView(act)
            l.text = lab[r]; l.textSize = 12f; l.setTextColor(Color.WHITE)
            l.background = Px.rounded(0x66000000, 9); l.setPadding(Px.dp(8), Px.dp(2), Px.dp(8), Px.dp(2))
            si.addView(l, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(2) })
            val z = FrameLayout(act)
            val zl = LinearLayout.LayoutParams(Px.dp(52), Px.dp(74)); zl.gravity = Gravity.CENTER_HORIZONTAL
            if (pos(r) == 0) { w.addView(z, zl); w.addView(si) } else { w.addView(si); w.addView(z, zl) }
            val gv = when (pos(r)) {
                0 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                1 -> Gravity.LEFT or Gravity.CENTER_VERTICAL
                else -> Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            bx.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, gv).also { it.setMargins(Px.dp(4), Px.dp(4), Px.dp(4), Px.dp(4)) })
            Z.add(z); Lb.add(l); moods.add(setM); SW.add(w)
        }
        val say_ = { t: String, min: Int ->
            try {
                if (sayf != null) {
                    val d = Spk.slot(t, min.toLong())
                    if (d > 0) Sched.laterRaw(d) { if (g == Sched.GEN) sayf(t, false) } else sayf(t, false)
                }
            } catch (e: Exception) { }
        }
        val hold = { ms: Int -> Math.max(ms.toLong(), Spk.end - Sched.now()) }
        say_("تعیین حاکم.", 0)
        var i = 0
        fun toss(x: TP): View {
            val ox = Math.round((Math.random() - 0.5) * 12).toFloat(); val oy = Math.round((Math.random() - 0.5) * 8).toFloat(); val rot = Math.round((Math.random() - 0.5) * 22).toFloat()
            val c = FrameLayout(act)
            val im = android.widget.ImageView(act); im.setImageBitmap(Assets.bitmap(act, Assets.cardPath(x.c))); im.adjustViewBounds = true
            c.addView(im, FrameLayout.LayoutParams(Px.dp(52), ViewGroup.LayoutParams.WRAP_CONTENT))
            Z[x.p].addView(c, FrameLayout.LayoutParams(Px.dp(52), ViewGroup.LayoutParams.WRAP_CONTENT))
            c.translationX = Px.dp(ox).toFloat(); c.translationY = Px.dp(oy).toFloat(); c.rotation = rot
            c.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    if (c.viewTreeObserver.isAlive) c.viewTreeObserver.removeOnPreDrawListener(this)
                    val a = center(c); val k = center(dk)
                    if (a != null && k != null) {
                        val dx = k.x - (a.x - c.translationX); val dy = k.y - (a.y - c.translationY)
                        val tx = c.translationX; val ty = c.translationY
                        c.translationX = tx + dx; c.translationY = ty + dy; c.rotation = -rot * 2; c.scaleX = 0.85f; c.scaleY = 0.85f
                        c.animate().translationX(tx).translationY(ty).rotation(rot).scaleX(1f).scaleY(1f).setDuration(A(340).toLong())
                            .setInterpolator(PathInterpolator(0.2f, 0.8f, 0.2f, 1f)).start()
                    }
                    return true
                }
            })
            Sched.laterRaw(Math.max(0, A(340) - Sound.CSO).toLong()) { Sound.cardSnd() }
            return c
        }
        fun mark(r: Int, h: Boolean, ic: String) { Lb[r].text = ic + " " + lab[r]; Lb[r].setTextColor(if (h) 0xFFFFE36B.toInt() else 0xFF9BE7FF.toInt()) }
        fun ace(c: View) { c.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD) }
        fun close() {
            if (g != Sched.GEN) { box.removeView(o); return }
            Av.set(ids[D.h], "joy", 3500)
            if (n == 4 && D.pt != null) Av.set(ids[D.pt], "happy", 3500)
            o.animate().alpha(0f).setDuration(A(280).toLong()).withEndAction { box.removeView(o); cb?.invoke() }.start()
        }
        fun fin() {
            val moves = ArrayList<Pair<Int, Int>>()
            if (n == 4) for (r in 0 until 4) if (D.mv[r] != r) moves.add(Pair(r, D.mv[r]))
            val hm = lab[D.h] == "شما"; val hp = n == 4 && D.pt != null; val pm = hp && lab[D.pt!!] == "شما"
            val t = (if (hm) "شما حاکم شدید" else lab[D.h] + " حاکم شد") +
                (if (hp) (if (hm) " و " + lab[D.pt!!] + " یار شماست" else if (pm) " و شما یار او هستید" else " و " + lab[D.pt!!] + " یار اوست") else "") + "."
            ti.text = t
            try { sayf?.invoke(t, true) } catch (e: Exception) { }
            if (moves.isNotEmpty()) {
                Sched.laterRaw(hold(A(1200))) {
                    if (g != Sched.GEN) { box.removeView(o); return@laterRaw }
                    ti.text = "صندلی‌ها جابه‌جا می‌شوند تا یار روبه‌روی حاکم بنشیند"
                    for ((r, t2) in moves) {
                        val a = center(SW[r]); val b = center(SW[t2])
                        if (a != null && b != null) SW[r].animate().translationX(b.x - a.x).translationY(b.y - a.y).setDuration(A(1000).toLong())
                            .setInterpolator(PathInterpolator(0.42f, 0f, 0.58f, 1f)).start()
                    }
                    Sched.laterRaw(hold(A(1000) + A(900))) { close() }
                }
            } else Sched.laterRaw(hold(if (n == 2) A(350) else A(950))) { close() }
        }
        fun step() {
            if (g != Sched.GEN) { box.removeView(o); return }
            if (i >= D.seq.size) { fin(); return }
            val idx = i; val x = D.seq[i]; i++
            val c = toss(x)
            if (idx == D.i1 || idx == D.i2) {
                val hm_ = lab[D.h] == "شما"; val pm_ = n == 4 && D.pt != null && lab[D.pt!!] == "شما"
                say_(if (idx == D.i1) (if (hm_) "شما حاکم شدید." else lab[D.h] + " حاکم شد.")
                else (if (hm_) lab[D.pt!!] + " یار شماست." else if (pm_) "شما یار او هستید." else lab[D.pt!!] + " یار اوست."), Math.max(0, A(340) - Sound.CSO))
            }
            if (idx == D.i1) {
                Sched.laterRaw(A(340).toLong()) {
                    ace(c); mark(x.p, true, "👑"); moods[x.p]("joy")
                    if (n == 2 || D.pt == null) { for (r in 0 until n) if (r != x.p) moods[r]("sad") } else ti.text = "حالا دومین آس: یار حاکم"
                    Sched.laterRaw(hold((if (n == 2) A(500) else A(1100)) - A(340))) { step() }
                }
                return
            }
            if (idx == D.i2) {
                Sched.laterRaw(A(340).toLong()) {
                    ace(c); mark(x.p, false, "🤝"); moods[x.p]("happy")
                    for (r in 0 until 4) if (r != x.p && r != D.h) moods[r]("sad")
                    Sched.laterRaw(hold(A(950) - A(340))) { step() }
                }
                return
            }
            Sched.laterRaw((if (idx < 5) A(380) else A(230)).toLong()) { step() }
        }
        Sched.laterRaw(A(250).toLong()) { step() }
    }

    // ---------------------------------------------------------------- partners hugging at the end of a game (avHug)

    fun bduOf(n: String): Int = BDU[n] ?: 3400

    /** several values moving through keyframes; each piece eased with [ease] (like element.animate with an easing) */
    private fun kfAnim(du: Long, off: FloatArray, props: Array<FloatArray>, ease: android.view.animation.Interpolator?, upd: (FloatArray) -> Unit) {
        val an = ValueAnimator.ofFloat(0f, 1f)
        an.duration = du
        an.interpolator = android.view.animation.LinearInterpolator()
        val out = FloatArray(props.size)
        an.addUpdateListener { a ->
            val t = a.animatedValue as Float
            var k = 0
            while (k < off.size - 2 && t > off[k + 1]) k++
            val seg = off[k + 1] - off[k]
            var p = if (seg <= 0f) 1f else ((t - off[k]) / seg).coerceIn(0f, 1f)
            if (ease != null) p = ease.getInterpolation(p)
            for (j in props.indices) out[j] = props[j][k] + (props[j][k + 1] - props[j][k]) * p
            upd(out)
        }
        an.start()
    }

    /** the two arms drawn across the screen between the hugging partners */
    private class Arms(ctx: android.content.Context, val sz: Float, val T: Array<PointF>, val mid: PointF, val ux: Float, val uy: Float,
                       val nx: Float, val ny: Float, val names: List<String>) : View(ctx) {
        private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: android.graphics.Canvas) {
            for (i in 0..1) {
                val A = T[i]; val B = T[1 - i]; val P = Av.ident(names[i]); val dir = if (i == 0) 1f else -1f
                val s1 = PointF(A.x + nx * sz * 0.46f, A.y + ny * sz * 0.46f)
                val e1 = PointF(B.x + nx * sz * 0.40f - ux * dir * sz * 0.22f, B.y + ny * sz * 0.40f - uy * dir * sz * 0.22f)
                val c1 = PointF(mid.x + nx * sz * 0.78f, mid.y + ny * sz * 0.78f)
                val t = 0.55f
                val sp = PointF((1 - t) * (1 - t) * s1.x + 2 * (1 - t) * t * c1.x + t * t * e1.x, (1 - t) * (1 - t) * s1.y + 2 * (1 - t) * t * c1.y + t * t * e1.y)
                val cA = PointF(s1.x + (c1.x - s1.x) * t, s1.y + (c1.y - s1.y) * t)
                val cB = PointF(c1.x + (e1.x - c1.x) * t, c1.y + (e1.y - c1.y) * t)
                fun q(a: PointF, b: PointF, d: PointF, col: String, w: Float) {
                    p.style = android.graphics.Paint.Style.STROKE; p.color = Color.parseColor(col); p.strokeWidth = w; p.strokeCap = android.graphics.Paint.Cap.ROUND
                    val path = android.graphics.Path(); path.moveTo(a.x, a.y); path.quadTo(b.x, b.y, d.x, d.y); c.drawPath(path, p)
                }
                q(s1, cA, sp, P.sh, sz * 0.2f); q(sp, cB, e1, P.sk, sz * 0.16f)
                p.style = android.graphics.Paint.Style.FILL; p.color = Color.parseColor(P.sk); c.drawCircle(e1.x, e1.y, sz * 0.1f, p)
            }
        }
    }

    /** the two partners (pair) walk to a free spot, hug for [D] ms and walk back; kind = "win" | "lose" */
    fun hug(pair: List<String>, kind: String, D: Int) {
        try {
            if (!::box.isInitialized || pair.size != 2 || pair[0] == pair[1]) return
            val els = pair.map { Av.findView(it) }
            if (els.any { it == null } || els[0] === els[1]) return
            val v0 = els[0]!!; val v1 = els[1]!!
            val C = arrayOf(center(v0) ?: return, center(v1) ?: return)
            val W = floatArrayOf(v0.width.toFloat(), v1.width.toFloat())
            val sz = Math.round(Math.max(W[0], W[1]) * 1.2f).toFloat()
            val win = kind == "win"
            var ux = C[1].x - C[0].x; var uy = C[1].y - C[0].y
            val dist = Math.hypot(ux.toDouble(), uy.toDouble()).toFloat().let { if (it == 0f) 1f else it }
            ux /= dist; uy /= dist
            val iw = act.root.width.toFloat(); val ih = act.root.height.toFloat()
            val mid = PointF((C[0].x + C[1].x) / 2, (C[0].y + C[1].y) / 2); val sep = sz * 0.74f
            if (Math.abs(uy) > Math.abs(ux)) mid.x -= Math.min(iw * 0.26f, sz * 2.6f) else mid.y = Math.min(ih - sz, mid.y + Math.min(ih * 0.11f, sz * 2))
            val T = arrayOf(PointF(mid.x - ux * sep / 2, mid.y - uy * sep / 2), PointF(mid.x + ux * sep / 2, mid.y + uy * sep / 2))
            var nx = -uy; var ny = ux
            if (ny < 0) { nx = -nx; ny = -ny }
            val made = ArrayList<View>()
            val lean = if (Math.abs(ux) >= Math.abs(uy)) floatArrayOf(if (ux > 0) 11f else -11f, if (ux > 0) -11f else 11f) else floatArrayOf(8f, -8f)
            val mood0 = if (win) "joy" else "sad"
            val px = Math.round(sz)
            val cl = ArrayList<android.widget.ImageView>()
            val boxes = ArrayList<FrameLayout>()
            for (i in 0..1) {
                val im = android.widget.ImageView(act); im.setImageBitmap(Av.faceBitmap(pair[i], mood0, px))
                val e = FrameLayout(act)
                e.addView(im, FrameLayout.LayoutParams(px, px))
                e.clipToOutline = true
                e.outlineProvider = object : android.view.ViewOutlineProvider() { override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) } }
                e.background = android.graphics.drawable.GradientDrawable().also { it.shape = android.graphics.drawable.GradientDrawable.OVAL; it.setColor(Color.WHITE); it.setStroke(Px.dp(2), 0x66000000) }
                e.elevation = Px.dp(4).toFloat()
                e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                box.addView(e, FrameLayout.LayoutParams(px, px)); made.add(e); cl.add(im); boxes.add(e)
            }
            val arms = Arms(act, sz, T, mid, ux, uy, nx, ny, pair)
            arms.alpha = 0f
            box.addView(arms, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); made.add(arms)
            val ease = PathInterpolator(0.42f, 0f, 0.58f, 1f)
            val du = D.toLong()
            for (i in 0..1) {
                val o = lean[i]; val s0 = W[i] / sz
                val xs = floatArrayOf(C[i].x, T[i].x, T[i].x, T[i].x, T[i].x, T[i].x, T[i].x, C[i].x)
                val ys = floatArrayOf(C[i].y, T[i].y, T[i].y, T[i].y, T[i].y, T[i].y, T[i].y, C[i].y)
                val rs = floatArrayOf(0f, 0f, o, o * 0.5f, o, o * 0.5f, o, 0f)
                val ss = floatArrayOf(s0, 1f, 1.05f, 1.11f, 1.05f, 1.11f, 1.06f, s0)
                val off = floatArrayOf(0f, 0.2f, 0.28f, 0.42f, 0.56f, 0.7f, 0.86f, 1f)
                val e = boxes[i]
                e.pivotX = sz / 2; e.pivotY = sz / 2
                kfAnim(du, off, arrayOf(xs, ys, rs, ss), ease) { v ->
                    e.translationX = v[0] - sz / 2; e.translationY = v[1] - sz / 2; e.rotation = v[2]; e.scaleX = v[3]; e.scaleY = v[3]
                }
            }
            kfAnim(du, floatArrayOf(0f, 0.2f, 0.28f, 0.84f, 0.9f, 1f), arrayOf(floatArrayOf(0f, 0f, 1f, 1f, 0f, 0f)), null) { v -> arms.alpha = v[0] }
            els.forEach { it!!.visibility = View.INVISIBLE }
            fun fl(txt: String, x: Float, y: Float, big: Boolean, dur: Long) {
                val t = TextView(act)
                t.text = txt; t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, if (big) Math.round(sz * 0.9f).toFloat() else Math.round(sz * 0.5f).toFloat())
                t.includeFontPadding = false
                t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                box.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)); made.add(t)
                val x2 = x + ((Math.random() - 0.5) * sz * 0.5).toFloat()
                kfAnim(dur, floatArrayOf(0f, 0.25f, 1f), arrayOf(floatArrayOf(x, x, x2), floatArrayOf(y, y - sz * 0.3f, y - sz * 1.5f),
                    floatArrayOf(0.4f, 1.15f, 1f), floatArrayOf(0f, 1f, 0f)), PathInterpolator(0f, 0f, 0.58f, 1f)) { v ->
                    t.translationX = v[0]; t.translationY = v[1]; t.scaleX = v[2]; t.scaleY = v[2]; t.alpha = v[3]
                }
            }
            val g = Math.max(250.0, D * 0.07)
            if (win) {
                Sched.laterRaw((D * 0.34).toLong()) { fl("💋", mid.x - sz * 0.35f, mid.y - sz * 0.2f, true, 1500) }
                for (k in 0 until 7) Sched.laterRaw((D * 0.3 + k * g * 1.1).toLong()) {
                    fl(listOf("❤️", "💖", "✨", "💕")[k % 4], mid.x + ((Math.random() - 0.5) * sz * 1.3).toFloat(), mid.y - sz * 0.5f, false, 1200)
                }
            } else {
                for (i in 0..1) {
                    val hd = android.widget.ImageView(act); val hb = Av.handBitmap(pair[i]); hd.setImageBitmap(hb)
                    hd.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    hd.alpha = 0f
                    box.addView(hd, FrameLayout.LayoutParams(hb.width, hb.height)); made.add(hd)
                    hd.pivotX = hb.width / 2f; hd.pivotY = hb.height.toFloat()
                    val B = T[1 - i]; val hx = B.x + nx * sz * 0.5f - 17 * Px.d; val hy = B.y + ny * sz * 0.5f - 30 * Px.d
                    val d5 = 5 * Px.d
                    val off = floatArrayOf(0f, 0.3f, 0.34f, 0.42f, 0.5f, 0.58f, 0.66f, 0.74f, 0.8f, 0.86f, 1f)
                    val yy = floatArrayOf(hy, hy, hy, hy + d5, hy, hy + d5, hy, hy + d5, hy, hy, hy)
                    val rr = floatArrayOf(-18f, -18f, -18f, 10f, -18f, 10f, -18f, 10f, -18f, -18f, -18f)
                    val oo = floatArrayOf(0f, 0f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 0f, 0f)
                    kfAnim(du, off, arrayOf(FloatArray(11) { hx }, yy, rr, oo), ease) { v ->
                        hd.translationX = v[0]; hd.translationY = v[1]; hd.rotation = v[2]; hd.alpha = v[3]
                    }
                }
                for (k in 0 until 4) Sched.laterRaw((D * 0.36 + k * g * 1.4).toLong()) {
                    fl(listOf("💙", "🤍")[k % 2], mid.x + ((Math.random() - 0.5) * sz * 1.1).toFloat(), mid.y - sz * 0.5f, false, 1400)
                }
                Sched.laterRaw((D * 0.55).toLong()) { for (i in 0..1) { try { cl[i].setImageBitmap(Av.faceBitmap(pair[i], "happy", px)) } catch (e: Exception) { } } }
            }
            Sched.laterRaw(du + 120) {
                made.forEach { try { box.removeView(it) } catch (e: Exception) { } }
                els.forEach { try { it!!.visibility = View.VISIBLE } catch (e: Exception) { } }
            }
        } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- cards put aside (asideCards)

    /** one card that flies to the pile: it may first appear in the middle (mid) and be shown for [hold] ms */
    class AItem(val src: Card?, val from: PointF?, val mid: PointF?, val hold: Int, val fly: Int, val delay: Int, val w: Float)

    /** the cards fly one after another to [to] and shrink into the pile; returns the total time (ms) */
    fun asideCards(items: List<AItem>, to: PointF): Long {
        var tot = 0L
        items.forEachIndexed { i, it ->
            val w = it.w; val h = Math.round(w * 1.46f)
            val dl0 = it.delay.toLong()
            val ap = if (it.mid != null) Anim.ad(260).toLong() else 0L
            val ho = if (it.mid != null) Anim.ad(it.hold).toLong() else 0L
            val fl = Anim.ad(it.fly).toLong()
            val T = ap + ho + fl + Anim.ad(160)
            tot = Math.max(tot, dl0 + T)
            val es = Math.min(0.8f, Px.dp(44) / w)
            Sched.laterRaw(Math.max(0L, dl0 + ap + ho + fl - Sound.CSO)) { Sound.cardSnd() }
            val st = it.mid ?: it.from
            if (st == null || !::box.isInitialized) return@forEachIndexed
            val d = FrameLayout(act)
            d.alpha = 0f
            d.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            fun mk(bmp: android.graphics.Bitmap?): android.widget.ImageView {
                val im = android.widget.ImageView(act); im.setImageBitmap(bmp); im.scaleType = android.widget.ImageView.ScaleType.FIT_XY
                d.addView(im, FrameLayout.LayoutParams(Math.round(w), h)); return im
            }
            val bk = mk(Assets.bitmap(act, Assets.backPath(Prefs.back)))
            val fr = if (it.src != null) mk(Assets.bitmap(act, Assets.cardPath(it.src))) else null
            box.addView(d, FrameLayout.LayoutParams(Math.round(w), h))
            d.pivotX = w / 2f; d.pivotY = h / 2f
            val rot = (if (i == 1) 1f else -1f) * 12f
            val tF = (ap + ho).toFloat() / T; val tL = (ap + ho + fl).toFloat() / T
            val ease = PathInterpolator(0.42f, 0f, 0.58f, 1f)
            val off: FloatArray; val xs: FloatArray; val ys: FloatArray; val ss: FloatArray; val rs: FloatArray; val os: FloatArray
            if (it.mid != null) {
                off = floatArrayOf(0f, ap.toFloat() / T, tF, tL, 1f)
                xs = floatArrayOf(st.x, st.x, st.x, to.x, to.x); ys = floatArrayOf(st.y, st.y, st.y, to.y, to.y)
                ss = floatArrayOf(0.5f, 1.1f, 1f, es, es); rs = floatArrayOf(0f, 0f, 0f, rot, rot); os = floatArrayOf(0f, 1f, 1f, 1f, 0f)
            } else {
                off = floatArrayOf(0f, tL, 1f)
                xs = floatArrayOf(st.x, to.x, to.x); ys = floatArrayOf(st.y, to.y, to.y)
                ss = floatArrayOf(1f, es, es); rs = floatArrayOf(0f, rot, rot); os = floatArrayOf(1f, 1f, 0f)
            }
            Sched.laterRaw(dl0) {
                kfAnim(T, off, arrayOf(xs, ys, ss, rs, os), ease) { v ->
                    d.translationX = v[0] - w / 2; d.translationY = v[1] - h / 2; d.scaleX = v[2]; d.scaleY = v[2]; d.rotation = v[3]; d.alpha = v[4]
                }
                if (fr != null) {
                    val tf = Math.min(0.98f, tF + (fl * 0.4f) / T)
                    kfAnim(T, floatArrayOf(0f, tF, tf, 1f), arrayOf(floatArrayOf(1f, 1f, 0f, 0f)), null) { v -> fr.alpha = v[0] }
                    kfAnim(T, floatArrayOf(0f, tF, tf, 1f), arrayOf(floatArrayOf(0f, 0f, 1f, 1f)), null) { v -> bk.alpha = v[0] }
                }
            }
            Sched.laterRaw(dl0 + T + 150) { try { box.removeView(d) } catch (e: Exception) { } }
        }
        return tot
    }

    // ---------------------------------------------------------------- two-player drawing: where the two cards go (pickRun)

    /** end of the drawing animation (ANI.pkEnd): the game waits for it before the next step */
    @JvmField var pkEnd = 0L

    /**
     * Two cards are shown for a moment where they were offered, then the taken one flies to [to] (its place in the hand,
     * or the opponent's cards) and the other to the pile. [faces] = pictures of the two cards, [from]/[fw] = where they
     * start and how wide they are, [toW]/[pileW] = width of the places they go to. land0/land1 are called when each lands.
     */
    fun pickRun(faces: List<android.graphics.Bitmap?>, from: List<PointF>, fw: List<Float>, to: PointF, toW: Float,
                pile: PointF, pileW: Float, land0: () -> Unit, land1: () -> Unit) {
        val now = Sched.now()
        val ho = Anim.ad(500).toLong(); val fl = Anim.ad(600).toLong(); val gap = Anim.ad(420).toLong()
        val T = ho + fl + Anim.ad(120); val total = gap + T
        pkEnd = now + total
        val dst = listOf(to, pile); val dw = listOf(toW, pileW)
        for (i in 0..1) {
            val f = from[i]
            val w = Math.max(Px.dp(40).toFloat(), Math.min(Px.dp(72).toFloat(), fw[i]))
            val h = Math.round(w * 1.46f)
            val dl0 = i * gap; val d = dst[i]
            val sc = Math.min(1f, dw[i] / w)
            val el = FrameLayout(act)
            el.alpha = 0f
            el.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            val im = android.widget.ImageView(act); im.setImageBitmap(faces[i]); im.scaleType = android.widget.ImageView.ScaleType.FIT_XY
            el.addView(im, FrameLayout.LayoutParams(Math.round(w), h))
            if (::box.isInitialized) box.addView(el, FrameLayout.LayoutParams(Math.round(w), h))
            el.pivotX = w / 2f; el.pivotY = h / 2f
            val tH = ho.toFloat() / T; val tL = (ho + fl).toFloat() / T
            val rot = if (i == 1) (if (Math.random() < 0.5) -10f else 10f) else 0f
            val s2 = if (i == 1) sc else 1f
            val off = floatArrayOf(0f, tH * 0.45f, tH, tL, 1f)
            val xs = floatArrayOf(f.x, f.x, f.x, d.x, d.x); val ys = floatArrayOf(f.y, f.y, f.y, d.y, d.y)
            val ss = floatArrayOf(1f, 1.12f, 1.12f, s2, s2); val rs = floatArrayOf(0f, 0f, 0f, rot, 0f); val os = floatArrayOf(1f, 1f, 1f, 1f, 0f)
            val ease = PathInterpolator(0.42f, 0f, 0.58f, 1f)
            Sched.laterRaw(dl0) {
                kfAnim(T, off, arrayOf(xs, ys, ss, rs, os), ease) { v ->
                    el.translationX = v[0] - w / 2; el.translationY = v[1] - h / 2; el.scaleX = v[2]; el.scaleY = v[2]; el.rotation = v[3]; el.alpha = v[4]
                }
            }
            Sched.laterRaw(Math.max(0L, dl0 + ho + fl - Sound.CSO)) { Sound.cardSnd() }
            Sched.laterRaw(dl0 + ho + fl) { if (i == 0) land0() else land1() }
            Sched.laterRaw(dl0 + T + 150) { try { box.removeView(el) } catch (e: Exception) { } }
        }
    }

    fun clear() { if (::box.isInitialized) box.removeAllViews() }
}
