package com.example.hokm

import com.example.hokm.Cards.shuf

/** The draw that decides the first hakem (first ace) and his partner (second ace to another player). */
object Draw {
    class D(
        @JvmField val n: Int, @JvmField val seq: List<TP>, @JvmField val h: Int, @JvmField val pt: Int?,
        @JvmField val i1: Int, @JvmField val i2: Int, @JvmField val mv: IntArray
    )

    fun reseatPlan(h: Int, a: Int): IntArray {
        if ((h + 2) % 4 == a) return intArrayOf(0, 1, 2, 3)
        var best = intArrayOf(0, 1, 2, 3); var bc = 9
        val qs = listOf(intArrayOf(1, 2, 3), intArrayOf(1, 3, 2), intArrayOf(2, 1, 3), intArrayOf(2, 3, 1), intArrayOf(3, 1, 2), intArrayOf(3, 2, 1))
        for (q in qs) {
            val to = intArrayOf(0, q[0], q[1], q[2])
            if ((to[h] + 2) % 4 == to[a]) {
                var c = 0
                for (o in 0 until 4) if (to[o] != o) c++
                if (c < bc || (c == bc && Math.random() < 0.5)) { bc = c; best = to }
            }
        }
        return best
    }

    fun genDraw(n: Int, pd: Boolean): D {
        val wp = pd
        for (tr in 0 until 200) {
            val d = ArrayList<Card>()
            for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
            shuf(d)
            val st = Math.floor(Math.random() * n).toInt(); val ia = ArrayList<Int>()
            d.forEachIndexed { i, c -> if (c.r == 14) ia.add(i) }
            val own = { i: Int -> (st + i) % n }
            val h = own(ia[0])
            var k2 = -1
            if (n == 4 && wp) for (k in 1 until ia.size) if (own(ia[k]) != h) { k2 = k; break }
            if (n == 4 && wp && k2 < 0) continue
            val pp = n == 4 && wp
            val end = if (pp) ia[k2] else ia[0]
            val seq = d.subList(0, end + 1).mapIndexed { i, c -> TP(own(i), c) }
            val pt = if (pp) own(ia[k2]) else null
            return D(n, seq, h, pt, ia[0], if (pp) ia[k2] else -1,
                if (n == 4) (if (pp) reseatPlan(h, pt!!) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
        }
        val wp2 = n == 4 && wp
        return D(n, listOf(TP(0, Card(0, 14))) + (if (wp2) listOf(TP(1, Card(1, 14))) else listOf()), 0,
            if (wp2) 1 else null, 0, if (wp2) 1 else -1,
            if (n == 4) (if (wp) reseatPlan(0, 1) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
    }

    /** the text the draw scene announces when it ends */
    fun describe(D: D, lab: List<String>): String {
        val hm = lab[D.h] == "شما"
        val hp = D.n == 4 && D.pt != null
        val pm = hp && lab[D.pt!!] == "شما"
        return (if (hm) "شما حاکم شدید" else lab[D.h].replace(" (یار)", "") + " حاکم شد") +
            (if (hp) (if (hm) " و " + lab[D.pt!!].replace(" (یار)", "") + " یار شماست" else if (pm) " و شما یار او هستید"
            else " و " + lab[D.pt!!].replace(" (یار)", "") + " یار اوست") else "") + "."
    }
}
