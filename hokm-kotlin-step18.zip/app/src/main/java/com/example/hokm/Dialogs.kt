package com.example.hokm

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import com.example.hokm.Cards.fa

/** The pop-up boxes of the page (confirm, list, sound, card/table look, name, help, about). */
class Dialogs(private val act: MainActivity) {

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    /** a rounded box on a dimmed screen; [content] is its body */
    private fun show(content: View, maxW: Int = 300, onCancel: (() -> Unit)? = null): Dialog {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val sv = ScrollView(act)
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Px.dp(24), Px.dp(20), Px.dp(24), Px.dp(20))
        box.background = Px.rounded(Px.bg, 14)
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.addView(content)
        sv.addView(box)
        d.setContentView(sv)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setDimAmount(0.6f)
            setLayout(Math.min(Px.dp(maxW + 48), (act.resources.displayMetrics.widthPixels * 0.92f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.setOnCancelListener { onCancel?.invoke() }
        d.show()
        return d
    }

    fun text(t: String, size: Float = 17f, bold: Boolean = false, center: Boolean = true): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = size
        v.setTextColor(Px.tx)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.gravity = if (center) Gravity.CENTER else Gravity.START
        return v
    }

    /** the green rounded button of the page */
    fun btn(t: String, full: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(act)
        b.text = t
        b.isAllCaps = false
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.background = Px.rounded(Px.BTN, 10)
        b.stateListAnimator = null
        b.minHeight = 0; b.minimumHeight = 0
        b.setPadding(Px.dp(16), Px.dp(12), Px.dp(16), Px.dp(12))
        val l = lp(if (full) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8))
        l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        b.setOnClickListener { onClick() }
        b.isSoundEffectsEnabled = false
        return b
    }

    // ---- confirm (cfAsk) ----
    fun confirm(t: String, yes: () -> Unit, no: () -> Unit = {}) {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text(t).also { it.setPadding(0, 0, 0, Px.dp(14)) })
        var d: Dialog? = null
        c.addView(btn("بله") { d?.dismiss(); yes() })
        c.addView(btn("خیر") { d?.dismiss(); no() })
        d = show(c, 300) { no() }
    }

    // ---- list of choices (dlg) ----
    fun list(title: String, items: List<Pair<String, () -> Unit>>, ok: String = "انصراف") {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text(title).also { it.setPadding(0, 0, 0, Px.dp(14)) })
        var d: Dialog? = null
        for (it in items) c.addView(btn(it.first) { d?.dismiss(); it.second() })
        c.addView(btn(ok) { d?.dismiss() })
        d = show(c, 300)
    }

    fun message(t: String) {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text(t).also { it.setPadding(0, 0, 0, Px.dp(14)) })
        var d: Dialog? = null
        c.addView(btn("بستن") { d?.dismiss() })
        d = show(c, 300)
    }

    // ---- sound settings ----
    private var sndLabelM: TextView? = null
    private var sndLabelE: TextView? = null
    private var sndBtn: Button? = null
    private var sndBarM: SeekBar? = null
    private var sndBarE: SeekBar? = null

    private fun uiVol() {
        fun f(bar: SeekBar?, lab: TextView?, txt: String, v: Double) {
            if (bar == null || lab == null) return
            val pc = Math.round(v * 100).toInt()
            val t = fa(pc) + " درصد"
            if (bar.progress != pc) bar.progress = pc
            bar.contentDescription = "$txt: $t"
            lab.text = "$txt: $t"
        }
        f(sndBarM, sndLabelM, "صدای آهنگ", Sound.vm)
        f(sndBarE, sndLabelE, "صدای افکت‌ها", Sound.ve)
        sndBtn?.text = "صدا و موسیقی: " + (if (Sound.on) "روشن" else "خاموش")
    }

    private fun bar(label: String, init: Double, onVal: (Double) -> Unit, onDone: (() -> Unit)?, setLab: (TextView) -> Unit): SeekBar {
        val s = SeekBar(act)
        s.max = 100
        s.progress = Math.round(init * 100).toInt()
        s.contentDescription = label
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                if (user) onVal((Math.round(p / 5.0) * 5).toDouble())
            }
            override fun onStartTrackingTouch(sb: SeekBar) { }
            override fun onStopTrackingTouch(sb: SeekBar) { onDone?.invoke() }
        })
        return s
    }

    fun sound() {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text("تنظیمات صدا").also { it.setPadding(0, 0, 0, Px.dp(14)) })
        val mb = btn("") { Sound.toggleMusic() }
        sndBtn = mb
        c.addView(mb)
        val lm = text("", 15f); sndLabelM = lm
        c.addView(lm)
        val bm = bar("صدای آهنگ", Sound.vm, { Sound.setVolM(it) }, null) { }
        sndBarM = bm
        c.addView(bm, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, Px.dp(4), 0, Px.dp(12)) })
        val le = text("", 15f); sndLabelE = le
        c.addView(le)
        val be = bar("صدای افکت‌ها", Sound.ve, { Sound.setVolE(it) }, { Sound.sfx("card") }) { }
        sndBarE = be
        c.addView(be, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, Px.dp(4), 0, Px.dp(12)) })
        var d: Dialog? = null
        c.addView(btn("بستن") { d?.dismiss() })
        Sound.onChange = { uiVol() }
        uiVol()
        d = show(c, 300) { }
        d?.setOnDismissListener { Sound.onChange = null }
    }

    // ---- card back / table background ----
    fun cards(mode: String, onChanged: () -> Unit) {
        val bg = mode == "bg"
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text(if (bg) "تنظیمات تصویر زمینه" else "تنظیمات پشت کارت", 20f, true).also { it.setPadding(0, 0, 0, Px.dp(6)) })
        val grid = FlowLayout(act, Px.dp(3), Px.dp(3))
        c.addView(grid, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        fun opt(label: String, on: Boolean, pic: View?, pick: () -> Unit): View {
            val b = LinearLayout(act)
            b.orientation = LinearLayout.VERTICAL
            b.gravity = Gravity.CENTER
            b.setPadding(Px.dp(4), Px.dp(4), Px.dp(4), Px.dp(4))
            b.minimumWidth = Px.dp(56); b.minimumHeight = Px.dp(44)
            b.background = if (on) Px.rounded(0x44FFD34D, 8, 2, Px.GOLD) else Px.rounded(0x22FFFFFF, 8, 2, Color.TRANSPARENT)
            if (pic != null) b.addView(pic)
            val t = text(label, 12f); t.setTextColor(Px.tx); t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            b.addView(t)
            b.isClickable = true; b.isFocusable = true
            b.contentDescription = label + (if (on) "، انتخاب شده" else "")
            b.setOnClickListener { pick() }
            return b
        }
        fun pic(path: String): View {
            val iv = ImageView(act)
            iv.setImageBitmap(Assets.bitmap(act, path))
            iv.adjustViewBounds = true
            iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            iv.layoutParams = lp(Px.dp(44), ViewGroup.LayoutParams.WRAP_CONTENT)
            return iv
        }
        fun fill() {
            grid.removeAllViews()
            if (!bg) {
                for (i in 1..35) grid.addView(opt("طرح " + fa(i), Prefs.back == i, pic(Assets.backPath(i))) { Prefs.back = i; onChanged(); fill() })
            } else {
                val sw = View(act)
                sw.background = Px.rounded(Px.FELT, 4, 1, 0x88FFFFFF.toInt())
                sw.layoutParams = lp(Px.dp(44), Px.dp(30))
                grid.addView(opt("سبز ساده", Prefs.bg == 0, sw) { Prefs.bg = 0; onChanged(); fill() })
                for (i in 1..4) grid.addView(opt("فرش " + fa(i), Prefs.bg == i, pic(Assets.bgThumb(i))) { Prefs.bg = i; onChanged(); fill() })
            }
        }
        fill()
        var d: Dialog? = null
        c.addView(btn("بستن") { d?.dismiss() })
        d = show(c, 340)
    }

    // ---- name and gender ----
    /** asks the player's name and gender. [cancellable] false = first run (no cancel button). */
    fun nameAsk(cancellable: Boolean, done: (String) -> Unit) {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text("نام شما چیست؟ در بازی با چند گوشی بقیه‌ی بازیکنان همین نام را می‌بینند.").also { it.setPadding(0, 0, 0, Px.dp(14)) })
        val et = EditText(act)
        et.setText(Prefs.name)
        et.filters = arrayOf(InputFilter.LengthFilter(20))
        et.textSize = 16f
        et.setTextColor(Px.tx)
        et.contentDescription = "نام شما"
        et.isSingleLine = true
        c.addView(et)
        c.addView(text("جنسیت شما (برای آدمکی که سر میز برای شما می‌نشیند):", 15f).also { it.setPadding(0, Px.dp(10), 0, 0) })
        val sp = Spinner(act)
        val ad = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("انتخاب کنید", "زن", "مرد"))
        sp.adapter = ad
        sp.setSelection(if (Prefs.gender == "m") 2 else if (Prefs.gender == "f") 1 else 0)
        c.addView(sp)
        val err = text("", 14f); err.setTextColor(0xFFCC0000.toInt())
        c.addView(err)
        var d: Dialog? = null
        c.addView(btn("تأیید") {
            val v = et.text.toString().trim().take(20)
            if (v.isEmpty()) { err.text = "لطفاً نام خود را بنویسید."; return@btn }
            if (sp.selectedItemPosition == 0) { err.text = "لطفاً جنسیت خود را انتخاب کنید."; return@btn }
            Prefs.name = v
            Prefs.gender = if (sp.selectedItemPosition == 2) "m" else "f"
            d?.dismiss(); done(v)
        })
        if (cancellable) c.addView(btn("انصراف") { d?.dismiss() })
        d = show(c, 300) { }
        d?.setCancelable(cancellable)
        et.requestFocus()
    }

    // ---- help ----
    fun guide() {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text("راهنمای بازی", 22f, true, false).also { it.setPadding(0, 0, 0, Px.dp(8)); it.isFocusable = true })
        val netNames = mapOf("bt" to "بلوتوث", "lan" to "وای‌فای (یک شبکهٔ مشترک)", "direct" to "وای‌فای مستقیم")
        val netHints = mapOf(
            "bt" to "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن در تنظیمات بلوتوث نیست.",
            "lan" to "همه‌ی گوشی‌ها باید به یک شبکه‌ی وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها. بعد میزبان بازی را باز می‌کند و بقیه نامش را در فهرست می‌بینند.",
            "direct" to "وای‌فای همه‌ی گوشی‌ها باید روشن و گوشی‌ها نزدیک هم باشند. لازم نیست به مودم یا شبکه‌ای وصل شوید؛ بقیه مستقیم به گوشی میزبان وصل می‌شوند."
        )
        val net = Prefs.net
        val netLine = "روش اتصال فعلی شما: " + netNames[net] + ". " + netHints[net]

        fun section(s: GSec, parent: LinearLayout, indent: Int) {
            val wrap = LinearLayout(act); wrap.orientation = LinearLayout.VERTICAL
            wrap.setPadding(Px.dp(indent), 0, 0, 0)
            val body = LinearLayout(act); body.orientation = LinearLayout.VERTICAL
            body.visibility = View.GONE
            body.setPadding(Px.dp(8), Px.dp(2), Px.dp(8), Px.dp(10))
            val head = TextView(act)
            head.setTextColor(Px.tx); head.textSize = 16f; head.setTypeface(head.typeface, Typeface.BOLD)
            head.setPadding(Px.dp(4), Px.dp(10), Px.dp(4), Px.dp(10))
            fun upd() { head.text = (if (body.visibility == View.VISIBLE) "▾ " else "◂ ") + s.title; head.contentDescription = s.title + (if (body.visibility == View.VISIBLE) "، باز" else "، بسته") }
            head.setOnClickListener { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE; upd() }
            upd()
            wrap.addView(head)
            if (s.title == "روش‌های اتصال") body.addView(text(netLine, 15f, false, false).also { it.setPadding(0, Px.dp(4), 0, Px.dp(4)) })
            for (t in s.body) body.addView(text(t, 15f, false, false).also { it.setPadding(0, Px.dp(4), 0, Px.dp(4)) })
            for (sub in s.subs) section(sub, body, 14)
            wrap.addView(body)
            val line = View(act); line.setBackgroundColor(0x59808080); wrap.addView(line, lp(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            parent.addView(wrap)
        }
        for (s in GuideData.ROOT) section(s, c, 0)
        var d: Dialog? = null
        c.addView(btn("بستن") { d?.dismiss() })
        d = show(c, 340)
    }

    // ---- about ----
    fun about() {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(text("درباره", 22f, true))
        c.addView(text("بازی حکم").also { it.setPadding(0, Px.dp(8), 0, 0) })
        c.addView(text("حکم چهار نفره و دو نفره، با ربات یا با چند گوشی (بلوتوث یا وای‌فای)، قابل استفاده با صفحه‌خوان.").also { it.setPadding(0, Px.dp(8), 0, 0) })
        val v = act.bridge.version()
        c.addView(text(if (v.isNotEmpty()) "نسخهٔ ساخت: $v" else "").also { it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        var d: Dialog? = null
        c.addView(btn("بستن") { d?.dismiss() })
        d = show(c, 300)
    }
}
