package com.example.hokm

/** The screen-reader announcement queue shared by both games (SPKQ / spkSlot of the page). */
object Spk {
    /** time (ms since epoch) when the last queued announcement ends */
    @JvmField var end = 0L
    private var gen = 0

    private fun dur(t: String): Long = Math.max(900, t.length * 50).toLong()

    /** how long to wait before announcing t so that it does not talk over earlier announcements */
    fun slot(t: String, min: Long): Long {
        if (!Prefs.a11y) return min
        if (gen != Sched.GEN) { gen = Sched.GEN; end = 0 }
        val now = Sched.now()
        val at = Math.max(now + min, end)
        end = at + dur(t)
        return at - now
    }

    fun reset() { end = 0 }
}
