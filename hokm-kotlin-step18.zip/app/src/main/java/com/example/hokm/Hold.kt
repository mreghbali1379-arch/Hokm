package com.example.hokm

import org.json.JSONObject

/**
 * "Hold": after a player drops out (a bot takes the seat) the host's game pauses until the host presses
 * "ادامه بازی". Moves that arrive meanwhile are kept and run, in order, after the confirmation
 * (the page's HOLD block: mpHoldStart / mpResume / holdWrap / holdUi).
 */
object Hold {
    private class Held(val k: String, val g: Int, val f: () -> Unit)

    @JvmField var on = false
    @JvmField var txt = ""
    private val q = ArrayList<Held>()

    /** redraws the bar at the bottom of the screen (set by App) */
    var ui: (() -> Unit)? = null

    /** how the game logs its messages after resuming (set by App: log for four players, log2 for two) */
    var logResume: ((String) -> Unit)? = null

    /**
     * Put at the start of a game function. While the game is held: the host's own move (own = true) is ignored,
     * any other call is kept (once per name+args) and run after the confirmation. Returns true when held back.
     */
    fun hold(name: String, args: String, own: Boolean = false, f: () -> Unit): Boolean {
        if (MP.role != "host" || !on) return false
        if (own) { ui?.invoke(); return true }
        val k = "$name:$args"
        if (q.none { it.k == k }) q.add(Held(k, Sched.GEN, f))
        return true
    }

    fun start(t: String) {
        if (MP.role != "host" || !MP.started) return
        val was = on
        on = true
        txt = "$t بازی متوقف است. برای ادامه، دکمه‌ی «ادامه بازی» را بزنید."
        try {
            MP.each { cid, _ -> MP.send(cid, JSONObject().put("t", "hold").put("on", true)
                .put("x", "بازی متوقف است تا میزبان («" + MP.hostName + "») ادامه را تأیید کند.")) }
        } catch (e: Exception) { }
        ui?.invoke()
    }

    fun resume() {
        if (!on) return
        on = false; txt = ""
        val list = ArrayList(q); q.clear()
        ui?.invoke()
        try { MP.each { cid, _ -> MP.send(cid, JSONObject().put("t", "hold").put("on", false)) } } catch (e: Exception) { }
        try { logResume?.invoke("بازی ادامه پیدا کرد.") } catch (e: Exception) { }
        for (h in list) { if (h.g != Sched.GEN) continue; try { h.f() } catch (x: Exception) { } }
    }

    fun clear() { on = false; txt = ""; q.clear(); ui?.invoke() }
}
