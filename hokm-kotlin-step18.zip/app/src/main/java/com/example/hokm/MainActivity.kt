package com.example.hokm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.FrameLayout
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.Priority
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        // Transport: Google Nearby Connections (no Bluetooth pairing needed).
        private const val SERVICE_ID = "com.example.hokm.v1"
        private const val REQ_BT = 7
        private const val REQ_LOC = 8
        private const val REQ_BTON = 9
        private const val REQ_WIFI = 10
        private const val CHUNK = 20000
    }

    private val afterLocation = ArrayList<Runnable>()

    /** Root container of the native game UI (replaces the old WebView). */
    lateinit var root: FrameLayout
        private set

    /** Receives transport events: type, connection id, data (replaces window.btEvt of the page). */
    var btEvt: ((String, Int, String) -> Unit)? = null

    /** The phone's back button: returns true when the game handled it (replaces window.hokmBack). */
    var onBack: (() -> Boolean)? = null

    /** The calls the game makes to the native layer (replaces the AndroidBT JS interface). */
    val bridge = Bridge()

    private var adapter: BluetoothAdapter? = null
    private lateinit var cc: ConnectionsClient
    private val lock = Any()
    private val epToId = HashMap<String, Int>()
    private val idToEp = HashMap<Int, String>()
    private val pendingNames = HashMap<String, String>()
    private val partial = HashMap<String, StringBuilder>()
    private val writer = Executors.newSingleThreadExecutor()
    @Volatile private var hosting = false
    @Volatile private var scanning = false
    @Volatile private var discovering = false
    @Volatile private var wantRoom: String? = null
    @Volatile private var maxClients = 4
    @Volatile private var alive = true
    private var nextId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
        adapter = bm?.adapter
        cc = Nearby.getConnectionsClient(this)

        root = FrameLayout(this)
        root.setBackgroundColor(0xFF1F6B47.toInt())
        root.isSoundEffectsEnabled = false // no Android system click sound when buttons/cards are tapped
        setContentView(root)
        startHeartbeat()
        Game.start(this, savedInstanceState)
    }

    // The phone's back button goes one step back inside the game.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val handled = try { onBack?.invoke() ?: false } catch (e: Exception) { false }
        if (!handled) finish()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        Game.save(out)
    }

    override fun onPause() {
        super.onPause()
        // the music keeps playing (screen lock, home button, other apps): MusicService is a foreground service
    }

    override fun onResume() {
        super.onResume()
        MusicService.hold(false)
        if (settingsOpened) {
            settingsOpened = false
            ev("perm", 0, if (hasPerm()) "1" else "0")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) MusicService.stopNow()
        alive = false
        closeAll()
        synchronized(this) { link?.shutdown(); link = null }
        writer.shutdown()
        Game.stop()
    }

    /** Replaces the page's confirm(): shows a Yes/No dialog (بله / خیر). */
    fun confirmDialog(msg: String, onYes: () -> Unit, onNo: () -> Unit = {}) {
        AlertDialog.Builder(this)
            .setMessage(msg)
            .setPositiveButton("بله") { _, _ -> onYes() }
            .setNegativeButton("خیر") { _, _ -> onNo() }
            .setOnCancelListener { onNo() }
            .show()
    }

    // Shows the system "turn on location?" dialog (one tap) when location is off, then runs r.
    private fun withLocationOn(r: Runnable) {
        runOnUiThread {
            if (afterLocation.isNotEmpty()) { afterLocation.add(r); return@runOnUiThread }
            try {
                val lr = LocationRequest.Builder(Priority.PRIORITY_LOW_POWER, 10000).build()
                val req = LocationSettingsRequest.Builder().addLocationRequest(lr).build()
                LocationServices.getSettingsClient(this).checkLocationSettings(req)
                    .addOnSuccessListener { r.run() }
                    .addOnFailureListener { e ->
                        if (e is ResolvableApiException) {
                            afterLocation.add(r)
                            try {
                                e.startResolutionForResult(this@MainActivity, REQ_LOC)
                            } catch (ex: Exception) {
                                afterLocation.clear()
                                r.run()
                            }
                        } else {
                            r.run()
                        }
                    }
            } catch (t: Throwable) {
                r.run()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(code: Int, result: Int, data: Intent?) {
        super.onActivityResult(code, result, data)
        if (code == REQ_BTON) {
            ev("perm", 0, if (result == RESULT_OK) "1" else "0")
        }
        if (code == REQ_WIFI) {
            // the Wi-Fi panel was closed: carry on automatically (Wi-Fi Direct needs Wi-Fi really on)
            ev("perm", 0, if ("direct" == net && !wifiOn()) "w0" else "1")
        }
        if (code == REQ_LOC) {
            val todo = ArrayList(afterLocation)
            afterLocation.clear()
            for (t in todo) t.run()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_BT) {
            if (hasPerm()) {
                ev("perm", 0, "1")
                return
            }
            // Asked and refused: ask once more by ourselves; if Android will not show the dialog any more
            // ("don't ask again"), open this app's settings page and carry on when the player comes back.
            var blocked = false
            var i = 0
            while (i < perms.size && i < res.size) {
                if (res[i] != PackageManager.PERMISSION_GRANTED && !shouldShowRequestPermissionRationale(perms[i])) blocked = true
                i++
            }
            if (res.isEmpty()) {
                ev("perm", 0, "0")
            } else if (!blocked && !permRetried) {
                permRetried = true
                requestPermissions(neededPerms(), REQ_BT)
            } else if (blocked) {
                try {
                    settingsOpened = true
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
                    ev("perm", 0, "s0")
                } catch (e: Exception) {
                    settingsOpened = false
                    ev("perm", 0, "0")
                }
            } else {
                ev("perm", 0, "0")
            }
        }
    }

    // ---------- helpers ----------
    private fun neededPerms(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        // Nearby Connections needs location permission on every Android version
        l.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        return l.toTypedArray()
    }

    private fun hasPerm(): Boolean {
        for (p in neededPerms()) {
            val isLoc = p == Manifest.permission.ACCESS_COARSE_LOCATION
                || p == Manifest.permission.ACCESS_FINE_LOCATION
            if (isLoc) continue // location is checked below: either one is enough
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return false
        }
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    /** Delivers a transport event to the game on the UI thread (was: evaluateJavascript("window.btEvt(...)")). */
    private fun ev(type: String, cid: Int, data: String?) {
        val d = data ?: ""
        if (!alive) return
        runOnUiThread { if (alive) btEvt?.invoke(type, cid, d) }
    }

    @Suppress("unused")
    private fun quote(s: String) = JSONObject.quote(s)

    private fun localName(): String {
        try {
            val n = adapter?.name
            if (n != null && n.isNotEmpty()) return n
        } catch (e: Exception) { }
        return "بازیکن"
    }

    private fun liveCount(): Int = synchronized(lock) { epToId.size }

    private fun bind(id: Int, ep: String) {
        synchronized(lock) {
            epToId[ep] = id
            idToEp[id] = ep
        }
    }

    private fun closeConn(id: Int, notify: Boolean) {
        val ep: String?
        synchronized(lock) {
            ep = idToEp.remove(id)
            if (ep != null) {
                epToId.remove(ep)
                partial.remove(ep)
            }
        }
        if (ep != null) {
            try { cc.disconnectFromEndpoint(ep) } catch (e: Exception) { }
            if (notify) ev("drop", id, "")
        }
    }

    private fun stopDiscoveryIfIdle() {
        if (!scanning && wantRoom == null && discovering) {
            discovering = false
            try { cc.stopDiscovery() } catch (e: Exception) { }
        }
    }

    private fun closeAll() {
        synchronized(this) { link?.closeAll() }
        hosting = false
        scanning = false
        wantRoom = null
        discovering = false
        try { cc.stopAdvertising() } catch (e: Exception) { }
        try { cc.stopDiscovery() } catch (e: Exception) { }
        try { cc.stopAllEndpoints() } catch (e: Exception) { }
        synchronized(lock) {
            epToId.clear()
            idToEp.clear()
            pendingNames.clear()
            partial.clear()
        }
    }

    private fun queueSend(id: Int, msg: String) {
        writer.submit {
            val ep: String?
            synchronized(lock) { ep = idToEp[id] }
            if (ep != null) {
                try {
                    if (msg.length <= CHUNK) {
                        cc.sendPayload(ep, Payload.fromBytes((msg + "\n").toByteArray(StandardCharsets.UTF_8)))
                    } else {
                        val parts = ArrayList<String>()
                        var i = 0
                        while (i < msg.length) {
                            var e = Math.min(msg.length, i + CHUNK)
                            if (e < msg.length && Character.isHighSurrogate(msg[e - 1])) e--
                            parts.add(msg.substring(i, e))
                            i = e
                        }
                        for (k in parts.indices) {
                            val f = "\u0002" + k + "," + parts.size + "," + parts[k]
                            cc.sendPayload(ep, Payload.fromBytes(f.toByteArray(StandardCharsets.UTF_8)))
                        }
                    }
                } catch (e: Exception) {
                    closeConn(id, true)
                }
            }
        }
    }

    // Sends an empty message every few seconds so a lost link is noticed quickly.
    private fun startHeartbeat() {
        val hb = Thread {
            while (alive) {
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { return@Thread }
                val ids: Array<Int>
                synchronized(lock) { ids = idToEp.keys.toTypedArray() }
                for (k in ids) queueSend(k, "")
            }
        }
        hb.isDaemon = true
        hb.start()
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(ep: String, p: Payload) {
            val b = p.asBytes() ?: return
            val id: Int?
            synchronized(lock) { id = epToId[ep] }
            if (id == null) return
            var s = String(b, StandardCharsets.UTF_8)
            if (s.isNotEmpty() && s[0] == '\u0002') {
                val c1 = s.indexOf(',')
                val c2 = if (c1 < 0) -1 else s.indexOf(',', c1 + 1)
                if (c1 < 0 || c2 < 0) return
                try {
                    val idx = s.substring(1, c1).toInt()
                    val tot = s.substring(c1 + 1, c2).toInt()
                    var sb: StringBuilder?
                    synchronized(lock) {
                        sb = partial[ep]
                        if (idx == 0 || sb == null) { sb = StringBuilder(); partial[ep] = sb!! }
                        sb!!.append(s.substring(c2 + 1))
                        if (idx != tot - 1) return
                        partial.remove(ep)
                    }
                    s = sb.toString()
                } catch (e: Exception) { return }
            }
            s = s.trim()
            if (s.isNotEmpty()) ev("msg", id, s)
        }

        override fun onPayloadTransferUpdate(ep: String, u: PayloadTransferUpdate) { }
    }

    // Host side: players ask to connect to us.
    private val hostCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            if (!hosting || liveCount() >= maxClients) {
                try { cc.rejectConnection(ep) } catch (e: Exception) { }
                return
            }
            synchronized(lock) { pendingNames[ep] = info.endpointName }
            try { cc.acceptConnection(ep, payloadCb) } catch (e: Exception) { }
        }

        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            val nm: String?
            synchronized(lock) { nm = pendingNames.remove(ep) }
            if (!r.status.isSuccess || !hosting) return
            val id: Int
            synchronized(lock) { id = nextId++ }
            bind(id, ep)
            ev("conn", id, (if (nm == null || nm.isEmpty()) "بازیکن" else nm) + "\u0001" + ep)
        }

        override fun onDisconnected(ep: String) {
            val id: Int?
            synchronized(lock) { id = epToId[ep] }
            if (id != null) closeConn(id, true)
        }
    }

    // Client side: we ask a host to connect.
    private val clientCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(ep: String, info: ConnectionInfo) {
            try { cc.acceptConnection(ep, payloadCb) } catch (e: Exception) { }
        }

        override fun onConnectionResult(ep: String, r: ConnectionResolution) {
            if (r.status.isSuccess) {
                closeConn(0, false)
                bind(0, ep)
                scanning = false
                wantRoom = null
                stopDiscoveryIfIdle()
                ev("open", 0, "")
            } else {
                ev("err", 0, "اتصال برقرار نشد. مطمئن شوید میزبان صفحه‌ی «میزبان بازی می‌شوم» را باز کرده، بلوتوث و موقعیت‌مکانی/وای‌فای هر دو گوشی روشن است و اجازه‌ها داده شده است.")
            }
        }

        override fun onDisconnected(ep: String) {
            val id: Int?
            synchronized(lock) { id = epToId[ep] }
            if (id != null) closeConn(id, true)
        }
    }

    // "bt" = Nearby Connections (Bluetooth / Wi-Fi chosen by Google), "lan" = same Wi-Fi network, "direct" = Wi-Fi Direct
    @Volatile private var net = "bt"
    @Volatile private var wifiAsked = false
    @Volatile private var locAsked = false
    @Volatile private var permRetried = false
    @Volatile private var settingsOpened = false
    private var link: NetLink? = null

    @Synchronized
    private fun link(): NetLink {
        if (link == null) link = NetLink(this, "direct" == net) { type, cid, data -> ev(type, cid, data) }
        return link!!
    }

    private fun wifiOn(): Boolean {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager?
            wm == null || wm.isWifiEnabled
        } catch (e: Exception) {
            true
        }
    }

    private fun locOn(): Boolean {
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager? ?: return true
            if (Build.VERSION.SDK_INT >= 28) return lm.isLocationEnabled
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            true
        }
    }

    private fun viaWifi(): Boolean = "bt" != net

    private fun requestTo(ep: String) {
        try {
            cc.requestConnection(localName(), ep, clientCb)
                .addOnFailureListener { e -> ev("err", 0, "درخواست اتصال ناموفق بود. (" + e.message + ")") }
        } catch (e: Exception) {
            ev("err", 0, "درخواست اتصال ناموفق بود. (" + e.message + ")")
        }
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(ep: String, info: DiscoveredEndpointInfo) {
            val n = info.endpointName
            if (n == null || !n.startsWith("HK|")) return
            val pr = n.split("|", limit = 3)
            val room = if (pr.size > 1) pr[1] else ""
            val host = if (pr.size > 2) pr[2] else ""
            if (scanning) ev("found", 0, ep + "\u0001" + room + "\u0001" + host)
            val w = wantRoom
            if (w != null && w == room) {
                wantRoom = null
                requestTo(ep)
                stopDiscoveryIfIdle()
            }
        }

        override fun onEndpointLost(ep: String) {
            if (scanning) ev("lost", 0, ep)
        }
    }

    private fun startDiscoveryNow() {
        if (discovering) return
        withLocationOn { startDiscoveryReal() }
    }

    private fun startDiscoveryReal() {
        if (discovering) return
        discovering = true
        try {
            cc.startDiscovery(SERVICE_ID, discCb,
                DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
                .addOnFailureListener { e ->
                    discovering = false
                    ev("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.message + ")")
                }
        } catch (e: Exception) {
            discovering = false
            ev("err", 0, "جست‌وجوی بازی‌های نزدیک ممکن نشد. (" + e.message + ")")
        }
    }

    // ---------- bridge (was the AndroidBT JavaScript interface) ----------
    inner class Bridge {
        fun state(): String {
            if (viaWifi()) {
                if (!hasPerm()) return "noperm"
                // Wi-Fi Direct needs Wi-Fi and location switched on. On a shared network each is asked once
                // per attempt (a phone that hosts a hotspot may have Wi-Fi off, and location may not be needed).
                val direct = "direct" == net
                if (!wifiOn() && (direct || !wifiAsked)) return "wifioff"
                if (!locOn() && (direct || !locAsked)) return "locoff"
                return "ok"
            }
            if (adapter == null) return "nobt"
            try {
                if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this@MainActivity) != ConnectionResult.SUCCESS) return "nogms"
            } catch (e: Exception) {
                return "nogms"
            }
            if (!hasPerm()) return "noperm"
            return if (adapter!!.isEnabled) "ok" else "off"
        }

        // Shows the system "allow Bluetooth to be turned on?" dialog.
        fun enableBt() {
            runOnUiThread {
                try {
                    startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BTON)
                } catch (e: Exception) {
                    ev("err", 0, "روشن کردن خودکار بلوتوث ممکن نشد. آن را از تنظیمات گوشی روشن کنید.")
                }
            }
        }

        fun ensure() {
            permRetried = false
            if (!hasPerm()) {
                runOnUiThread { requestPermissions(neededPerms(), REQ_BT) }
            } else {
                ev("perm", 0, "1")
            }
        }

        fun myName(): String {
            return try {
                adapter?.name ?: ""
            } catch (e: Exception) {
                ""
            }
        }

        // Start advertising a game room. room = short id kept for the whole game (even when the host changes).
        fun host(max: Int, room: String, name: String?) {
            if (viaWifi()) { link().startHost(max, room, name); return }
            try { cc.stopAdvertising() } catch (e: Exception) { }
            maxClients = max
            hosting = true
            var n = name ?: ""
            if (n.length > 20) n = n.substring(0, 20)
            val adv = "HK|$room|$n"
            withLocationOn {
                try {
                    cc.startAdvertising(adv, SERVICE_ID, hostCb,
                        AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
                        .addOnFailureListener { e ->
                            if (hosting) ev("err", 0, "باز کردن حالت میزبان ممکن نشد. بلوتوث و موقعیت‌مکانی را روشن کنید و اجازه‌ها را بدهید. (جزئیات فنی: " + e.message + ")")
                        }
                } catch (e: Exception) {
                    ev("err", 0, "باز کردن حالت میزبان ممکن نشد. (جزئیات فنی: " + e.message + ")")
                }
            }
        }

        fun stopHost() {
            if (viaWifi()) { link().stopHost(); return }
            hosting = false
            try { cc.stopAdvertising() } catch (e: Exception) { }
        }

        // Start listing nearby games ("found" / "lost" events).
        fun scan() {
            if (viaWifi()) { link().startScan(); return }
            scanning = true
            startDiscoveryNow()
        }

        fun stopScan() {
            if (viaWifi()) { link().stopScan(); return }
            scanning = false
            stopDiscoveryIfIdle()
        }

        // target = endpoint id from a "found" event, or "room:<id>" to find whoever hosts that room.
        fun connect(target: String?) {
            if (viaWifi()) { link().connect(target, localName()); return }
            closeConn(0, false)
            if (target != null && target.startsWith("room:")) {
                val room = target.substring(5)
                wantRoom = room
                startDiscoveryNow()
                Thread {
                    try { Thread.sleep(12000) } catch (ie: InterruptedException) { return@Thread }
                    if (room == wantRoom) {
                        wantRoom = null
                        stopDiscoveryIfIdle()
                        ev("err", 0, "بازی پیدا نشد. میزبان نزدیک نیست یا بازی را بسته است.")
                    }
                }.start()
            } else if (target != null) {
                requestTo(target)
            }
        }

        fun send(id: Int, msg: String) {
            if (viaWifi()) { link().send(id, msg); return }
            queueSend(id, msg)
        }

        fun drop(id: Int) {
            if (viaWifi()) { link().drop(id); return }
            // small delay so messages queued before (like "you were removed") are delivered first
            writer.submit {
                try { Thread.sleep(500) } catch (ie: InterruptedException) { }
                closeConn(id, false)
            }
        }

        // Chooses how games are played: "bt", "lan" or "direct". Only called while no game is open.
        fun setNet(n: String?) {
            val v = if ("lan" == n || "direct" == n) n!! else "bt"
            if (v == net) return
            closeAll()
            synchronized(this@MainActivity) {
                link?.shutdown()
                link = null
            }
            net = v
            wifiAsked = false
            locAsked = false
        }

        // A new host/join attempt starts: ask again for Wi-Fi / location if they are off.
        fun newAttempt() {
            wifiAsked = false
            locAsked = false
        }

        // Shows the system "turn on location?" dialog (one tap), then tells the game to continue.
        fun enableLoc() {
            locAsked = true
            withLocationOn { ev("perm", 0, if (locOn() || "direct" != net) "1" else "l0") }
        }

        // Opens the Wi-Fi panel once so the player can switch Wi-Fi on (it only has to be on, not connected).
        fun enableWifi() {
            wifiAsked = true
            runOnUiThread {
                try {
                    startActivityForResult(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS), REQ_WIFI)
                } catch (e: Exception) {
                    ev("err", 0, "روشن کردن وای‌فای ممکن نشد. آن را از تنظیمات گوشی روشن کنید.")
                }
            }
        }

        // Background music is played by MusicService (a foreground service) so it survives the screen lock.
        fun musicNative(): Boolean = true

        fun musicSet(on: Boolean, vol: Double) {
            MusicService.apply(applicationContext, on, vol.toFloat())
        }

        fun version(): String {
            return try {
                val pi = packageManager.getPackageInfo(packageName, 0)
                @Suppress("DEPRECATION")
                val vc = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
                "${pi.versionName} ($vc)"
            } catch (e: Exception) {
                ""
            }
        }

        fun exitApp() {
            runOnUiThread { closeAll(); finish() }
        }

        fun close() {
            closeAll()
        }
    }
}
