package com.example.hokm

import android.content.Context
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import java.lang.ref.WeakReference

/**
 * The players' faces: every name always gets the same face (hash of the name), gender from the name,
 * and the expression follows the game (idle / think / happy / joy / sad / angry / surprised ...).
 * Ported from avHash / avIdent / avShade / avHair / avFace / avSVG / avDiv / avSet / avOutcome of the page.
 */
object Av {
    /** gender of names told by the players (GN of the page): name -> "f" | "m" */
    val GN = HashMap<String, String>()

    private val FEM_NAMES: Set<String> by lazy {
        val l = Names.IR_NAMES
        val i = l.indexOf("فاطمه")
        (if (i >= 0) l.subList(i, l.size) else emptyList<String>()).toSet() +
            listOf("آزاده", "آناهیتا", "پریسا", "پرستو", "ترانه", "سحر", "شیما", "شادی", "مریم", "هانیه", "هستی", "یاسمن", "سمیرا",
                "ستاره", "سپیده", "شقایق", "شیرین", "فرشته", "کیمیا", "مهتاب", "نازی", "نغمه", "رز", "رویا", "سوگند")
    }

    private val SK = arrayOf("#f6d5b8", "#efc29b", "#e2a878", "#c98a5c", "#a86b43", "#7b4a2c")
    private val HC = arrayOf("#1d1612", "#2b1d14", "#4a2f1c", "#6b4425", "#8c6a3c", "#b8863e", "#6e6e72")
    private val SH = arrayOf("#3b5b8c", "#8c3b3b", "#3b7a5b", "#6b4b8c", "#8c6b2f", "#2f6f7a", "#5b5b66", "#a24f6f")
    private val BG = arrayOf("#cfe3f4", "#f4dccf", "#d6efd9", "#eadcf4", "#f6efc8", "#d3eaea")

    class P(
        val nm: String, val g: String, val sk: String, val hc: String, val sh: String, val bg: String,
        val hs: Int, val fw: Double, val fh: Double, val es: Double, val bw: Double, val gl: Boolean, val bd: Int, val ns: Int, val tp: Int
    )

    /** number as JavaScript prints it: 22 not 22.0 */
    private fun f(x: Double): String = if (x == Math.rint(x) && Math.abs(x) < 1e15) x.toLong().toString() else x.toString()

    fun clean(s: String?): String = (s ?: "").replace(" (یار)", "")

    private fun hash(nm: String): Long {
        var h = 2166136261L.toInt()
        for (ch in clean(nm)) { h = h xor ch.code; h *= 16777619 }
        h = h xor (h ushr 15); h *= 2246822507L.toInt()
        h = h xor (h ushr 13); h *= 3266489909L.toInt()
        h = h xor (h ushr 16)
        return h.toLong() and 0xFFFFFFFFL
    }

    fun ident(nm: String): P {
        val s = clean(nm).trim()
        val h = hash(s)
        val g = GN[s] ?: (if (FEM_NAMES.contains(s)) "f" else if (Names.IR_NAMES.indexOf(s) >= 0) "m" else if (((h ushr 7) % 2) != 0L) "f" else "m")
        fun r(k: Int) = h ushr k
        return P(s, g, SK[(r(0) % 6).toInt()], HC[(r(3) % 7).toInt()], SH[(r(6) % 8).toInt()], BG[(r(9) % 6).toInt()],
            (r(12) % 5).toInt(), 22.0 + (r(15) % 5), 27.0 + (r(17) % 4), 9.0 + (r(19) % 4), 1.6 + (r(21) % 3) * 0.5,
            (r(23) % 5) == 0L, if (g == "m") (r(25) % 5).toInt() else 0, (r(27) % 3).toInt(), (r(29) % 2).toInt())
    }

    private fun shade(c: String, k: Double): String {
        val n = c.substring(1).toInt(16)
        fun ff(x: Int) = Math.max(0.0, Math.min(255.0, Math.round(x * k).toDouble())).toInt()
        val r = ff(n shr 16); val g = ff((n shr 8) and 255); val b = ff(n and 255)
        return "#" + String.format("%06x", (r shl 16) + (g shl 8) + b)
    }

    private fun hair(P: P, back: Boolean): String {
        val c = P.hc; val d = shade(c, 0.75); val cx = 50.0; val top = 44 - P.fh; val fw = P.fw
        if (P.g == "f") {
            if (back) {
                if (P.hs == 0 || P.hs == 4) return "<path d=\"M" + f(cx - fw - 4) + " 46Q" + f(cx - fw - 6) + " 8 50 8Q" + f(cx + fw + 6) + " 8 " + f(cx + fw + 4) + " 46L" + f(cx + fw + 8) + " 96L" + f(cx - fw - 8) + " 96Z\" fill=\"" + c + "\"/>"
                if (P.hs == 1) return "<path d=\"M" + f(cx - fw - 5) + " 44Q" + f(cx - fw - 7) + " 10 50 9Q" + f(cx + fw + 7) + " 10 " + f(cx + fw + 5) + " 44L" + f(cx + fw + 6) + " 66L" + f(cx - fw - 6) + " 66Z\" fill=\"" + c + "\"/>"
                if (P.hs == 2) return "<circle cx=\"50\" cy=\"10\" r=\"9\" fill=\"" + c + "\"/><path d=\"M" + f(cx - fw - 3) + " 40Q" + f(cx - fw - 4) + " 12 50 11Q" + f(cx + fw + 4) + " 12 " + f(cx + fw + 3) + " 40Z\" fill=\"" + c + "\"/>"
                return "<path d=\"M" + f(cx - fw - 4) + " 44Q" + f(cx - fw - 6) + " 10 50 9Q" + f(cx + fw + 6) + " 10 " + f(cx + fw + 4) + " 44L" + f(cx + fw + 11) + " 84L" + f(cx + fw + 3) + " 88L" + f(cx - fw - 3) + " 88L" + f(cx - fw - 11) + " 84Z\" fill=\"" + c + "\"/>"
            }
            return "<path d=\"M" + f(cx - fw - 1) + " 40Q" + f(cx - fw + 2) + " " + f(top - 3) + " 50 " + f(top - 4) + "Q" + f(cx + fw - 2) + " " + f(top - 3) + " " + f(cx + fw + 1) + " 40Q" + f(cx + 6) + " 26 " + f(cx - 8) + " 24Q" + f(cx - fw + 4) + " 30 " + f(cx - fw - 1) + " 40Z\" fill=\"" + c + "\"/>"
        }
        if (back) return if (P.hs == 3) "<circle cx=\"50\" cy=\"" + f(top + 8) + "\" r=\"" + f(fw + 5) + "\" fill=\"" + c + "\"/>" else ""
        if (P.hs == 4) return "<path d=\"M" + f(cx - fw) + " 36Q" + f(cx - fw + 1) + " " + f(top + 3) + " 50 " + f(top + 2) + "Q" + f(cx + fw - 1) + " " + f(top + 3) + " " + f(cx + fw) + " 36Q" + f(cx + fw - 4) + " 30 50 " + f(top + 9) + "Q" + f(cx - fw + 4) + " 30 " + f(cx - fw) + " 36Z\" fill=\"" + c + "\" opacity=\".35\"/>"
        if (P.hs == 0) return "<path d=\"M" + f(cx - fw - 1) + " 38Q" + f(cx - fw) + " " + f(top - 4) + " 50 " + f(top - 5) + "Q" + f(cx + fw) + " " + f(top - 4) + " " + f(cx + fw + 1) + " 38Q" + f(cx + fw - 3) + " 26 50 " + f(top + 8) + "Q" + f(cx - fw + 3) + " 26 " + f(cx - fw - 1) + " 38Z\" fill=\"" + c + "\"/>"
        if (P.hs == 1) return "<path d=\"M" + f(cx - fw - 2) + " 40Q" + f(cx - fw - 2) + " " + f(top - 5) + " 52 " + f(top - 6) + "Q" + f(cx + fw + 2) + " " + f(top - 5) + " " + f(cx + fw + 2) + " 40Q" + f(cx + fw - 2) + " 28 " + f(cx + 4) + " 25Q" + f(cx - 4) + " 30 " + f(cx - fw + 2) + " 26Q" + f(cx - fw - 1) + " 32 " + f(cx - fw - 2) + " 40Z\" fill=\"" + c + "\"/>"
        if (P.hs == 2) return "<path d=\"M" + f(cx - fw - 2) + " 40Q" + f(cx - fw - 3) + " " + f(top - 6) + " 50 " + f(top - 7) + "Q" + f(cx + fw + 3) + " " + f(top - 6) + " " + f(cx + fw + 2) + " 40Q" + f(cx + fw - 4) + " 30 50 " + f(top + 4) + "Q" + f(cx - fw + 4) + " 30 " + f(cx - fw - 2) + " 40Z\" fill=\"" + c + "\"/><path d=\"M" + f(cx - fw + 2) + " " + f(top + 3) + "Q50 " + f(top - 2) + " " + f(cx + fw - 2) + " " + f(top + 3) + "\" stroke=\"" + d + "\" stroke-width=\"2\" fill=\"none\"/>"
        return "<path d=\"M" + f(cx - fw - 2) + " 38Q" + f(cx - fw - 4) + " " + f(top - 6) + " 50 " + f(top - 8) + "Q" + f(cx + fw + 4) + " " + f(top - 6) + " " + f(cx + fw + 2) + " 38Q" + f(cx + fw - 2) + " 27 50 " + f(top + 6) + "Q" + f(cx - fw + 2) + " 27 " + f(cx - fw - 2) + " 38Z\" fill=\"" + c + "\"/>"
    }

    private fun face(P: P, m: String): String {
        val ex = P.es; val L = 50 - ex; val R = 50 + ex; val bw = P.bw; val bc = shade(P.hc, 0.9)
        val lip = if (P.g == "f") "#b5475a" else "#a5453f"
        val brow: String; val eyes: String; val mouth: String; var extra = ""
        fun open(x: Double, y: Double, rx: Double, ry: Double, px: Double, py: Double) =
            "<ellipse cx=\"" + f(x) + "\" cy=\"" + f(y) + "\" rx=\"" + f(rx) + "\" ry=\"" + f(ry) + "\" fill=\"#fff\"/><circle cx=\"" + f(x + px) + "\" cy=\"" + f(y + py) +
                "\" r=\"" + f(Math.min(rx, ry) * 0.62) + "\" fill=\"#3a2a20\"/><circle cx=\"" + f(x + px - 1) + "\" cy=\"" + f(y + py - 1) + "\" r=\"1\" fill=\"#fff\"/>"
        fun arc(x: Double, up: Boolean) =
            "<path d=\"M" + f(x - 4.5) + " " + (if (up) 41 else 39) + "Q" + f(x) + " " + (if (up) 36 else 44) + " " + f(x + 4.5) + " " + (if (up) 41 else 39) +
                "\" stroke=\"#2a1d16\" stroke-width=\"2.2\" fill=\"none\" stroke-linecap=\"round\"/>"
        fun B(l: String, r: String) =
            "<path d=\"" + l + "\" stroke=\"" + bc + "\" stroke-width=\"" + f(bw) + "\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"" + r + "\" stroke=\"" + bc + "\" stroke-width=\"" + f(bw) + "\" fill=\"none\" stroke-linecap=\"round\"/>"
        fun mo(d: String, fl: String? = null) =
            "<path d=\"" + d + "\" stroke=\"" + lip + "\" stroke-width=\"2.4\" fill=\"" + (fl ?: "none") + "\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>"
        fun cheek(r: String, op: String) =
            "<circle cx=\"" + f(L - 6) + "\" cy=\"52\" r=\"" + r + "\" fill=\"#ff7a8a\" opacity=\"" + op + "\"/><circle cx=\"" + f(R + 6) + "\" cy=\"52\" r=\"" + r + "\" fill=\"#ff7a8a\" opacity=\"" + op + "\"/>"
        when (m) {
            "joy" -> {
                brow = B("M" + f(L - 5) + " 33Q" + f(L) + " 29 " + f(L + 5) + " 32", "M" + f(R - 5) + " 32Q" + f(R) + " 29 " + f(R + 5) + " 33"); eyes = arc(L, true) + arc(R, true)
                mouth = "<path d=\"M" + f(50.0 - 9) + " 54Q50 70 " + f(50.0 + 9) + " 54Z\" fill=\"#7a2230\" stroke=\"" + lip + "\" stroke-width=\"1.6\" stroke-linejoin=\"round\"/><path d=\"M" + f(50.0 - 6) + " 56Q50 60 " + f(50.0 + 6) + " 56L" + f(50.0 + 5) + " 58Q50 61 " + f(50.0 - 5) + " 58Z\" fill=\"#fff\"/>"
                extra = cheek("4.2", ".38")
            }
            "happy" -> {
                brow = B("M" + f(L - 5) + " 34Q" + f(L) + " 31 " + f(L + 5) + " 33", "M" + f(R - 5) + " 33Q" + f(R) + " 31 " + f(R + 5) + " 34"); eyes = open(L, 40.0, 4.4, 4.0, 0.0, 0.4) + open(R, 40.0, 4.4, 4.0, 0.0, 0.4)
                mouth = mo("M" + f(50.0 - 8) + " 54Q50 64 " + f(50.0 + 8) + " 54"); extra = cheek("3.6", ".3")
            }
            "sad" -> {
                brow = B("M" + f(L - 5) + " 36Q" + f(L + 1) + " 33 " + f(L + 5) + " 31", "M" + f(R - 5) + " 31Q" + f(R - 1) + " 33 " + f(R + 5) + " 36"); eyes = open(L, 41.0, 4.2, 3.6, 0.0, 1.3) + open(R, 41.0, 4.2, 3.6, 0.0, 1.3)
                mouth = mo("M" + f(50.0 - 7) + " 60Q50 53 " + f(50.0 + 7) + " 60")
                extra = "<path d=\"M" + f(L - 2) + " 46Q" + f(L - 3) + " 51 " + f(L - 1) + " 53Q" + f(L + 1) + " 51 " + f(L) + " 46Z\" fill=\"#8cc9ff\" opacity=\".85\"/>"
            }
            "angry" -> {
                brow = B("M" + f(L - 6) + " 31Q" + f(L) + " 35 " + f(L + 6) + " 37", "M" + f(R - 6) + " 37Q" + f(R) + " 35 " + f(R + 6) + " 31"); eyes = open(L, 41.0, 4.2, 2.8, 0.6, 0.4) + open(R, 41.0, 4.2, 2.8, -0.6, 0.4)
                mouth = mo("M" + f(50.0 - 8) + " 61Q50 53 " + f(50.0 + 8) + " 61") + "<path d=\"M" + f(50.0 - 5) + " 58L" + f(50.0 + 5) + " 58\" stroke=\"#fff\" stroke-width=\"1.3\"/>"
                extra = "<ellipse cx=\"50\" cy=\"44\" rx=\"" + f(P.fw) + "\" ry=\"" + f(P.fh) + "\" fill=\"#ff2a2a\" opacity=\".18\"/><path d=\"M" + f(R + 8) + " 22l3-4 1 4 4-1-2 4\" stroke=\"#e0201a\" stroke-width=\"1.6\" fill=\"none\" stroke-linecap=\"round\"/>"
            }
            "wait" -> {
                brow = B("M" + f(L - 5) + " 32Q" + f(L) + " 29 " + f(L + 5) + " 32", "M" + f(R - 5) + " 32Q" + f(R) + " 29 " + f(R + 5) + " 32"); eyes = open(L, 40.0, 4.6, 4.8, 1.6, -1.2) + open(R, 40.0, 4.6, 4.8, 1.6, -1.2)
                mouth = mo("M" + f(50.0 - 4) + " 57Q50 58 " + f(50.0 + 5) + " 56")
            }
            "think" -> {
                brow = B("M" + f(L - 5) + " 34Q" + f(L) + " 33 " + f(L + 5) + " 34", "M" + f(R - 5) + " 31Q" + f(R) + " 28 " + f(R + 5) + " 31"); eyes = open(L, 41.0, 4.2, 3.6, -1.6, -0.6) + open(R, 41.0, 4.2, 3.6, -1.6, -0.6)
                mouth = mo("M" + f(50.0 - 6) + " 57Q" + f(50.0 - 1) + " 56 " + f(50.0 + 6) + " 54")
            }
            "surprised" -> {
                brow = B("M" + f(L - 5) + " 30Q" + f(L) + " 26 " + f(L + 5) + " 30", "M" + f(R - 5) + " 30Q" + f(R) + " 26 " + f(R + 5) + " 30"); eyes = open(L, 40.0, 4.8, 5.2, 0.0, 0.0) + open(R, 40.0, 4.8, 5.2, 0.0, 0.0)
                mouth = "<ellipse cx=\"50\" cy=\"59\" rx=\"3.8\" ry=\"4.8\" fill=\"#7a2230\" stroke=\"" + lip + "\" stroke-width=\"1.6\"/>"
            }
            else -> {
                brow = B("M" + f(L - 5) + " 34Q" + f(L) + " 32 " + f(L + 5) + " 34", "M" + f(R - 5) + " 34Q" + f(R) + " 32 " + f(R + 5) + " 34"); eyes = open(L, 40.0, 4.2, 4.0, 0.0, 0.2) + open(R, 40.0, 4.2, 4.0, 0.0, 0.2)
                mouth = mo("M" + f(50.0 - 6) + " 56Q50 60 " + f(50.0 + 6) + " 56")
            }
        }
        val lash = if (P.g == "f") "<path d=\"M" + f(L - 5) + " 37Q" + f(L) + " 34 " + f(L + 5) + " 37\" stroke=\"#2a1d16\" stroke-width=\"1.6\" fill=\"none\"/><path d=\"M" + f(R - 5) + " 37Q" + f(R) + " 34 " + f(R + 5) + " 37\" stroke=\"#2a1d16\" stroke-width=\"1.6\" fill=\"none\"/>" else ""
        return "<g class=\"avf\">" + eyes + lash + brow + mouth + extra + "</g>"
    }

    /** the face as SVG text (avSVG) */
    fun svg(nm: String, m: String, size: Int): String {
        val P = ident(nm); val sk = P.sk; val sd = shade(sk, 0.86); val cx = 50.0; val fw = P.fw; val fh = P.fh
        val nose = "<path d=\"M50 42Q" + (if (P.ns == 0) "53 50 50 52" else if (P.ns == 1) "54 49 51 53" else "52 51 49 52") + "\" stroke=\"" + sd + "\" stroke-width=\"1.8\" fill=\"none\" stroke-linecap=\"round\"/>"
        var beard = ""
        if (P.g == "m") {
            val bc = shade(P.hc, 0.95)
            if (P.bd == 1) beard = "<path d=\"M" + f(cx - fw + 3) + " 52Q50 " + f(44 + fh + 3) + " " + f(cx + fw - 3) + " 52Q50 62 " + f(cx - fw + 3) + " 52Z\" fill=\"" + bc + "\" opacity=\".28\"/>"
            else if (P.bd == 2) beard = "<path d=\"M" + f(cx - fw) + " 46Q" + f(cx - fw + 1) + " " + f(44 + fh + 4) + " 50 " + f(44 + fh + 5) + "Q" + f(cx + fw - 1) + " " + f(44 + fh + 4) + " " + f(cx + fw) + " 46Q" + f(cx + fw - 5) + " 56 " + f(cx + 9) + " 55Q50 52 " + f(cx - 9) + " 55Q" + f(cx - fw + 5) + " 56 " + f(cx - fw) + " 46Z\" fill=\"" + bc + "\"/>"
            else if (P.bd == 3) beard = "<path d=\"M" + f(50.0 - 10) + " 53Q50 49 " + f(50.0 + 10) + " 53Q50 56 " + f(50.0 - 10) + " 53Z\" fill=\"" + bc + "\"/>"
        }
        val glass = if (P.gl) "<g><circle cx=\"" + f(50 - P.es) + "\" cy=\"40\" r=\"7.4\" fill=\"none\" stroke=\"#222\" stroke-width=\"1.6\"/><circle cx=\"" + f(50 + P.es) + "\" cy=\"40\" r=\"7.4\" fill=\"none\" stroke=\"#222\" stroke-width=\"1.6\"/><path d=\"M" + f(50 - P.es + 7.4) + " 40L" + f(50 + P.es - 7.4) + " 40\" fill=\"none\" stroke=\"#222\" stroke-width=\"1.6\"/></g>" else ""
        val sh = if (P.g == "f") "<path d=\"M4 100Q9 76 50 73Q91 76 96 100Z\" fill=\"" + P.sh + "\"/><path d=\"M38 74Q50 86 62 74\" fill=\"" + sk + "\"/>"
        else "<path d=\"M4 100Q8 75 50 72Q92 75 96 100Z\" fill=\"" + P.sh + "\"/><path d=\"M40 73L50 82L60 73Z\" fill=\"#fff\"/>"
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\" width=\"$size\" height=\"$size\"><g>" +
            "<rect width=\"100\" height=\"100\" fill=\"" + P.bg + "\"/>" + hair(P, true) + "<rect x=\"43\" y=\"58\" width=\"14\" height=\"20\" fill=\"" + sd + "\"/>" + sh +
            "<ellipse cx=\"" + f(cx - fw - 0.5) + "\" cy=\"46\" rx=\"3.4\" ry=\"5\" fill=\"" + sk + "\"/><ellipse cx=\"" + f(cx + fw + 0.5) + "\" cy=\"46\" rx=\"3.4\" ry=\"5\" fill=\"" + sk + "\"/>" +
            "<ellipse cx=\"50\" cy=\"44\" rx=\"" + f(fw) + "\" ry=\"" + f(fh) + "\" fill=\"" + sk + "\"/>" + hair(P, false) + nose + beard + face(P, m) + glass + "</g></svg>"
    }

    /** a hand in the player's sleeve colour and skin tone (avHandSVG) */
    fun handSvg(nm: String): String {
        val P = ident(nm); val sk = P.sk; val sd = shade(sk, 0.82)
        val fingers = StringBuilder()
        listOf(11.0, 16.5, 22.0, 27.0).forEachIndexed { i, x ->
            fingers.append("<rect x=\"" + f(x) + "\" y=\"" + f(5.0 + (if (i == 1) -2 else if (i == 3) 2 else 0)) + "\" width=\"4.6\" height=\"18\" rx=\"2.3\" fill=\"" + sk + "\" stroke=\"" + sd + "\" stroke-width=\".6\"/>")
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 40 60\" width=\"34\" height=\"51\">" +
            "<rect x=\"9\" y=\"40\" width=\"22\" height=\"20\" rx=\"5\" fill=\"" + P.sh + "\"/><rect x=\"12\" y=\"31\" width=\"16\" height=\"12\" rx=\"3\" fill=\"" + sd + "\"/>" +
            "<rect x=\"9\" y=\"18\" width=\"22\" height=\"18\" rx=\"7\" fill=\"" + sk + "\"/>" + fingers +
            "<rect x=\"3\" y=\"21\" width=\"9\" height=\"5\" rx=\"2.5\" fill=\"" + sk + "\" stroke=\"" + sd + "\" stroke-width=\".6\" transform=\"rotate(-25 7 23)\"/></svg>"
    }

    private val handCache = HashMap<String, Bitmap>()

    /** the hand picture, 34 x 51 dp */
    fun handBitmap(nm: String): Bitmap {
        val k = clean(nm)
        return handCache.getOrPut(k) { SvgLite.render(handSvg(k), Px.dp(34), Px.dp(51)) }
    }

    // ---------------------------------------------------------------- the face views and their moods

    private val cache = HashMap<String, Bitmap>()

    private fun bitmap(nm: String, m: String, px: Int): Bitmap {
        val k = clean(nm) + "|" + m + "|" + px
        return cache.getOrPut(k) { SvgLite.render(svg(clean(nm), m, px), px) }
    }

    private class Mood(val m: String, val until: Long)
    private val moods = HashMap<String, Mood>()
    private class Live(val nm: String, val sz: Int, val iv: ImageView, val box: View)
    private val live = ArrayList<WeakReference<Live>>()

    /** the mood a face shows now (avNow) */
    fun now(nm: String, turn: Boolean): String {
        val r = moods[clean(nm)]
        if (r != null && r.until > Sched.now()) return r.m
        return if (turn) "think" else "idle"
    }

    /** the name of this player on his own phone (avMe) */
    fun me(): String {
        return try {
            val n = if (MP.role == "client" && MP.myName.isNotEmpty()) clean(MP.myName)
            else if (MP.role == "host" && MP.hostName.isNotEmpty()) clean(MP.hostName)
            else { val s = Prefs.name; if (s.isNotEmpty()) clean(s) else "شما" }
            val g = Prefs.gender
            if (g.isNotEmpty()) GN[n] = g
            n
        } catch (e: Exception) { "شما" }
    }

    /** a round face for the player's box (avDiv); ring = it is his turn */
    fun view(ctx: Context, name: String, sz: Int, turn: Boolean, ring: Boolean): View {
        val nm = clean(name)
        val px = Px.dp(sz)
        val box = FrameLayout(ctx)
        val iv = ImageView(ctx)
        iv.setImageBitmap(bitmap(nm, now(nm, turn), px))
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        box.addView(iv, FrameLayout.LayoutParams(px, px))
        box.clipToOutline = true
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        box.background = android.graphics.drawable.GradientDrawable().also {
            it.shape = android.graphics.drawable.GradientDrawable.OVAL; it.setColor(0xFFFFFFFF.toInt())
            it.setStroke(Px.dp(if (ring) 3 else 2), if (ring) 0xFFFFE36B.toInt() else 0x66000000)
        }
        box.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        box.layoutParams = ViewGroup.MarginLayoutParams(px, px)
        synchronized(live) { live.removeAll { it.get() == null }; live.add(WeakReference(Live(nm, sz, iv, box))) }
        return box
    }

    /** the visible face of this player on the table (for the hug), or null */
    fun findView(name: String): View? {
        val nm = clean(name)
        synchronized(live) {
            for (w in live) {
                val l = w.get() ?: continue
                if (l.nm == nm && l.box.isAttachedToWindow && l.box.isShown && l.box.width > 0) return l.box
            }
        }
        return null
    }

    /** a face as a bitmap (for the hugging copies) */
    fun faceBitmap(name: String, m: String, px: Int): Bitmap = bitmap(clean(name), m, px)

    /** a round face with a fixed expression, and a function that changes it (the draw scene's faces) */
    fun viewMood(ctx: Context, name: String, sz: Int, mood: String): Pair<View, (String) -> Unit> {
        val nm = clean(name); val px = Px.dp(sz)
        val box = FrameLayout(ctx)
        val iv = ImageView(ctx)
        iv.setImageBitmap(bitmap(nm, mood, px))
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        box.addView(iv, FrameLayout.LayoutParams(px, px))
        box.clipToOutline = true
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        box.background = android.graphics.drawable.GradientDrawable().also {
            it.shape = android.graphics.drawable.GradientDrawable.OVAL; it.setColor(0xFFFFFFFF.toInt()); it.setStroke(Px.dp(2), 0x66000000)
        }
        box.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        return Pair(box) { m ->
            iv.setImageBitmap(bitmap(nm, m, px))
            box.animate().cancel(); box.scaleX = 1f; box.scaleY = 1f
            box.animate().scaleX(1.25f).scaleY(1.25f).setDuration(150).withEndAction { box.animate().scaleX(1f).scaleY(1f).setDuration(150).start() }.start()
        }
    }

    /** changes a player's expression for [ms] milliseconds (avSet) */
    fun set(name: String, m: String, ms: Long) {
        val nm = clean(name)
        if (nm.isEmpty()) return
        val until = Sched.now() + ms
        moods[nm] = Mood(m, until)
        repaint(nm, m)
        Sched.laterRaw(ms + 60) {
            val r = moods[nm]
            if (r != null && r.until <= Sched.now()) repaint(nm, "idle")
        }
    }

    private fun repaint(nm: String, m: String) {
        synchronized(live) {
            for (w in live) {
                val l = w.get() ?: continue
                if (l.nm == nm) { try { l.iv.setImageBitmap(bitmap(nm, m, Px.dp(l.sz))) } catch (e: Exception) { } }
            }
        }
    }

    /** the two teams (or the two players) at the table now: (our side, the opponents) — set by App (avGroups) */
    var groups: (() -> Pair<List<String>, List<String>>?)? = null

    private fun temper(nm: String): Int = (hash(clean(nm)) % 3).toInt()

    /** faces react to what happens (avOutcome); n = the sound name */
    fun outcome(n: String) {
        val G = try { groups?.invoke() } catch (e: Exception) { null } ?: return
        val al = G.first.filter { it.isNotEmpty() }; val op = G.second.filter { it.isNotEmpty() }
        val lose = { x: String -> if (temper(x) == 0) "angry" else "sad" }
        val lose2 = { x: String -> if (temper(x) == 0) "surprised" else "sad" }
        fun W(a: List<String>, b: List<String>, ma: String, mb: (String) -> String, ms: Long) {
            a.forEach { set(it, ma, ms) }; b.forEach { set(it, mb(it), ms) }
        }
        when (n) {
            "trick" -> W(al, op, "happy", lose2, 1550)
            "tlose" -> W(op, al, "happy", lose2, 1950)
            "win" -> W(al, op, "joy", lose, 3250)
            "lose" -> W(op, al, "joy", lose, 3650)
            "kwin" -> W(al, op, "joy", { "angry" }, 3800)
            "klose" -> W(op, al, "joy", { "angry" }, 3800)
            "fwin" -> W(al, op, "joy", lose, 5300)
            "flose" -> W(op, al, "joy", lose, 3700)
        }
        // at the end of a game each pair of partners hugs (the winners kiss, the losers console each other)
        if ((n == "fwin" || n == "flose") && al.size == 2 && op.size == 2) {
            val D = Anim.ad(if (Sound.on) Fx.bduOf(n) else 3300)
            Fx.hug(al, if (n == "fwin") "win" else "lose", D)
            Fx.hug(op, if (n == "fwin") "lose" else "win", D)
        }
    }
}
