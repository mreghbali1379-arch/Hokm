package com.example.hokm

/** A playing card: s = suit (0 ♠ پیک, 1 ♥ دل, 2 ♦ خشت, 3 ♣ گشنیز), r = rank 2..14 (11 J, 12 Q, 13 K, 14 A).
 *  Identity matters (the game compares cards by reference, like the original objects), so this is a plain class. */
class Card(@JvmField val s: Int, @JvmField val r: Int)

/** A card played in a four-player trick. */
class TC(@JvmField val seat: Int, @JvmField val c: Card)

/** A card played in a two-player trick (p = player 0/1). */
class TP(@JvmField val p: Int, @JvmField val c: Card)

/** One played card kept for the bots' inference (weightOf). len = cards already on the table. */
class Play(
    @JvmField val seat: Int, @JvmField val c: Card, @JvmField val len: Int,
    @JvmField val led: Int, @JvmField val bs: Int, @JvmField val bc: Card?
)

object Cards {
    val SU = arrayOf("♠", "♥", "♦", "♣")
    val RL = mapOf(11 to "J", 12 to "Q", 13 to "K", 14 to "A")
    val NM = arrayOf("شما", "حریف ۱", "یار", "حریف ۲")
    val SN = arrayOf("پیک", "دل", "خشت", "گشنیز")
    val RN = mapOf(11 to "سرباز", 12 to "بی‌بی", 13 to "شاه", 14 to "آس")

    /** Western digits -> Persian digits. */
    fun fa(n: Int): String = n.toString().map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")

    fun lab(c: Card): String = RN[c.r] ?: fa(c.r)
    fun cname(c: Card): String = lab(c) + " " + SN[c.s]
    fun idc(c: Card): Int = c.s * 20 + c.r

    fun sortH(h: MutableList<Card>) {
        h.sortWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }
    }

    fun sorted2(h: List<Card>): List<Card> =
        h.sortedWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }

    fun allCards(): MutableList<Card> {
        val a = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) a.add(Card(s, r))
        return a
    }

    fun <T> shuf(a: MutableList<T>): MutableList<T> {
        for (i in a.size - 1 downTo 1) {
            val j = Math.floor(Math.random() * (i + 1)).toInt()
            val x = a[i]; a[i] = a[j]; a[j] = x
        }
        return a
    }

    /** Hand as spoken text for TalkBack: "پیک: آس، شاه؛ دل: ..." */
    fun handText(h: List<Card>): String {
        val o = ArrayList<String>()
        for (x in 0 until 4) {
            val a = h.filter { it.s == x }.sortedByDescending { it.r }
            if (a.isNotEmpty()) o.add(SN[x] + ": " + a.joinToString("، ") { lab(it) })
        }
        return o.joinToString("؛ ")
    }
}

/** Thrown to stop a search that ran out of nodes or time (the original used `throw 0`). */
class Abort : RuntimeException(null, null, false, false)
