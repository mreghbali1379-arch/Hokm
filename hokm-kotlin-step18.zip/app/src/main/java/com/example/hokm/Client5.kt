package com.example.hokm

import com.example.hokm.Cards.SN
import com.example.hokm.Cards.cname
import org.json.JSONArray
import org.json.JSONObject

/** a card on the table as the guest sees it: n = who played it, r = relative seat (0 you, 1 left, 2 across, 3 right) */
class CT(@JvmField val n: String, @JvmField val c: Card, @JvmField val r: Int)

/** another player's cards (a fan): r = relative seat, n = number of cards, t = name */
class CF(@JvmField val r: Int, @JvmField val n: Int, @JvmField val t: String)

/**
 * The guest side of a multi-phone game (the page's CL object and clMsg/clEv/clLog/clAns/clPlay):
 * it receives the table state and the host's questions, and answers them. The screen is drawn by [App.renderClient].
 */
class Client(private val app: App) {
    var me = -1
    var mode = 4
    var ask: JSONObject? = null
    val sel: MutableList<Card> = ArrayList()
    var hand: List<Card> = ArrayList()
    var table: List<CT> = ArrayList()
    var status = ""
    var fan: List<CF> = ArrayList()
    var tr = -1
    var hkn = ""
    var tkv = intArrayOf(0, 0)
    var scv = intArrayOf(0, 0)
    var hr = -1
    var tn = -1
    var wr = -1
    var bk = 0
    var ph = ""
    var wm = false
    var v4 = true
    private var heard5 = ""
    private var lsc: IntArray? = null
    private var lend = ""

    private fun jc(o: JSONObject) = Card(o.getInt("s"), o.getInt("r"))
    private fun cards(a: JSONArray?): List<Card> {
        val l = ArrayList<Card>()
        if (a != null) for (i in 0 until a.length()) l.add(jc(a.getJSONObject(i)))
        return l
    }

    /** the cards listed in the host's current question (d.hand / d.cards) */
    fun askCards(key: String): List<Card> = cards(ask?.optJSONObject("d")?.optJSONArray(key))

    private fun reset() {
        ask = null; sel.clear(); hand = ArrayList(); table = ArrayList(); status = ""; fan = ArrayList()
        lsc = null; lend = ""; ph = ""; wm = false; tr = -1; wr = -1; hr = -1; tn = -1; bk = 0
        sndq.clear()
    }

    // ---------------------------------------------------------------- log with the host's timing tags (c5log / clLog)

    fun c5log(t: String, clr: Boolean = false, min: Long = 0) {
        val d = Spk.slot(t, min)
        if (d > 0) Sched.later(d) { c5logNow(t, clr) } else c5logNow(t, clr)
    }

    fun c5logNow(t: String, clr: Boolean = false) {
        if (!Prefs.a11y) return
        if (clr) app.clearLog()
        app.logNow(t)
    }

    /** a line shown in the message box and the log (used for kick / full) */
    fun said(t: String) {
        if (app.currentScreen() == "g5") { c5log(t); app.say(t); app.clientActionsClear() }
    }

    private val sndq = ArrayList<() -> Unit>()
    private var sndT: Runnable? = null

    private fun flushSnd() {
        Sched.cancel(sndT)
        val q = ArrayList(sndq); sndq.clear()
        for (f in q) { try { f() } catch (e: Exception) { } }
    }

    private fun clLog(m: JSONObject) {
        val x = m.optString("x"); val w = m.optString("w"); val clr = m.optBoolean("clr", false)
        val go = {
            if (m.optString("h") == "hand5") heard5 = x
            if (w == "snd" && ph == "end") app.say(x)
            c5log(x, clr)
        }
        if (w == "card") Sched.later(Math.max(0, Anim.ad(360) - Sound.CSO)) { go() }
        else if (w == "snd") {
            sndq.add { go() }
            Sched.cancel(sndT)
            sndT = Sched.later(4000) { flushSnd() }
        } else go()
    }

    // ---------------------------------------------------------------- sounds

    private var bnEnd = 0L

    private fun clPlay(a: String) {
        if (Sound.on) Sound.EST[a]?.let { bnEnd = Math.max(bnEnd, Sched.now() + it) }
        val go = { flushSnd(); Sound.sfx(a) }
        val d = Sound.qd(a)
        if (d > 0) Sched.later(d) { go() } else go()
    }

    /** sounds for the end of a hand, found from the change of score (clEv) */
    private fun clEv(m: JSONObject) {
        val sa = m.optJSONArray("sc") ?: return
        val sc = intArrayOf(sa.getInt(0), sa.getInt(1))
        val prev = lsc
        val mph = m.optString("ph")
        if (mph == "end" && prev != null && lend != sc.joinToString(",")) {
            lend = sc.joinToString(",")
            val dm = sc[0] - prev[0]; val dt = sc[1] - prev[1]
            if (dm > 0 || dt > 0) {
                val me2 = dm > 0; val pts = if (me2) dm else dt; val win = if (me2) sc[0] else sc[1]
                val kot = pts >= 2; val gm = win >= 7
                val a = ArrayList<String>()
                if (kot) a.add(if (me2) "kwin" else "klose")
                if (gm) a.add(if (me2) "fwin" else "flose")
                if (!kot && !gm) a.add(if (me2) "win" else "lose")
                if (Sound.on) bnEnd = Math.max(bnEnd, Sched.now() + 700 + a.sumOf { Sound.EST[it] ?: 0 })
                Sched.later(700) { a.forEach { clPlay(it) } }
            }
        }
        lsc = sc.copyOf(); ph = mph; wm = m.optBoolean("wm", false)
    }

    // ---------------------------------------------------------------- telling the host when we are free (clFree)

    private var freeT: Runnable? = null
    private fun clFree() {
        if (MP.role != "client") return
        Sched.cancel(freeT)
        freeT = Sched.laterRaw(40) {
            try {
                val now = Sched.now()
                val e = Math.max(Spk.end, bnEnd)
                MP.send(0, JSONObject().put("t", "free").put("ms", Math.max(0L, e - now)))
            } catch (x: Exception) { }
        }
    }

    // ---------------------------------------------------------------- answers

    fun answer(v: Any?) {
        val a = ask ?: return
        ask = null; sel.clear()
        app.say("")
        MP.send(0, JSONObject().put("t", "ans").put("id", a.getInt("id")).put("v", v ?: JSONObject.NULL))
        app.renderClient()
    }

    fun toggleSel(c: Card) {
        val k = sel.indexOfFirst { it.s == c.s && it.r == c.r }
        if (k >= 0) sel.removeAt(k) else if (sel.size < 2) sel.add(c) else c5log("فقط دو کارت را می‌شود انتخاب کرد.")
        app.renderClient()
    }

    // ---------------------------------------------------------------- messages from the host

    fun onMsg(m: JSONObject) {
        val t = m.optString("t")
        onMsg0(m)
        if (t == "st" || t == "shf" || t == "snd" || t == "log" || t == "asd" || t == "drw") clFree()
    }

    // ---------------------------------------------------------------- reconnecting and taking over as host

    var holdTxt = ""
    private var rc: Runnable? = null
    private var foI: Runnable? = null

    // who may become the host if the host disappears (sent by the host in "roster" / "sync")
    var succAddr = ""
    var imSucc = false
    var rank = -2
    var syncS = ""

    private val FO_MS = 10000L
    private val FO_GAP = 8000L

    fun stopReconnect() { Sched.cancel(rc); Sched.cancel(foI); foI = null; MP.rcOn = false }

    /** forget the table of the old game (used when this phone stops being the host) */
    fun resetForTransfer() {
        hand = ArrayList(); table = ArrayList(); status = ""; ask = null; me = -1
        app.clearLog()
    }

    fun onDrop() {
        ask = null
        if (!MP.over) startReconnect()
    }

    fun startReconnect() {
        MP.rcOn = true; MP.rcN = 0; MP.rcT0 = Sched.now()
        Sched.cancel(foI); foI = Sched.laterRaw(1000) { foTick() }
        val t = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید ربات جای شما بازی می‌کند. در حال اتصال دوباره..."
        c5log(t); app.say(t)
        app.clientButtons(listOf(
            Pair("اتصال دوباره") { MP.rcN = 0; MP.rcOn = true; Sched.cancel(rc); doReconnect() },
            Pair("خروج به منو") { app.lobby.mpLeave() }
        ))
        app.focusFirst("#a5 button")
        Sched.cancel(rc)
        rc = Sched.laterRaw(2500) { if (!MP.conn) doReconnect() }
    }

    private fun doReconnect() {
        if (MP.role != "client" || MP.leaving || MP.conn) return
        if (foStep(false)) return
        if (++MP.rcN > 40) {
            MP.rcOn = false
            val t = "اتصال دوباره ممکن نشد. می‌توانید دکمه‌ی «اتصال دوباره» را بزنید."
            c5log(t); app.say(t)
            return
        }
        try { Game.act.bridge.connect(MP.lastAddr) } catch (e: Exception) { }
        Sched.cancel(rc)
        rc = Sched.laterRaw(6000) { if (!MP.conn) doReconnect() }
    }

    private fun foRank(): Int = if (rank >= -1) rank else (if (imSucc) 0 else -1)

    /** after a while without the host: the first successor takes over, the others connect to him (foStep) */
    private fun foStep(go: Boolean): Boolean {
        if (MP.role != "client" || MP.leaving || MP.conn || MP.rcT0 == 0L) return false
        val el = Sched.now() - MP.rcT0; val rk = foRank()
        if (rk >= 0 && el > FO_MS + rk * FO_GAP && failover()) return true
        if (!MP.fo && rk != 0 && el > FO_MS && succAddr.isNotEmpty()) {
            MP.fo = true; MP.lastAddr = succAddr; MP.rcN = 0
            val t = "میزبان قبلی قطع شد. در حال اتصال به میزبان جدید..."
            c5log(t); app.say(t)
            if (go) try { Game.act.bridge.connect(MP.lastAddr) } catch (e: Exception) { }
        }
        return false
    }

    private fun foTick() {
        if (MP.role != "client" || MP.leaving || MP.conn || !MP.rcOn) { foI = null; return }
        foStep(true)
        foI = Sched.laterRaw(1000) { foTick() }
    }

    private fun failover(): Boolean {
        if (foRank() < 0 || syncS.isEmpty() || me < 0) return false
        val x = try { JSONObject(syncS) } catch (e: Exception) { return false }
        try { app.lobby.adoptHost(x, me, null) } catch (e: Exception) { return false }
        return true
    }

    /** the game state of this phone's old table is kept (prev games): store what the host sent with "sv" */
    private fun storeSv(m: JSONObject) {
        try {
            val room = m.optString("room")
            val old = Prefs.loadPrev(); val a = org.json.JSONArray()
            a.put(JSONObject().put("room", room).put("hn", m.optString("hn")).put("m", m.optInt("m")).put("t", System.currentTimeMillis())
                .put("s", m.get("s")).put("seat", if (me >= 0) me else m.optInt("seat")))
            for (i in 0 until old.length()) { val o = old.getJSONObject(i); if (o.optString("room") != room) a.put(o) }
            Prefs.putPrev(a)
        } catch (e: Exception) { }
    }

    private fun onMsg0(m: JSONObject) {
        when (m.optString("t")) {
            "go" -> {
                MP.over = false
                if (m.has("mode")) mode = m.optInt("mode", mode)
                app.showClientScreen()
                reset()
                app.clearLog(); app.say("")
                app.clientActionsClear()
                val tx = if (m.optBoolean("add", false)) "میزبان شما را به بازی اضافه کرد و بازی ادامه دارد."
                else if (m.optBoolean("back", false)) "دوباره به بازی وصل شدید و بازی ادامه دارد." else ""
                if (tx.isNotEmpty()) c5log(tx)
                app.renderClient()
            }
            "st" -> {
                clEv(m)
                status = m.optString("status")
                table = m.optJSONArray("table")?.let { a -> (0 until a.length()).map { i -> val o = a.getJSONObject(i); CT(o.optString("n"), jc(o.getJSONObject("c")), o.optInt("r")) } } ?: ArrayList()
                hand = cards(m.optJSONArray("hand"))
                fan = m.optJSONArray("fan")?.let { a -> (0 until a.length()).map { i -> val o = a.getJSONObject(i); CF(o.optInt("r"), o.optInt("n"), o.optString("t")) } } ?: ArrayList()
                v4 = m.has("hr")
                tr = if (m.isNull("tr")) -1 else m.optInt("tr", -1)
                hkn = m.optString("hkn")
                m.optJSONArray("tk")?.let { tkv = intArrayOf(it.getInt(0), it.getInt(1)) }
                m.optJSONArray("sc")?.let { scv = intArrayOf(it.getInt(0), it.getInt(1)) }
                hr = m.optInt("hr", -1); tn = m.optInt("tn", -1)
                wr = if (m.isNull("wr")) -1 else m.optInt("wr", -1)
                bk = m.optInt("bk", 0)
                app.renderClient()
            }
            "shf" -> { Fx.hn++; clPlay("shuffle") }
            "snd" -> {
                flushSnd()
                val a = m.optString("a")
                if (Sound.on) Sound.EST[a]?.let { bnEnd = Math.max(bnEnd, Sched.now() + it) }
                Sound.sfx(a)
            }
            "log" -> clLog(m)
            "drw" -> {
                val nm = m.optJSONArray("nm")
                val lab = (0 until (nm?.length() ?: 0)).map { nm!!.getString(it) }
                val h = m.optInt("h", 0)
                val pt = if (m.isNull("pt")) null else m.optInt("pt")
                val sq = m.optJSONArray("seq")
                val seq = ArrayList<TP>()
                if (sq != null) for (k in 0 until sq.length()) { val e = sq.getJSONObject(k); seq.add(TP(e.getInt("p"), jc(e.getJSONObject("c")))) }
                val mvA = m.optJSONArray("mv")
                val mv = IntArray(4) { k -> if (mvA != null && k < mvA.length()) mvA.getInt(k) else k }
                val D = Draw.D(m.optInt("n", 4), seq, h, pt, m.optInt("i1", 0), m.optInt("i2", -1), mv)
                if (seq.isEmpty()) { val tx = Draw.describe(D, lab); app.say(tx); c5logNow(tx) }
                else Fx.drawScene(D, lab, null, if (m.has("f")) m.optDouble("f") else null) { tx, q -> app.say(tx); if (!q) c5logNow(tx) }
            }
            "seat" -> me = m.optInt("seat", me)
            "hn" -> MP.hostName = m.optString("name", MP.hostName)
            "ask" -> {
                ask = m; sel.clear()
                app.renderClient()
                val k = m.optString("k"); val d = m.getJSONObject("d")
                val msg = if (k == "play") "نوبت شماست. " + (if (d.optInt("led", -1) >= 0) "خال زمین: " + SN[d.getInt("led")] + "." else "شما شروع می‌کنید.")
                else if (k == "trump") "شما حاکم هستید. پنج کارت شما: " + Cards.handText(cards(d.optJSONArray("hand"))) + ". حکم را انتخاب کنید."
                else if (k == "disc") {
                    val five = "پنج کارت شما: " + Cards.handText(cards(d.optJSONArray("hand"))) + "."
                    (if (heard5 == five) "دو کارت را کنار بگذارید" else "$five دو کارت را کنار بگذارید") +
                        (if (!d.isNull("trump") && d.has("trump")) " (حکم " + SN[d.getInt("trump")] + " است)." else ".")
                }
                else "مرحله " + d.optInt("n") + ". کارت رو: " + cname(jc(d.getJSONObject("up"))) + "."
                if (k == "disc") heard5 = ""
                app.say(msg)
                c5log(msg)
                app.focusFirst(if (k == "play") "#hand button.ok" else if (k == "trump") ".pick button" else if (k == "disc") "#hand2 button" else "#a2 button")
            }
            "roster" -> {
                succAddr = m.optString("succ"); imSucc = m.optBoolean("me", false)
                rank = if (m.has("rank") && !m.isNull("rank")) m.optInt("rank") else (if (m.optBoolean("me", false)) 0 else -1)
                if (m.has("nm")) MP.myName = m.optString("nm")
            }
            "sync" -> syncS = m.optString("s")
            "migrate" -> {
                MP.lastAddr = m.optString("addr"); MP.fo = true
                if (m.has("nm")) MP.myName = m.optString("nm")
                c5log("میزبانی در حال انتقال است. به‌زودی به میزبان جدید وصل می‌شوید.")
            }
            "xfer" -> {
                val x = try { JSONObject(m.optString("s")) } catch (e: Exception) { null }
                if (x != null) app.lobby.adoptHost(x, m.optInt("seat"), null)
            }
            "sv" -> storeSv(m)
            "hold" -> {
                holdTxt = if (m.optBoolean("on", false)) m.optString("x").ifEmpty { "بازی متوقف است تا میزبان ادامه را تأیید کند." } else ""
                app.holdUi()
                c5log(if (holdTxt.isNotEmpty()) holdTxt else "بازی ادامه پیدا کرد.")
            }
            "over" -> { MP.over = true; ask = null; app.clientActionsClear() }
        }
    }
}
