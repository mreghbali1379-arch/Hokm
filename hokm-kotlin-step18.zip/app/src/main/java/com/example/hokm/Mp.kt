package com.example.hokm

import org.json.JSONObject

/** One phone connected to the host. seat: 1 right opponent, 2 partner, 3 left opponent (null = waiting). */
class Peer(@JvmField var seat: Int?, @JvmField var name: String, @JvmField var addr: String) {
    @JvmField var joined = false
    @JvmField var id = ""
    @JvmField var g = ""
    @JvmField var freeAt = 0L
}

/** A question waiting for a remote player's answer (MP.pend). */
class Pend(@JvmField val id: Int, @JvmField val k: String, @JvmField val cb: (Any?) -> Unit)

/** a player who dropped out of a running game (MP.away): his seat is kept for him */
class Away(@JvmField val name: String, @JvmField val id: String)

/** A game found nearby while joining. */
class Found(@JvmField val room: String, @JvmField val name: String)

/** State of the multi-phone game (the page's MP object). role: "off" | "host" | "client". */
object MP {
    @JvmField var role = "off"
    @JvmField var mode = 0
    @JvmField val cl = LinkedHashMap<Int, Peer>()
    @JvmField var started = false
    @JvmField var leaving = false
    @JvmField var hostName = "میزبان"
    @JvmField var myName = ""
    @JvmField var room = ""
    @JvmField val found = LinkedHashMap<String, Found>()
    @JvmField var conn = false
    @JvmField var lastAddr = ""
    @JvmField var rcN = 0
    @JvmField var rcOn = false
    @JvmField var rcT0 = 0L
    @JvmField var fo = false
    /** last snapshot sent to the successors (so an unchanged one is not sent again) */
    @JvmField var lsy = ""
    /** called by the game flows after each move so the host can keep its successors up to date */
    @JvmField var onSync: (() -> Unit)? = null
    @JvmField var over = false
    @JvmField var pdraw = true
    @JvmField val pend = HashMap<Int, Pend>()
    @JvmField var askId = 0
    /** seats played by a remote person instead of a bot (REM) */
    @JvmField val rem = BooleanArray(4)
    /** seats of players who dropped out, by seat */
    @JvmField val away = HashMap<Int, Away>()
    /** the opponent of a two-player game is a remote person (QREM) */
    @JvmField var qrem = false

    private val bridge get() = Game.act.bridge

    /** send a JSON message to the phone with connection id cid (mpSend) */
    fun send(cid: Int, o: JSONObject) { try { bridge.send(cid, o.toString()) } catch (e: Exception) { } }

    /** calls f for every connected phone that has a seat (mpEach) */
    fun each(f: (Int, Peer) -> Unit) {
        for ((k, c) in LinkedHashMap(cl)) if (c.seat != null) f(k, c)
    }

    /** connection id of the phone sitting at seat (cidOf) */
    fun cidOf(seat: Int): Int? {
        for ((k, c) in cl) if (c.seat == seat) return k
        return null
    }

    /** ask the phone sitting at [seat] to decide (k = "trump" | "play" ...); cb gets its answer. false when nobody sits there. */
    fun ask(seat: Int, k: String, d: JSONObject, cb: (Any?) -> Unit): Boolean {
        val cid = cidOf(seat) ?: return false
        val id = ++askId
        pend[cid] = Pend(id, k, cb)
        send(cid, JSONObject().put("t", "ask").put("id", id).put("k", k).put("d", d))
        return true
    }

    /** waits (a little) until the remote phones have finished their own animations/speech, then runs fn (mpGate) */
    fun gate(fn: () -> Unit) {
        val t0 = Sched.now()
        var wm = 0L
        fun chk() {
            var w = 0L
            try {
                if (role == "host") {
                    val now = Sched.now()
                    for (c in cl.values) if (c.seat != null && c.freeAt > 0) w = Math.max(w, c.freeAt - now)
                }
            } catch (e: Exception) { }
            wm = Math.max(wm, w)
            val used = Sched.now() - t0
            val cap = Math.min(6000.0, Math.max(700.0, wm * 0.3)).toLong()
            if (w > 0 && used < cap) Sched.later(Math.min(w, cap - used) + 30) { chk() } else fn()
        }
        chk()
    }

    /** forget everything about the current multi-phone game and close the links (mpReset) */
    fun reset() {
        try { bridge.close() } catch (e: Exception) { }
        role = "off"; mode = 0; cl.clear(); started = false; leaving = false
        found.clear(); conn = false; over = false; room = ""
        pend.clear(); rem.fill(false); qrem = false; away.clear()
        Hold.clear()
    }
}
