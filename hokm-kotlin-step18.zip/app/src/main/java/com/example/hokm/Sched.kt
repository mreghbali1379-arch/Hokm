package com.example.hokm

import android.os.Handler
import android.os.Looper

/**
 * Timers with a "generation" guard. The original replaced window.setTimeout so that every timer
 * started before a new game / screen change (GEN++) silently does nothing when it fires.
 * Everything runs on the main thread.
 */
object Sched {
    private val handler = Handler(Looper.getMainLooper())

    /** current generation; bump it (newGen) to cancel every pending guarded timer */
    @Volatile var GEN = 0
        private set

    fun newGen() { GEN++ }

    /** setTimeout with the generation guard */
    fun later(ms: Long, f: () -> Unit): Runnable {
        val g = GEN
        val r = Runnable { if (g == GEN) f() }
        handler.postDelayed(r, Math.max(0L, ms))
        return r
    }

    fun later(ms: Int, f: () -> Unit): Runnable = later(ms.toLong(), f)

    /** timer that ignores the generation (used by things that must survive a screen change) */
    fun laterRaw(ms: Long, f: () -> Unit): Runnable {
        val r = Runnable { f() }
        handler.postDelayed(r, Math.max(0L, ms))
        return r
    }

    fun cancel(r: Runnable?) { if (r != null) handler.removeCallbacks(r) }

    fun post(f: () -> Unit) { handler.post(f) }

    fun now(): Long = System.currentTimeMillis()
}
