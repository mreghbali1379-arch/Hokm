package com.example.hokm

import android.os.Bundle

/**
 * Entry point of the game: sets up settings, sound and the screens.
 */
object Game {
    lateinit var act: MainActivity
        private set
    var app: App? = null
        private set

    fun start(a: MainActivity, saved: Bundle?) {
        act = a
        Prefs.init(a)
        Px.init(a)
        Sound.init(a)
        val ap = App(a)
        app = ap
        ap.setup()
        a.onBack = { ap.back() }
    }

    fun save(out: Bundle) { }

    fun stop() {
        Sound.release()
        app = null
    }
}
