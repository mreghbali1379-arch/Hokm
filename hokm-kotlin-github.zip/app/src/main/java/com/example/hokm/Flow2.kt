package com.example.hokm

import com.example.hokm.Cards.SN
import com.example.hokm.Cards.cname
import com.example.hokm.Cards.idc
import com.example.hokm.Cards.sorted2
import org.json.JSONArray
import org.json.JSONObject

/** The screen as seen by the two-player flow. */
interface Ui2 {
    fun render2()
    fun say2(t: String)
    fun log2Now(t: String)
    fun clearLog2()
    fun clearAct2()
    fun focusFirst2(what: String)
    fun showNewGame2()
    fun keepMsg2(on: Boolean)
    fun pileUpd2()
    /** animation of the two 2s coming out of the pack and going to the pile; returns its length, or null when it cannot run */
    fun asideTwo(out: List<Card>): Long?
    /** animation of a player's two discarded cards going to the pile; returns its length, or null */
    fun dsc2(p: Int, cards: List<Card>?): Long?
    /** remember how the card taken in this step looks, before the screen is redrawn (the page's pick data) */
    fun pickPrep(p: Int, face: Boolean, got: Card, out: Card)
}

/**
 * The flow of the two-player game against the bot: discarding, trump, drawing the 40 cards two by two,
 * turns, tricks and the end of a hand. Ported from start2 / botHakem / confirmDisc / pickTrump2 / drawStep /
 * take2 / startPlay2 / next2 / play2 / endHand2 of the page. Rules and bot are in [Engine2].
 */
class Flow2(private val ui: Ui2) {
    val e = Engine2()

    var botName = "حریف"
    var phase = ""       // disc | trump | aside | draw | drawbot | drawwait | play | end
    var turn = -1
    var step = 0
    var ch = 0
    var up: Card? = null
    var dn: Card? = null
    var busy = false
    var last: List<TP> = ArrayList()
    val sel: MutableList<Card> = ArrayList()

    // the draw that was made for the first hand of a new game (PRE2)
    private var preH = 0
    private var preB = ""

    /** cards in the pile on the table (Q.pile) */
    var pile = 0
    // the two 2s taken out for the whole game (G2OUT) and the ones to leave out of the next deal (PRE2.out)
    private var g2out: List<Card>? = null
    private var preOut: List<Card>? = null
    private var asideEnd = 0L

    fun ow2(p: Int) = if (p == 0) "شما" else botName
    private fun who2(p: Int, q: Int) = if (p == q) "شما" else (if (q == 0) botName else MP.hostName)

    // ---- multi-phone (host side, two players): the opponent is another phone ----
    private fun rc(): Int? = if (MP.role == "host" && MP.mode == 2 && MP.qrem) MP.cidOf(1) else null
    private fun cjs(c: Card) = JSONObject().put("s", c.s).put("r", c.r)
    private fun srt(h: List<Card>) = h.sortedWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }
    private fun mpName2(): String = MP.cl[MP.cidOf(1)]?.name ?: "بازیکن"

    /** show f(0) here and send f(1) to the remote opponent (skip = the player that must not get it) */
    fun pub2(f: (Int) -> String, min: Long = 0, skip: Int = -1, tag: String = "") {
        if (skip != 0) log2(f(0), min)
        val c = rc()
        if (c != null && skip != 1) MP.send(c, JSONObject().put("t", "log").put("x", f(1)).put("w", tag))
    }

    private fun mpAsd(o: JSONObject) { val c = rc(); if (c != null) MP.send(c, o) }
    private fun mpShuf2() { val c = rc(); if (c != null) MP.send(c, JSONObject().put("t", "shf")) }

    private fun sendDraw2(D: Draw.D, nm: String) {
        val c = rc() ?: return
        try {
            val o = JSONObject().put("t", "drw").put("n", 2).put("f", Anim.f)
            o.put("seq", JSONArray().also { a -> D.seq.forEach { a.put(JSONObject().put("p", 1 - it.p).put("c", cjs(it.c))) } })
            o.put("h", 1 - D.h).put("pt", JSONObject.NULL).put("i1", D.i1).put("i2", -1)
            o.put("mv", JSONArray().put(0).put(1)).put("nm", JSONArray().put("شما").put(nm))
            MP.send(c, o)
        } catch (x: Exception) { }
    }

    /** the full state for the remote opponent, sent after every redraw (mpSnap2) */
    fun mpSnap2() {
        val c = rc() ?: return
        if (phase == "") return
        val q = e
        val o = JSONObject().put("t", "st")
        o.put("status", "حکم: " + (if (q.trump < 0) "—" else Cards.SU[q.trump] + " " + SN[q.trump]) + " | حاکم: " + who2(q.hk, 1) +
            " | دست‌ها: شما " + q.tk[1] + " " + MP.hostName + " " + q.tk[0] + " | امتیاز: شما " + q.sc[1] + " " + MP.hostName + " " + q.sc[0])
        val dt = if (q.trick.isNotEmpty()) q.trick else q.shown
        o.put("table", JSONArray().also { a -> dt.forEach { a.put(JSONObject().put("n", who2(it.p, 1)).put("c", cjs(it.c)).put("r", if (it.p == 1) 0 else 2)) } })
        o.put("hand", JSONArray().also { a -> srt(q.hands[1]).forEach { a.put(cjs(it)) } })
        o.put("tr", if (q.trump < 0) JSONObject.NULL else q.trump)
        o.put("hr", if (q.hk == 1) 0 else 2).put("hkn", who2(q.hk, 1))
        o.put("tk", JSONArray().put(q.tk[1]).put(q.tk[0]))
        o.put("tn", if (phase == "play") (if (turn == 1) 0 else 2) else -1)
        val win = q.trick.isEmpty() && q.shown.isNotEmpty()
        o.put("wr", if (win) (if (turn == 1) 0 else 2) else JSONObject.NULL)
        o.put("ot", phase == "play" && turn == 0)
        o.put("fan", JSONArray().put(JSONObject().put("r", 2).put("n", q.hands[0].size).put("t", MP.hostName)))
        o.put("pl", pile)
        o.put("win", if (win) who2(turn, 1) else JSONObject.NULL)
        o.put("sc", JSONArray().put(q.sc[1]).put(q.sc[0]))
        o.put("ph", phase).put("wm", turn == 1)
        MP.send(c, o)
    }

    fun mpOver() { if (MP.role == "host") rc()?.let { MP.send(it, JSONObject().put("t", "over")) } }

    fun log2(t: String, min: Long = 0) {
        val d = Spk.slot(t, min)
        if (d > 0) Sched.later(d) { ui.log2Now(t) } else ui.log2Now(t)
    }

    private fun hand2Text(h: List<Card>) = Cards.handText(h)

    // ---------------------------------------------------------------- start

    /** start2: nm = a new game (draw for the first hakem), otherwise the next hand */
    fun start2(nm: Boolean) {
        if (Hold.hold("start2", "[$nm]") { start2(nm) }) return
        val g = Sched.GEN
        val go = {
            if (g == Sched.GEN) {
                Sched.later(if (nm) Anim.ad(60) else Anim.ad(250)) {
                    if (g == Sched.GEN) {
                        ui.clearLog2()
                        aside2(nm) {
                            if (g == Sched.GEN) {
                                Sound.psnd("shuffle", true) {
                                    if (!nm && e.sc[0] + e.sc[1] != 0) pub2({ q -> "دور جدید. حاکم: " + who2(e.hk, q) + "." }, 0, -1, "snd")
                                    mpShuf2()
                                }
                                Sched.later(Anim.ad(900)) {
                                    if (g == Sched.GEN) deal2(nm)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (nm) {
            val D = Draw.genDraw(2, true)
            preH = D.h; preB = if (rc() != null) mpName2() else Names.pickNames(1)[0]
            sendDraw2(D, MP.hostName)
            Fx.drawScene(D, listOf("شما", preB), { go() }, null) { t, q -> ui.say2(t); if (!q) ui.log2Now(t) }
        } else go()
    }

    private fun pick2Twos(): List<Card> {
        val s = arrayListOf(0, 1, 2, 3)
        for (i in 3 downTo 1) { val j = Math.floor(Math.random() * (i + 1)).toInt(); val t = s[i]; s[i] = s[j]; s[j] = t }
        return listOf(Card(s[0], 2), Card(s[1], 2))
    }

    /** two 2s come out of the pack at the start of the game, are shown and put aside; later hands reuse them (aside2) */
    private fun aside2(first: Boolean, cb: () -> Unit) {
        if (!first && g2out != null) { preOut = g2out; pile = 2; try { ui.pileUpd2() } catch (x: Exception) { }; cb(); return }
        if (first) g2out = null
        var done = false
        val fin = { if (!done) { done = true; cb() } }
        val g = Sched.GEN
        val out = pick2Twos(); preOut = out; g2out = out; pile = 0
        try { ui.pileUpd2() } catch (x: Exception) { }
        val cj = JSONArray().also { a -> out.forEach { a.put(JSONObject().put("s", it.s).put("r", it.r)) } }
        val tot = try { ui.asideTwo(out) } catch (x: Exception) { null }
        ui.say2("دو کارت دو کنار گذاشته شد.")
        mpAsd(JSONObject().put("t", "asd").put("k", "two").put("c", cj))
        if (tot == null) {
            // no animation possible: the sound and the message still come every time
            Sound.cardSnd(); Sched.later(Anim.ad(420)) { Sound.cardSnd() }
            pile = 2; try { ui.pileUpd2() } catch (x: Exception) { }
            Sched.later(Anim.ad(900)) { fin() }
            return
        }
        Sched.later(tot + Anim.ad(60)) { if (g == Sched.GEN) { pile = 2; ui.pileUpd2() } }
        Sched.later(tot + Anim.ad(600)) { if (g == Sched.GEN) fin() }
    }

    /** a player puts two cards aside (dsc2): p = 0 you, 1 the opponent; cards = yours; rem = what the opponent put aside */
    private fun dsc2(p: Int, cards: List<Card>?, rem: List<Card>? = null) {
        if (p == 0) mpAsd(JSONObject().put("t", "asd").put("k", "opp"))
        else if (rem != null && rem.isNotEmpty())
            mpAsd(JSONObject().put("t", "asd").put("k", "me").put("c", JSONArray().also { a -> rem.forEach { a.put(JSONObject().put("s", it.s).put("r", it.r)) } }))
        val tot = try { ui.dsc2(p, cards) } catch (x: Exception) { null }
        if (tot == null) { Sound.cardSnd(); Sound.cardSnd() }
        val t = tot ?: 0L
        asideEnd = Sched.now() + t + Anim.ad(800)
        Sched.later(t) { pile += 2; ui.pileUpd2() }
    }

    private fun deal2(nm: Boolean) {
        Fx.hn++
        if (nm) { e.sc = intArrayOf(0, 0); e.hk = preH; botName = preB }
        var d = Cards.allCards()
        Cards.shuf(d)
        val out2 = preOut
        d = if (out2 != null) ArrayList(d.filter { c -> out2.none { it.s == c.s && it.r == c.r } })
        else { var rm = 0; ArrayList(d.filter { c -> if (c.r == 2 && rm < 2) { rm++; false } else true }) }
        e.deck = d
        e.hands = arrayOf(ArrayList(), ArrayList())
        e.trump = -1; e.tk = intArrayOf(0, 0); e.trick = ArrayList(); e.shown = ArrayList()
        e.played = HashSet(); e.gone = HashSet(); e.known = ArrayList()
        e.vo = arrayOf(HashSet(), HashSet()); e.kt = -1
        out2?.forEach { e.gone.add(idc(it)) }
        preOut = null
        step = 0; sel.clear(); busy = false; last = ArrayList()
        for (k in 0 until 5) e.hands[e.hk].add(e.deck.removeAt(e.deck.size - 1))
        for (k in 0 until 5) e.hands[1 - e.hk].add(e.deck.removeAt(e.deck.size - 1))
        if (e.hk == 0) {
            phase = "disc"; ui.render2()
            log2("پنج کارت شما: " + hand2Text(e.hands[0]) + ". دو کارت را کنار بگذارید.")
            ui.say2("دو کارت را برای کنار گذاشتن انتخاب کنید.")
            ui.focusFirst2("#hand2 button")
            rc()?.let { MP.send(it, JSONObject().put("t", "log").put("x", "پنج کارت شما: " + hand2Text(e.hands[1]) + ".").put("w", "deal").put("h", "hand5")) }
        } else if (rc() != null) remHakem() else botHakem()
    }

    private fun pickOf(list: List<Card>, v: Any?, n: Int): List<Card>? {
        val a = v as? JSONArray ?: return null
        if (a.length() != n) return null
        val o = ArrayList<Card>()
        for (i in 0 until a.length()) {
            val x = a.optJSONObject(i) ?: return null
            val c = list.firstOrNull { it.s == x.optInt("s", -9) && it.r == x.optInt("r", -9) } ?: return null
            if (o.contains(c)) return null
            o.add(c)
        }
        return o
    }

    private fun handJ(l: List<Card>) = JSONArray().also { a -> l.forEach { a.put(cjs(it)) } }

    /** the remote opponent is the hakem: he discards two cards and chooses the trump (remHakem) */
    private fun remHakem() {
        phase = "remwait"; ui.render2()
        log2("پنج کارت شما: " + hand2Text(e.hands[0]) + ". دو کارت را کنار بگذارید.")
        ui.say2(botName + " حاکم است و کارت‌هایش را انتخاب می‌کند...")
        val h5 = ArrayList(e.hands[1])
        fun again() {
            MP.ask(1, "disc", JSONObject().put("hand", handJ(h5)).put("trump", JSONObject.NULL)) { v ->
                val sel2 = pickOf(h5, v, 2)
                if (sel2 == null) again()
                else {
                    e.hands[1] = ArrayList(h5.filter { !sel2.contains(it) })
                    dsc2(1, null, sel2)
                    pub2({ botName + " دو کارتش را کنار گذاشت." }, 0, 1)
                    fun t2() {
                        MP.ask(1, "trump", JSONObject().put("hand", handJ(e.hands[1]))) { tv ->
                            val T = tv as? Int ?: -1
                            if (T !in 0..3) t2()
                            else {
                                e.trump = T; phase = "disc"; ui.render2()
                                pub2({ q -> if (q == 1) "حکم " + SN[T] + " شد." else botName + " حکم را تعیین کرد: " + SN[T] + "." })
                                ui.say2("حکم " + SN[T] + " است. دو کارت را برای کنار گذاشتن انتخاب کنید.")
                                ui.focusFirst2("#hand2 button")
                            }
                        }
                    }
                    t2()
                }
            }
        }
        again()
    }

    /** the trump is known (chosen by me); now the remote opponent discards two cards (remDisc) */
    private fun remDisc(T: Int) {
        phase = "remwait"; ui.render2(); ui.say2("")
        val h5 = ArrayList(e.hands[1])
        fun again() {
            MP.ask(1, "disc", JSONObject().put("hand", handJ(h5)).put("trump", T)) { v ->
                val sel2 = pickOf(h5, v, 2)
                if (sel2 == null) again()
                else {
                    e.hands[1] = ArrayList(h5.filter { !sel2.contains(it) })
                    dsc2(1, null, sel2)
                    phase = "aside"
                    log2(botName + " دو کارتش را کنار گذاشت.")
                    beginDraw()
                }
            }
        }
        again()
    }

    private fun botHakem() {
        if (Hold.hold("botHakem", "[]") { botHakem() }) return
        val h = e.hands[1]
        val ch = Engine2.choose2Hakem(h, 1, e.gone)
        val bT = ch.T; val keep = ch.keep
        e.trump = bT
        phase = "disc"; ui.render2()
        e.hands[1] = ArrayList(keep)
        h.filter { !keep.contains(it) }.forEach { e.gone.add(idc(it)) }
        dsc2(1, null)
        log2("پنج کارت شما: " + hand2Text(e.hands[0]) + ". دو کارت را کنار بگذارید.")
        log2(botName + " حاکم است، دو کارتش را کنار گذاشت و حکم را تعیین کرد: " + SN[bT] + ".")
        ui.render2()
        ui.say2("حکم " + SN[bT] + " است. دو کارت را برای کنار گذاشتن انتخاب کنید.")
        ui.focusFirst2("#hand2 button")
    }

    // ---------------------------------------------------------------- discarding and trump

    /** the player toggles one card of the five for discarding */
    fun toggleSel(c: Card) {
        val k = sel.indexOf(c)
        if (k >= 0) sel.removeAt(k)
        else if (sel.size < 2) sel.add(c)
        else ui.log2Now("فقط دو کارت را می‌شود انتخاب کرد.")
        ui.render2()
    }

    fun confirmDisc() {
        if (Hold.hold("confirmDisc", "[]", true) { confirmDisc() }) return
        if (sel.size != 2) {
            ui.say2("باید دقیقاً دو کارت انتخاب کنید.")
            ui.log2Now("باید دقیقاً دو کارت انتخاب کنید.")
            return
        }
        dsc2(0, ArrayList(sel))
        e.hands[0] = ArrayList(e.hands[0].filter { !sel.contains(it) }); sel.clear()
        val h_ = hand2Text(e.hands[0])
        log2("دو کارت کنار گذاشته شد. کارت‌های شما: $h_.")
        if (e.hk == 0) {
            phase = "trump"; ui.render2()
            ui.say2("حکم را انتخاب کنید."); log2("حکم را انتخاب کنید.")
            ui.focusFirst2("#hand2 .pick button")
        } else beginDraw()
    }

    fun pickTrump2(T: Int) {
        if (Hold.hold("pickTrump2", "[$T]", e.hk == 0) { pickTrump2(T) }) return
        if (phase != "trump" && phase != "remwait") return
        if (rc() != null) { e.trump = T; pub2({ "حکم " + SN[T] + " شد." }); remDisc(T); return }
        e.trump = T
        val h = e.hands[1]
        e.hands[1] = ArrayList(h.map { Pair(it, Engine2.v2(it, T)) }.sortedByDescending { it.second }.take(3).map { it.first })
        h.filter { !e.hands[1].contains(it) }.forEach { e.gone.add(idc(it)) }
        dsc2(1, null)
        phase = "aside"
        log2("حکم " + SN[T] + " شد.")
        beginDraw()
    }

    // ---------------------------------------------------------------- drawing the 40 cards

    private fun beginDraw() {
        if (Hold.hold("beginDraw", "[]") { beginDraw() }) return
        val w = asideEnd - Sched.now()
        if (w > 0) { val g = Sched.GEN; Sched.later(w) { if (g == Sched.GEN) { phase = "draw"; step = 0; drawStep() } }; return }
        phase = "draw"; step = 0; drawStep()
    }

    private fun drawStep() {
        if (step >= 20) { startPlay2(); return }
        ch = if (step % 2 == 0) e.hk else 1 - e.hk
        up = e.deck.removeAt(e.deck.size - 1); dn = e.deck.removeAt(e.deck.size - 1)
        if (ch == 0) {
            phase = "draw"; ui.render2()
            val m = "مرحله " + (step + 1) + ". کارت رو: " + cname(up!!) + "."
            ui.say2(m); log2(m); ui.focusFirst2("#a2 button")
        } else if (rc() != null) {
            phase = "drawbot"; ui.render2(); ui.say2("")
            val g_ = Sched.GEN
            Sched.later(Anim.ad(450)) {
                if (g_ == Sched.GEN && phase == "drawbot")
                    MP.ask(1, "draw", JSONObject().put("up", cjs(up!!)).put("n", step + 1)) { v -> take2(1, v == "face") }
            }
        } else {
            phase = "drawbot"; ui.render2(); ui.say2("")
            Sched.later(Math.max(Anim.ad(900).toLong(), Fx.pkEnd - Sched.now() + Anim.ad(700))) { botDraw() }
        }
    }

    private fun botDraw() {
        if (Hold.hold("botDraw", "[]") { botDraw() }) return
        take2(1, Engine2.draw2Face(e.hands[1], e.trump, up!!, e.gone))
    }

    /** one of the two cards of a drawing step reached the pile (land of the pick animation) */
    fun pickLand() { pile += 1; try { ui.pileUpd2() } catch (x: Exception) { } }

    /** a player takes the face-up card (face = true) or the hidden one */
    fun take2(p: Int, face: Boolean) {
        if (Hold.hold("take2", "[$p,$face]", p == 0) { take2(p, face) }) return
        if (p == 0 && (phase != "draw" || ch != 0)) return
        val got = if (face) up!! else dn!!
        val out = if (face) dn!! else up!!
        e.hands[p].add(got)
        val priv = if (face) "کارت رو را برداشتید: " + cname(got) + ". کارت پنهان که کنار گذاشته شد: " + cname(out) + "."
        else "کارت پنهان را برداشتید: " + cname(got) + ". کارت رو که کنار رفت: " + cname(out) + "."
        ui.pickPrep(p, face, got, out)
        val rcid = rc()
        if (p == 0) { log2(priv); if (rcid != null) mpAsd(JSONObject().put("t", "asd").put("k", "pickopp")) }
        else {
            if (rcid == null) e.gone.add(idc(out))
            else {
                mpAsd(JSONObject().put("t", "asd").put("k", "pickme").put("got", cjs(got)).put("out", cjs(out)))
                MP.send(rcid, JSONObject().put("t", "log").put("x", priv).put("w", "pk"))
            }
        }
        step++
        if (p == 1) {
            phase = "drawwait"; ui.render2()
            val g = Sched.GEN
            Sched.later(Math.max(Anim.ad(600).toLong(), Fx.pkEnd - Sched.now() + Anim.ad(450))) { if (g == Sched.GEN && phase == "drawwait") drawStep() }
        } else drawStep()
    }

    // ---------------------------------------------------------------- play

    private fun startPlay2() {
        phase = "play"; turn = e.hk; e.trick = ArrayList(); e.shown = ArrayList()
        log2("کارت‌های شما: " + hand2Text(e.hands[0]) + ".")
        rc()?.let { MP.send(it, JSONObject().put("t", "log").put("x", "کارت‌های شما: " + hand2Text(e.hands[1]) + ".")) }
        ui.render2(); next2()
    }

    fun next2() {
        if (Hold.hold("next2", "[]") { next2() }) return
        ui.render2(); MP.onSync?.invoke()
        if (phase != "play") return
        if (turn == 0) {
            val pr = {
                val m = "نوبت شماست. " + (if (e.trick.isNotEmpty()) "خال زمین: " + SN[e.trick[0].c.s] + "." else "شما شروع می‌کنید.")
                ui.say2(m); log2(m); ui.focusFirst2("#hand2 button.ok")
            }
            val wd = Math.max(Math.max(Sound.TBU, Spk.end), Fx.pkEnd) - Sched.now()
            if (wd > 0) {
                val g = Sched.GEN
                busy = true
                Sched.later(wd + Anim.ad(150)) {
                    busy = false
                    if (g == Sched.GEN && phase == "play" && turn == 0) pr()
                }
            } else pr()
            return
        }
        if (rc() != null) {
            val L1 = e.legal2(1)
            ui.say2("")
            val g_ = Sched.GEN
            val go_ = {
                if (g_ == Sched.GEN && phase == "play" && turn == 1) {
                    if (rc() == null) next2()
                    else MP.gate {
                        MP.ask(1, "play", JSONObject().put("cards", handJ(L1)).put("led", if (e.trick.isNotEmpty()) e.trick[0].c.s else -1)) { v ->
                            val o = v as? JSONObject
                            val c = if (o == null) null else L1.firstOrNull { it.s == o.optInt("s", -9) && it.r == o.optInt("r", -9) }
                            if (c != null && turn == 1 && phase == "play") play2(1, c)
                            else if (phase == "play" && turn == 1) next2()
                        }
                    }
                }
            }
            val wd = Math.max(Math.max(Sound.TBU, Spk.end), Fx.pkEnd) - Sched.now()
            if (wd > 0) Sched.later(wd + Anim.ad(150)) { go_() } else go_()
            return
        }
        ui.say2(""); busy = true
        val d = Math.max(
            if (e.shown.isNotEmpty()) 1000L else 600L,
            Math.max(Math.max(Sound.TBU - Sched.now() + Anim.ad(250), Spk.end - Sched.now() + Anim.ad(100)), Fx.pkEnd - Sched.now() + Anim.ad(200))
        )
        Sched.later(d) {
            MP.gate {
                busy = false
                if (rc() != null && turn == 1) next2() else play2(1, e.bot2Pick())
            }
        }
    }

    /** the remote opponent came back (or was added): he takes his seat again (seatIn of the page, two-player case) */
    fun seatIn2(cid: Int, nm: String, t: String) {
        MP.qrem = true; botName = nm
        ui.say2(t); log2(t); ui.render2()
        MP.send(cid, JSONObject().put("t", "log").put("x", "کارت‌های شما: " + hand2Text(e.hands[1]) + "."))
        if (phase == "play" && turn == 1 && !busy) next2()
    }

    /** the remote opponent left (or was removed): the bot takes his place */
    fun remDrop(c: Peer, hadAsk: Boolean, kick: Boolean) {
        MP.qrem = false
        val t = c.name + (if (kick) " از بازی حذف شد و ربات جای او بازی می‌کند." else " قطع شد و ربات تا اتصال دوباره جای او بازی می‌کند.")
        ui.say2(t); log2(t)
        if (phase == "remwait") { if (e.trump < 0) botHakem() else pickTrump2(e.trump) }
        else if (phase == "drawbot" && ch == 1 && hadAsk) botDraw()
        else if (phase == "play" && turn == 1 && hadAsk) next2()
    }

    /** you chose card c */
    fun humanPlay(c: Card) {
        if (turn == 0 && !busy && phase == "play") play2(0, c)
    }

    fun play2(p: Int, c: Card) {
        if (Hold.hold("play2", "[$p,${c.s},${c.r}]", p == 0) { play2(p, c) }) return
        e.shown = ArrayList()
        if (e.trick.isNotEmpty() && c.s != e.trick[0].c.s) e.vo[p].add(e.trick[0].c.s)
        e.hands[p] = ArrayList(e.hands[p].filter { it !== c }); e.played.add(idc(c))
        e.trick.add(TP(p, c))
        pub2({ q -> who2(p, q) + " " + cname(c) + (if (p == q) " بازی کردید" else " بازی کرد") + (if (c.s == e.trump) " (حکم)." else ".") },
            Math.max(0L, Anim.ad(360) - Sound.CSO.toLong()), p, "card")
        Sched.later(Math.max(0, Anim.ad(340) - Sound.CSO)) { Sound.cardSnd() }
        if (e.trick.size < 2) { turn = 1 - p; next2(); return }
        val a = e.trick[0]; val b = e.trick[1]
        val w = if (e.beats2(b.c, a.c)) b.p else a.p
        e.tk[w]++; last = ArrayList(e.trick); e.shown = ArrayList(e.trick); e.trick = ArrayList(); turn = w
        val mf = { q: Int -> who2(w, q) + (if (w == q) " دست را بردید. شما " else " دست را برد. شما ") + e.tk[q] + "، " + who2(1 - q, q) + " " + e.tk[1 - q] + "." }
        val wm = { min: Int -> Sched.later(min) { ui.say2(mf(0)) }; pub2(mf, min.toLong(), -1, "snd") }
        ui.render2()
        run {
            val hs = if (e.tk[0] >= 7) 0 else if (e.tk[1] >= 7) 1 else -1
            if (hs >= 0) {
                if (e.tk[1 - hs] == 0 && e.kt < 0) e.kt = hs
                if (e.tk[1 - hs] > 0 || e.tk[hs] == 13) { wm(Anim.ad(400)); endHand2(); return }
            }
        }
        Sound.TBU = Sched.now() + Anim.ad(1000) + (if (Sound.on) (if (w == 0) Sound.EST["trick"]!! else Sound.EST["tlose"]!!).toLong() else Anim.ad(400).toLong())
        wm(Anim.ad(1000))
        Sched.later(Anim.ad(1000)) { Sound.psnd(if (w == 0) "trick" else "tlose", true) }
        next2()
    }

    private fun endHand2() {
        val t = if (e.tk[0] >= 7) 0 else 1
        val bam = e.tk[t] == 13
        val bn = if (t == e.hk) "بام" else "پر بام"
        val kot = bam || e.kt == t
        val pts = if (kot) (if (t == e.hk) 2 else 3) else 1
        e.sc[t] += pts
        if (bam) e.sc[t] = Math.max(e.sc[t], 7)
        phase = "end"
        val gm = e.sc[t] >= 7
        val mf = { q: Int ->
            val fin = " امتیاز نهایی: شما " + e.sc[q] + "، " + who2(1 - q, q) + " " + e.sc[1 - q] + "."
            if (bam) ((if (t == q) "شما $bn کردید و بازی را بردید!" else who2(t, q) + " $bn کرد و بازی را برد.") + fin)
            else if (gm) ((if (t == q) "شما بازی را بردید!" else who2(t, q) + " بازی را برد.") + fin)
            else ((if (t == q) "شما" else who2(t, q)) + (if (t == q) " این دور را بردید" else " این دور را برد") +
                (if (kot) (if (t == e.hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)") else " (۱ امتیاز)") +
                ". امتیاز: شما " + e.sc[q] + "، " + who2(1 - q, q) + " " + e.sc[1 - q] + ".")
        }
        val m0 = mf(0); val m1 = mf(1)
        if (t != e.hk) e.hk = 1 - e.hk
        MP.onSync?.invoke()
        rc()?.let { MP.send(it, JSONObject().put("t", "log").put("x", m1).put("w", "snd")) }
        val ann = { ui.say2(m0); log2(m0) }
        ui.render2()
        ui.clearAct2()
        if (gm) {
            mpOver()
            Sound.endSnd(t, kot, gm, ann)
            Sound.afterSnd { ui.showNewGame2() }
        } else {
            Sound.endSnd(t, kot, gm, ann)
            Sched.later(if (Sound.on) 4600 else 3300) { start2(false) }
        }
    }

    // ---------------------------------------------------------------- save / resume

    private fun cj(c: Card) = JSONObject().put("s", c.s).put("r", c.r)
    private fun jc(o: JSONObject) = Card(o.getInt("s"), o.getInt("r"))
    private fun ints(a: Collection<Int>) = JSONArray().also { j -> a.forEach { j.put(it) } }
    private fun nul(v: Int): Any = if (v < 0) JSONObject.NULL else v

    fun snapshot(): JSONObject? {
        if (e.hands[0].isEmpty() && phase == "") return null
        val q = JSONObject()
        fun tps(l: List<TP>) = JSONArray().also { a -> l.forEach { a.put(JSONObject().put("p", it.p).put("c", cj(it.c))) } }
        q.put("sc", ints(e.sc.toList())); q.put("hk", e.hk)
        q.put("hands", JSONArray().also { h -> e.hands.forEach { l -> h.put(JSONArray().also { a -> l.forEach { a.put(cj(it)) } }) } })
        q.put("tk", ints(e.tk.toList()))
        q.put("trick", tps(e.trick)); q.put("shown", tps(e.shown)); q.put("last", tps(last))
        q.put("played", ints(e.played)); q.put("gone", ints(e.gone))
        q.put("vo", JSONArray().also { v -> e.vo.forEach { v.put(ints(it)) } })
        q.put("phase", phase); q.put("trump", nul(e.trump)); q.put("turn", nul(turn)); q.put("kt", nul(e.kt))
        return JSONObject().put("m", 2).put("BOTN", botName).put("Q", q)
    }

    fun resume(x: JSONObject, msg: String? = null, opp: String? = null) {
        val t = msg ?: "بازی ذخیره‌شده ادامه پیدا کرد."
        val q = x.getJSONObject("Q")
        val sca = q.getJSONArray("sc"); e.sc = intArrayOf(sca.getInt(0), sca.getInt(1))
        e.hk = q.getInt("hk")
        val hs = q.getJSONArray("hands")
        e.hands = Array(2) { i -> val a = hs.getJSONArray(i); ArrayList<Card>().also { l -> for (k in 0 until a.length()) l.add(jc(a.getJSONObject(k))) } }
        val tka = q.getJSONArray("tk"); e.tk = intArrayOf(tka.getInt(0), tka.getInt(1))
        fun tps(k: String): MutableList<TP> {
            val a = q.optJSONArray(k) ?: return ArrayList()
            return ArrayList<TP>().also { l -> for (i in 0 until a.length()) { val o = a.getJSONObject(i); l.add(TP(o.getInt("p"), jc(o.getJSONObject("c")))) } }
        }
        e.trick = tps("trick"); e.shown = tps("shown"); last = tps("last")
        fun set(k: String) = HashSet<Int>().also { s2 -> val a = q.getJSONArray(k); for (i in 0 until a.length()) s2.add(a.getInt(i)) }
        e.played = set("played"); e.gone = set("gone"); e.known = ArrayList()
        val va = q.getJSONArray("vo")
        e.vo = Array(2) { i -> HashSet<Int>().also { s2 -> val a = va.getJSONArray(i); for (k in 0 until a.length()) s2.add(a.getInt(k)) } }
        phase = q.getString("phase")
        e.trump = if (q.isNull("trump")) -1 else q.getInt("trump")
        turn = if (q.isNull("turn")) -1 else q.getInt("turn")
        e.kt = if (q.isNull("kt")) -1 else q.getInt("kt")
        sel.clear(); busy = false
        botName = opp ?: x.optString("BOTN", botName)
        ui.clearLog2(); ui.clearAct2()
        if (phase == "play") {
            ui.render2(); log2(t); ui.say2(t); next2()
        } else if (phase == "end" && (e.sc[0] >= 7 || e.sc[1] >= 7)) {
            ui.render2(); ui.say2("بازی قبلاً تمام شده بود."); ui.showNewGame2()
        } else {
            start2(false); log2(t)
        }
    }

    @Suppress("unused")
    private fun unused() = sorted2(e.hands[0])
}
