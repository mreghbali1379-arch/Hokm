package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import com.example.hokm.Cards.fa
import org.json.JSONObject

/**
 * The multi-phone lobby (the page's #g6): choosing the connection method, hosting a table, joining one,
 * the player list and the seating plan. Also handles the transport events and the lobby messages.
 */
class Lobby(private val act: MainActivity, private val dlg: Dialogs, private val app: App) {
    val view = LinearLayout(act)

    private val NETN = mapOf("bt" to "بلوتوث", "lan" to "وای‌فای (یک شبکهٔ مشترک)", "direct" to "وای‌فای مستقیم")
    private val NETH = mapOf(
        "bt" to "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن در تنظیمات بلوتوث نیست.",
        "lan" to "همه‌ی گوشی‌ها باید به یک شبکه‌ی وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها. بعد میزبان بازی را باز می‌کند و بقیه نامش را در فهرست می‌بینند.",
        "direct" to "وای‌فای همه‌ی گوشی‌ها باید روشن و گوشی‌ها نزدیک هم باشند. لازم نیست به مودم یا شبکه‌ای وصل شوید؛ بقیه مستقیم به گوشی میزبان وصل می‌شوند."
    )
    private val SEATL = mapOf(1 to "حریف سمت راست شما", 2 to "یار شما", 3 to "حریف سمت چپ شما")
    private val SEATT = mapOf(2 to "یار شما (روبه‌رو)", 1 to "حریف سمت راست شما", 3 to "حریف سمت چپ شما")
    private val SEATS = listOf(2, 1, 3)

    private var NET = Prefs.net
    private var btRetry: ((Boolean) -> Unit)? = null
    private var btN = 0
    private val bridge get() = act.bridge

    // panels
    private val l1 = LinearLayout(act)
    private val l3 = LinearLayout(act)
    private val l4 = LinearLayout(act)
    private val l5 = LinearLayout(act)
    private val lst = TextView(act)

    private lateinit var nm6: EditText
    private lateinit var gen6: Spinner
    private lateinit var nmrow: LinearLayout
    private lateinit var netb: Button
    private lateinit var nethint: TextView
    private lateinit var l3t: TextView
    private lateinit var mds: Spinner
    private lateinit var go6: Button
    private lateinit var pl6: LinearLayout
    private lateinit var dev6: LinearLayout
    private lateinit var st6: LinearLayout
    private lateinit var l5t: TextView
    private lateinit var pdrow: LinearLayout
    private lateinit var pd6: Spinner
    private var uiBusy = false

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun tv(t: String, size: Float = 15f, bold: Boolean = false): TextView {
        val v = TextView(act); v.text = t; v.textSize = size; v.setTextColor(Px.tx)
        v.gravity = Gravity.CENTER
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, Px.dp(6), 0, Px.dp(6))
        return v
    }
    private fun btn(t: String, f: () -> Unit): Button {
        val b = dlg.btn(t, true, f)
        val l = lp(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }
    private fun panel(p: LinearLayout) { p.orientation = LinearLayout.VERTICAL; p.gravity = Gravity.CENTER_HORIZONTAL }
    private fun spinner(items: List<String>, desc: String): Spinner {
        val s = Spinner(act)
        s.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, items)
        s.speakLabel(desc)
        return s
    }
    private fun spLp() = lp(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), Px.dp(48)).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.setMargins(0, Px.dp(6), 0, Px.dp(6)) }

    init {
        MP.onSync = { mpSync() }
        view.orientation = LinearLayout.VERTICAL
        view.gravity = Gravity.CENTER_HORIZONTAL
        view.addView(app.moreButtonView())
        view.addView(tv("بازی با چند گوشی", 22f, true).also { it.accessibilityHeadingCompat() })

        // ---- l1: name, connection method, host / join ----
        panel(l1)
        nmrow = LinearLayout(act); panel(nmrow)
        nmrow.addView(tv("نام شما در بازی (بقیه‌ی بازیکنان همین نام را می‌بینند):"))
        nm6 = EditText(act); nm6.filters = arrayOf(android.text.InputFilter.LengthFilter(20)); nm6.textSize = 16f
        nm6.setTextColor(Px.tx); nm6.isSingleLine = true; nm6.contentDescription = "نام شما در بازی"
        nmrow.addView(nm6, spLp())
        nmrow.addView(tv("جنسیت شما:"))
        gen6 = spinner(listOf("زن", "مرد"), "جنسیت شما")
        nmrow.addView(gen6, spLp())
        l1.addView(nmrow)
        l1.addView(tv("برای بازی با چند گوشی، همه‌ی گوشی‌ها باید این برنامه را داشته باشند و همه یک «روش اتصال» را انتخاب کنند. توضیح روش انتخاب‌شده را زیر دکمهٔ «روش اتصال» می‌بینید."))
        netb = btn("روش اتصال: بلوتوث") { netChoose() }
        l1.addView(netb)
        nethint = tv("")
        l1.addView(nethint)
        l1.addView(btn("میزبان بازی می‌شوم") { lobbyHost(false) })
        l1.addView(btn("به بازی دیگری می‌پیوندم") { lobbyJoin(false) })
        l1.addView(btn("بازی‌های قبلی") { prevAll() })
        view.addView(l1)

        // ---- l3: host waiting room ----
        panel(l3)
        l3t = tv("")
        l3.addView(l3t)
        l3.addView(tv("نوع بازی:"))
        mds = spinner(listOf("بازی چهار نفره", "بازی دو نفره"), "نوع بازی")
        mds.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (!uiBusy) setMode(if (pos == 0) 4 else 2) }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        l3.addView(mds, spLp())
        pl6 = LinearLayout(act); panel(pl6)
        l3.addView(pl6)
        go6 = btn("شروع بازی") { hostNext() }
        l3.addView(go6)
        l3.addView(btn("لغو") { mpLeave() })
        view.addView(l3)

        // ---- l5: seating plan ----
        panel(l5)
        l5.addView(tv("چینش بازیکن‌ها", 18f, true))
        l5t = tv("")
        l5.addView(l5t)
        st6 = LinearLayout(act); panel(st6)
        l5.addView(st6)
        pdrow = LinearLayout(act); panel(pdrow)
        pdrow.addView(tv("تعیین یار:"))
        pd6 = spinner(listOf("با قرعه (دو آس اول: حاکم و یارش)", "بدون قرعه (یار همان نفرِ روبه‌رو طبق چینش شماست)"), "تعیین یار")
        pdrow.addView(pd6, spLp())
        l5.addView(pdrow)
        l5.addView(btn("شروع بازی") { hostGo() })
        view.addView(l5)

        // ---- l4: nearby games list ----
        panel(l4)
        l4.addView(tv("بازی نزدیک را از فهرست انتخاب کنید (جست‌وجو ادامه دارد):"))
        dev6 = LinearLayout(act); panel(dev6)
        l4.addView(dev6)
        l4.addView(btn("لغو") { mpLeave() })
        view.addView(l4)

        lst.textSize = 15f; lst.setTextColor(Px.tx); lst.gravity = Gravity.CENTER
        lst.setPadding(Px.dp(8), Px.dp(10), Px.dp(8), Px.dp(10))
        lst.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        view.addView(lst)
        show6("l1")
    }

    private fun TextView.accessibilityHeadingCompat() {
        if (android.os.Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
    }

    fun setLst(t: String) { lst.text = t }

    fun show6(id: String) {
        l1.visibility = if (id == "l1") View.VISIBLE else View.GONE
        l3.visibility = if (id == "l3") View.VISIBLE else View.GONE
        l4.visibility = if (id == "l4") View.VISIBLE else View.GONE
        l5.visibility = if (id == "l5") View.VISIBLE else View.GONE
    }

    private fun shown(id: String) = when (id) {
        "l1" -> l1.visibility == View.VISIBLE
        "l3" -> l3.visibility == View.VISIBLE
        "l4" -> l4.visibility == View.VISIBLE
        else -> l5.visibility == View.VISIBLE
    }

    /** the phone's back button inside the lobby; true = handled */
    fun back(): Boolean {
        if (shown("l1")) { app.showCreatePanel(); return true }
        if (shown("l3")) { app.goMain(); return true }
        if (shown("l5")) { hostSeatBack(); return true }
        if (shown("l4")) { if (MP.conn) app.goMain() else btBack(); return true }
        return true
    }

    // ---------------------------------------------------------------- entry

    private fun savedName(): String = Prefs.name
    private fun savedGender(): String = Prefs.gender

    fun showBT() {
        app.showScreen("g6"); show6("l1"); uiNet()
        val sv = savedName()
        nm6.setText(sv)
        gen6.setSelection(if (savedGender() == "m") 1 else 0)
        nmrow.visibility = if (sv.isNotEmpty() && savedGender().isNotEmpty()) View.GONE else View.VISIBLE
        setLst("")
        app.focusNode(if (sv.isNotEmpty()) l1.getChildAt(2) else nm6)
    }

    private fun myNm(): String {
        var v = nm6.text.toString().trim().take(20)
        if (v.isEmpty()) v = savedName().ifEmpty { "بازیکن" }
        Prefs.name = v
        Prefs.gender = if (gen6.selectedItemPosition == 1) "m" else "f"
        return v
    }

    private fun uiNet() {
        netb.text = "روش اتصال: " + NETN[NET]
        nethint.text = NETH[NET]
    }

    private fun setNetUi(v: String) {
        NET = v; Prefs.net = v
        try { bridge.setNet(v) } catch (e: Exception) { }
        uiNet()
    }

    private fun netChoose() {
        dlg.list("روش اتصال", listOf(
            item("بلوتوث") { setNetUi("bt") },
            item("وای‌فای: همهٔ گوشی‌ها به یک مودم یا هات‌اسپات وصل باشند") { setNetUi("lan") },
            item("وای‌فای مستقیم: بدون مودم، گوشی‌ها مستقیم به میزبان وصل می‌شوند") { setNetUi("direct") }
        ))
    }

    private fun btReady(retry: ((Boolean) -> Unit)?): Boolean {
        btRetry = retry
        bridge.setNet(NET)
        val st = bridge.state()
        if (st == "nogms") { setLst("این گوشی خدمات گوگل پلی (Google Play Services) ندارد یا به‌روز نیست و اتصال نزدیک کار نمی‌کند."); return false }
        if (st == "noperm") {
            bridge.ensure()
            setLst(if (NET == "bt") "اجازه‌های درخواست‌شده (بلوتوث و دستگاه‌های نزدیک) را بدهید." else "اجازه‌های درخواست‌شده (دستگاه‌های نزدیک و موقعیت مکانی) را بدهید.")
            return false
        }
        if (st == "off") { bridge.enableBt(); setLst("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن بلوتوث را بدهید."); return false }
        if (st == "locoff") { bridge.enableLoc(); setLst("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن موقعیت مکانی را بدهید."); return false }
        if (st == "wifioff") {
            bridge.enableWifi()
            setLst(if (NET == "lan") "در پنجره‌ی باز‌شده وای‌فای را روشن کنید و به همان شبکه‌ای وصل شوید که بقیه‌ی بازیکن‌ها هستند (مودم یا هات‌اسپات). با بستن پنجره، برنامه خودش ادامه می‌دهد."
            else "در پنجره‌ی باز‌شده وای‌فای را روشن کنید (لازم نیست به شبکه‌ای وصل شوید). با بستن پنجره، برنامه خودش ادامه می‌دهد.")
            return false
        }
        if (st == "nobt") { setLst("این گوشی بلوتوث ندارد."); return false }
        btRetry = null; btN = 0
        return true
    }

    private fun btBack() { MP.reset(); Sched.newGen(); showBT() }

    // ---------------------------------------------------------------- host

    private fun lobbyHost(auto: Boolean) {
        if (!auto) { btN = 0; bridge.newAttempt() }
        if (!btReady { a -> lobbyHost(a) }) return
        hostOpen(if (MP.mode == 2) 2 else 4)
    }

    private fun hostOpen(n: Int) {
        MP.role = "host"; MP.mode = n; MP.cl.clear(); MP.started = false
        MP.hostName = myNm(); MP.room = java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        bridge.host(4, MP.room, MP.hostName)
        show6("l3"); modeUi()
        l3t.text = "نام شما در بازی: " + MP.hostName + ". منتظر ورود بازیکنان هستید. بازیکنان باید از بخش «به بازی دیگری می‌پیوندم» بازی «" + MP.hostName +
            "» را از فهرست بازی‌های نزدیک انتخاب کنند (گوشی‌ها باید نزدیک هم باشند). نوع بازی (دو نفره یا چهار نفره) را همین‌جا می‌توانید هر وقت خواستید عوض کنید و اتصال بازیکنان قطع نمی‌شود. هر وقت آماده بودید، دکمه‌ی پایین را بزنید (در بازی چهار نفره «مرحله بعد» که در آن چینش بازیکن‌ها را تعیین می‌کنید)؛ جاهای خالی را ربات پر می‌کند."
        setLst(""); lobbyRender()
        app.focusNode(mds)
    }

    private fun lobbyRender() {
        pl6.removeAllViews()
        var n = 0
        for ((_, c) in MP.cl) {
            if (!c.joined) continue
            n++
            val sx = c.seat
            pl6.addView(tv(if (sx != null) c.name + " — " + (if (MP.mode == 4) SEATL[sx].orEmpty() else "حریف شما") else c.name + " — در انتظار (در این نوع بازی جای خالی نیست)"))
        }
        setLst(if (n > 0) "$n بازیکن وارد شده است." else "هنوز کسی وارد نشده است.")
        if (shown("l5")) seatRender()
    }

    private fun modeUi() {
        uiBusy = true
        mds.setSelection(if (MP.mode == 2) 1 else 0)
        uiBusy = false
        go6.text = if (MP.mode == 4) "مرحله بعد" else "شروع بازی"
    }

    private fun reseat() {
        val ids = MP.cl.keys.sorted().filter { MP.cl[it]!!.joined }
        val order = if (MP.mode == 4) listOf(2, 1, 3) else listOf(1)
        val used = HashSet<Int>()
        if (MP.mode == 4) {
            for (k in ids) {
                val c = MP.cl[k]!!
                val s0 = c.seat
                if (s0 != null && order.contains(s0) && !used.contains(s0)) used.add(s0) else c.seat = null
            }
        } else for (k in ids) MP.cl[k]!!.seat = null
        for (k in ids) {
            val c = MP.cl[k]!!
            if (c.seat == null) {
                val s = order.firstOrNull { !used.contains(it) }
                if (s != null) { c.seat = s; used.add(s) }
            }
        }
    }

    private fun notifyLobby(back: Boolean = false) {
        for ((k, c) in MP.cl) {
            if (!c.joined) continue
            if (c.seat != null) {
                if (back) MP.send(k, JSONObject().put("t", "lobby").put("msg", ""))
                MP.send(k, JSONObject().put("t", "hi").put("seat", c.seat).put("host", MP.hostName).put("mode", MP.mode))
            } else MP.send(k, JSONObject().put("t", "lobby").put("msg",
                "در این نوع بازی (" + (if (MP.mode == 2) "دو نفره" else "چهار نفره") + ") جای خالی نیست. وصل می‌مانید و در انتظار هستید؛ اگر میزبان نوع بازی را عوض کند یا جایی خالی شود، وارد می‌شوید."))
        }
    }

    private fun setMode(n: Int) {
        if (MP.role != "host" || MP.started || MP.mode == n) { modeUi(); return }
        MP.mode = n; reseat(); modeUi(); notifyLobby(); lobbyRender()
    }

    private fun seatList() = if (MP.mode == 4) SEATS else listOf(1)
    private fun seatTt(s: Int) = if (MP.mode == 4) SEATT[s]!! else "حریف شما (روبه‌رو)"

    private fun hostNext() {
        if (MP.role != "host" || MP.started) return
        if (MP.mode != 4) { hostGo(); return }
        if (!MP.cl.values.any { it.joined }) { setLst("برای بازی چهار نفره باید دست‌کم یک بازیکن بپیوندد."); return }
        show6("l5"); seatRender()
        setLst("")
    }

    private fun hostSeatBack() { show6("l3"); lobbyRender() }

    private fun seatRender() {
        st6.removeAllViews()
        st6.addView(tv("پایین میز: " + MP.hostName + " (شما، میزبان)"))
        val ids = MP.cl.keys.filter { MP.cl[it]!!.joined }
        pdrow.visibility = if (MP.mode == 4) View.VISIBLE else View.GONE
        l5t.text = if (MP.mode == 4) "شما همیشه پایین میز هستید و یارتان روبه‌روی شماست. برای هر جایگاه بازیکن را انتخاب کنید. جای خالی را ربات پر می‌کند."
        else "شما همیشه پایین میز هستید و حریفتان روبه‌روی شماست. بازیکن حریف را انتخاب کنید."
        for (seat in seatList()) {
            st6.addView(tv(seatTt(seat) + ":"))
            val names = listOf("ربات") + ids.map { MP.cl[it]!!.name }
            val sp = spinner(names, seatTt(seat))
            val cur = MP.cidOf(seat)
            sp.setSelection(if (cur == null) 0 else ids.indexOf(cur) + 1)
            var first = true
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (first) { first = false; return }
                    assignSeat(seat, if (pos == 0) null else ids[pos - 1])
                }
                override fun onNothingSelected(p: AdapterView<*>?) { }
            }
            st6.addView(sp, spLp())
        }
    }

    private fun assignSeat(seat: Int, cid: Int?) {
        if (MP.role != "host" || MP.started) return
        val cur = MP.cidOf(seat)
        if (cid == null) { if (cur != null) MP.cl[cur]!!.seat = null }
        else {
            val c = MP.cl[cid] ?: return
            val old = c.seat
            if (cur != null && cur != cid) MP.cl[cur]!!.seat = old
            c.seat = seat
        }
        notifyLobby()
        for ((k, c) in MP.cl) if (c.joined && c.seat == null)
            MP.send(k, JSONObject().put("t", "lobby").put("msg", "میزبان در چینش فعلی برای شما جایی نگذاشته است. وصل می‌مانید و اگر میزبان چینش را عوض کند وارد بازی می‌شوید."))
        seatRender()
        setLst(if (cid == null) seatTt(seat) + ": ربات." else MP.cl[cid]!!.name + " در جایگاه «" + seatTt(seat) + "» قرار گرفت.")
    }

    private fun hostGo() {
        val ids = MP.cl.keys.filter { MP.cl[it]!!.seat != null }
        if (ids.isEmpty()) { setLst(if (MP.mode == 2) "برای بازی دو نفره باید یک بازیکن بپیوندد." else "برای بازی چهار نفره باید دست‌کم یک بازیکن بپیوندد."); return }
        MP.started = true
        MP.pdraw = pd6.selectedItemPosition == 0
        MP.rem.fill(false); MP.qrem = false
        if (MP.mode == 4) for (k in ids) MP.rem[MP.cl[k]!!.seat!!] = true else MP.qrem = true
        for (k in ids) MP.send(k, JSONObject().put("t", "go").put("mode", MP.mode))
        for ((k, c) in MP.cl) if (c.joined && c.seat == null)
            MP.send(k, JSONObject().put("t", "lobby").put("msg", "بازی شروع شد و در آن جایی برای شما نیست. وصل می‌مانید و بعد از پایان بازی می‌توانید وارد بازی بعدی شوید."))
        if (MP.mode == 4) app.start4() else app.start2()
    }

    /** the game is over: back to the waiting room with the same players (hostBackToLobby) */
    fun hostBackToLobby() {
        Sched.newGen(); MP.started = false; MP.pend.clear(); MP.rem.fill(false); MP.qrem = false
        reseat(); notifyLobby(true); modeUi()
        app.showScreen("g6"); show6("l3")
        l3t.text = "بازی قبلی تمام شد. بازیکنان همچنان وصل هستند. اگر خواستید نوع بازی (دو نفره یا چهار نفره) را همین‌جا عوض کنید. در بازی چهار نفره با دکمه‌ی «مرحله بعد» جای نشستن را تنظیم می‌کنید و بعد بازی را شروع می‌کنید."
        lobbyRender()
    }

    fun mpLeave() { MP.leaving = true; app.client.stopReconnect(); app.showMenu() }

    // ---------------------------------------------------------------- client

    private fun lobbyJoin(auto: Boolean) {
        if (!auto) { btN = 0; bridge.newAttempt() }
        if (!btReady { a -> lobbyJoin(a) }) return
        MP.role = "client"; MP.leaving = false; MP.myName = myNm(); MP.found.clear()
        show6("l4"); foundRender(); bridge.scan()
    }

    private fun foundRender() {
        val was = dev6.childCount
        dev6.removeAllViews()
        for ((ep, f) in MP.found) dev6.addView(btn(f.name.ifEmpty { "بازی بدون نام" }) { joinDev(ep, f.name, f.room) })
        val n = MP.found.size
        setLst(if (n > 0) "$n بازی نزدیک پیدا شد." else "در حال جست‌وجو. میزبان باید «میزبان بازی می‌شوم» را باز کرده باشد.")
        if (n > 0 && was == 0) app.focusNode(dev6.getChildAt(0))
    }

    private fun joinDev(ep: String, name: String, room: String) {
        MP.room = room
        MP.lastAddr = if (room.isNotEmpty()) "room:$room" else ep
        MP.rcN = 0
        setLst("در حال اتصال به " + name.ifEmpty { "بازی" } + " ...")
        bridge.connect(ep)
    }

    // ---------------------------------------------------------------- messages

    private fun uniqueName(base: String, c: Peer?): String {
        var nm = base; var i = 2
        fun taken(x: String) = x == MP.hostName || MP.cl.values.any { it !== c && it.name == x }
        while (taken(nm)) nm = base + " " + fa(i++)
        return nm
    }

    private fun hostMsg(cid: Int, m: JSONObject) {
        val c = MP.cl[cid] ?: return
        when (m.optString("t")) {
            "hello" -> {
                c.id = m.optString("id").take(40)
                val g = m.optString("g"); if (g == "f" || g == "m") c.g = g
                if (MP.started) { rejoin(cid, c, m); return }
                if (c.joined) return
                val nm0 = m.optString("name", c.name).trim().take(24).ifEmpty { "بازیکن" }
                c.name = uniqueName(nm0, c); c.joined = true
                val order = if (MP.mode == 4) listOf(2, 1, 3) else listOf(1)
                val seat = order.firstOrNull { MP.cidOf(it) == null }
                if (seat == null) {
                    c.seat = null
                    MP.send(cid, JSONObject().put("t", "lobby").put("msg",
                        "در این نوع بازی (" + (if (MP.mode == 2) "دو نفره" else "چهار نفره") + ") جای خالی نیست. وصل می‌مانید و در انتظار هستید؛ اگر میزبان نوع بازی را عوض کند یا جایی خالی شود، وارد می‌شوید."))
                    lobbyRender(); return
                }
                c.seat = seat
                MP.send(cid, JSONObject().put("t", "hi").put("seat", seat).put("host", MP.hostName).put("mode", MP.mode))
                lobbyRender()
            }
            "rn" -> {
                val nm0 = m.optString("name").trim().take(24)
                if (nm0.isEmpty()) return
                c.name = uniqueName(nm0, c)
                val g = m.optString("g"); if (g == "f" || g == "m") c.g = g
                if (c.seat == 1 && MP.mode == 2) app.flow2.botName = c.name
                lobbyRender()
            }
            "ans" -> {
                val pd = MP.pend[cid]
                if (pd != null && pd.id == m.optInt("id", -1)) { MP.pend.remove(cid); pd.cb(m.opt("v")) }
            }
            "free" -> c.freeAt = Sched.now() + Math.min(60000L, Math.max(0L, m.optLong("ms", 0)))
        }
    }

    private fun clMsg(m: JSONObject) {
        when (m.optString("t")) {
            "hi" -> {
                MP.hostName = m.optString("host", "میزبان").ifEmpty { "میزبان" }
                val md = m.optInt("mode", 0)
                if (md != 0) app.client.mode = md
                app.client.me = m.optInt("seat", -1)
                setLst("به بازی" + (if (md != 0) (if (md == 2) " دو نفره" else " چهار نفره") else "") + " پیوستید. منتظر شروع بازی توسط " + MP.hostName + " باشید...")
            }
            "lobby" -> {
                app.client.ask = null
                app.showScreen("g6"); show6("l4")
                setLst(m.optString("msg").ifEmpty { "بازی تمام شد یا میزبان بازی جدیدی آماده می‌کند. هنوز وصل هستید؛ منتظر شروع بازی توسط " + MP.hostName + " باشید..." })
            }
            "kick" -> {
                MP.rcN = 99; MP.leaving = true; app.client.ask = null; app.client.stopReconnect()
                val t = "میزبان شما را از بازی حذف کرد. اگر خواستید می‌توانید دوباره وارد شوید."
                setLst(t); app.client.said(t)
            }
            "full" -> {
                MP.rcN = 99; app.client.stopReconnect()
                val t = "جای شما در بازی خالی نیست و نمی‌شود دوباره وصل شد."
                setLst("این بازی پر است یا جای شما در آن دیگر خالی نیست."); app.client.said(t)
            }
            else -> app.client.onMsg(m)
        }
    }

    private fun mpDrop(cid: Int, kick: Boolean = false, quiet: Boolean = false) {
        val c = MP.cl[cid] ?: return
        val hadAsk = MP.pend.remove(cid) != null
        if (!MP.started) { MP.cl.remove(cid); reseat(); notifyLobby(); lobbyRender(); return }
        MP.cl.remove(cid)
        val s0 = c.seat ?: return
        MP.away[s0] = Away(c.name, c.id)
        mpRoster()
        if (MP.mode == 4) app.flow.remDrop(c, hadAsk, kick) else app.flow2.remDrop(c, hadAsk, kick)
        if (!kick && !quiet) Hold.start(c.name + " قطع شد و ربات جای او آمد.")
    }

    // ---------------------------------------------------------------- saving a multi-phone game and continuing it later

    /** the running game plus who sits where (buildSnap) */
    private fun buildSnap(): JSONObject? {
        val sn = (if (MP.mode == 4) app.flow.snap() else if (MP.mode == 2) app.flow2.snapshot() else null) ?: return null
        val hum = arrayOfNulls<String>(4); val hid = arrayOfNulls<String>(4)
        for ((sd, a) in MP.away) { hum[sd] = a.name; hid[sd] = a.id }
        for ((_, c) in MP.cl) { val sd = c.seat; if (sd != null) { hum[sd] = c.name; hid[sd] = c.id } }
        hum[0] = MP.hostName; hid[0] = Prefs.devId()
        fun arr(a: Array<String?>) = org.json.JSONArray().also { j -> a.forEach { j.put(it ?: JSONObject.NULL) } }
        return sn.put("hum", arr(hum)).put("hid", arr(hid))
    }

    private fun storeSave(): Boolean {
        if (MP.role != "host" || !MP.started) return false
        val sn = buildSnap() ?: return false
        val old = Prefs.loadSaves()
        val a = org.json.JSONArray()
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("m", MP.mode).put("room", MP.room).put("hn", MP.hostName).put("s", sn))
        for (i in 0 until old.length()) { val o = old.getJSONObject(i); if (o.optString("room") != MP.room) a.put(o) }
        if (sn.toString().length < 26000) MP.each { cid, c ->
            MP.send(cid, JSONObject().put("t", "sv").put("s", sn).put("room", MP.room).put("hn", MP.hostName).put("m", MP.mode).put("seat", c.seat))
        }
        return Prefs.putSaves(a)
    }

    fun saveGame() {
        if (MP.role != "host" || !MP.started) return
        dlg.list(if (storeSave()) "بازی ذخیره شد. هر وقت خواستید از «بازی‌های قبلی» در بخش «بازی با چند گوشی» ادامه‌اش دهید." else "ذخیرهٔ بازی ممکن نشد.", listOf(), "باشه")
    }

    /** "بازی‌های قبلی" of the lobby: games this phone saved as host or was told about as a guest */
    private fun prevAll() {
        class E(val src: String, val room: String, val hn: String, val m: Int, val t: Long, val o: JSONObject)
        val map = LinkedHashMap<String, E>()
        val saves = Prefs.loadSaves()
        for (i in 0 until saves.length()) { val o = saves.optJSONObject(i) ?: continue; map[o.optString("room")] = E("h", o.optString("room"), o.optString("hn"), o.optInt("m"), o.optLong("t"), o) }
        val prev = Prefs.loadPrev()
        for (i in 0 until prev.length()) {
            val o = prev.optJSONObject(i) ?: continue
            if (!o.has("s")) continue
            val e = map[o.optString("room")]
            if (e == null || o.optLong("t") > e.t) map[o.optString("room")] = E("g", o.optString("room"), o.optString("hn"), o.optInt("m"), o.optLong("t"), o)
        }
        val a = map.values.sortedByDescending { it.t }
        if (a.isEmpty()) {
            dlg.list("بازی ذخیره‌شده‌ای نیست. میزبان باید در بازی از «گزینه‌های بیشتر» دکمهٔ «ذخیره» را بزند.", listOf(), "باشه")
            return
        }
        dlg.list("بازی‌های قبلی", a.map { e ->
            item((if (e.m == 2) "دو نفره" else "چهار نفره") + " · " + e.hn + " · " + dateText(e.t)) {
                dlg.list("این بازی:", listOf(
                    item("میزبان این بازی می‌شوم") { if (e.src == "h") resumeSave(e.o) else prevHost(e.o) },
                    item("حذف") {
                        val s1 = Prefs.loadSaves(); val k1 = org.json.JSONArray()
                        for (i in 0 until s1.length()) { val o = s1.getJSONObject(i); if (o.optString("room") != e.room) k1.put(o) }
                        Prefs.putSaves(k1)
                        val p1 = Prefs.loadPrev(); val k2 = org.json.JSONArray()
                        for (i in 0 until p1.length()) { val o = p1.getJSONObject(i); if (o.optString("room") != e.room) k2.put(o) }
                        Prefs.putPrev(k2)
                    }
                ))
            }
        })
    }

    private fun dateText(t: Long): String = try {
        android.icu.text.DateFormat.getDateTimeInstance(android.icu.text.DateFormat.DEFAULT, android.icu.text.DateFormat.DEFAULT,
            android.icu.util.ULocale("fa_IR")).format(java.util.Date(t))
    } catch (e: Exception) { java.util.Date(t).toString() }

    private fun resumeSave(sv: JSONObject) {
        if (!btReady { resumeSave(sv) }) return
        MP.reset(); Sched.newGen()
        MP.myName = myNm(); MP.room = sv.optString("room")
        val s0 = sv.getJSONObject("s")
        adoptHost(if (s0.optInt("m") == 2) swap2(s0) else s0, 0, "بازی ذخیره‌شده ادامه پیدا کرد. بازیکنان می‌توانند دوباره وصل شوند و تا آن موقع ربات جایشان بازی می‌کند.")
    }

    /** a game saved by this phone as a guest: it becomes the host in the seat it had (prevHost) */
    private fun prevHost(r: JSONObject) {
        val s0 = r.optJSONObject("s")
        if (s0 == null) { dlg.list("برای این بازی ذخیره‌ای روی این گوشی نیست. اول باید میزبان یک دور را به پایان برساند یا «ذخیره» را بزند.", listOf(), "باشه"); return }
        if (!btReady { prevHost(r) }) return
        MP.reset(); Sched.newGen()
        MP.myName = myNm(); MP.room = r.optString("room")
        adoptHost(s0, if (r.isNull("seat")) 0 else r.optInt("seat"), "شما این بازی را به‌عنوان میزبان ادامه دادید. بازیکنان می‌توانند دوباره وصل شوند و تا آن موقع ربات جایشان بازی می‌کند.")
    }

    // ---- the saved game seen from the other player (two-player): swap2 / the flip done by adoptHost ----
    private fun swapArr(a: org.json.JSONArray) = org.json.JSONArray().put(a.get(1)).put(a.get(0))
    private fun flipTp(a: org.json.JSONArray?) = org.json.JSONArray().also { r ->
        if (a != null) for (i in 0 until a.length()) { val e = a.getJSONObject(i); r.put(JSONObject().put("p", 1 - e.getInt("p")).put("c", e.get("c"))) }
    }

    private fun flip2(x: JSONObject): JSONObject {
        val q = x.getJSONObject("Q")
        val nq = JSONObject()
        nq.put("sc", swapArr(q.getJSONArray("sc"))); nq.put("hk", 1 - q.getInt("hk"))
        nq.put("hands", swapArr(q.getJSONArray("hands"))); nq.put("tk", swapArr(q.getJSONArray("tk")))
        nq.put("trick", flipTp(q.optJSONArray("trick"))); nq.put("shown", flipTp(q.optJSONArray("shown"))); nq.put("last", flipTp(q.optJSONArray("last")))
        nq.put("played", q.get("played")); nq.put("gone", q.get("gone")); nq.put("vo", swapArr(q.getJSONArray("vo")))
        nq.put("phase", q.getString("phase")); nq.put("trump", if (q.isNull("trump")) JSONObject.NULL else q.get("trump"))
        nq.put("turn", if (q.isNull("turn")) JSONObject.NULL else 1 - q.getInt("turn"))
        nq.put("kt", if (q.isNull("kt")) JSONObject.NULL else 1 - q.getInt("kt"))
        return JSONObject(x.toString()).put("Q", nq)
    }

    private fun swap2(x: JSONObject): JSONObject {
        val r = flip2(x)
        val hum = x.optJSONArray("hum"); val hid = x.optJSONArray("hid")
        if (hum != null && hum.length() >= 2) r.put("hum", org.json.JSONArray().put(hum.get(1)).put(hum.get(0)))
        if (hid != null && hid.length() >= 2) r.put("hid", org.json.JSONArray().put(hid.get(1)).put(hid.get(0)))
        return r
    }

    /** four-player game as seen from seat [seat] (the new host moves to the bottom of the table) */
    private fun rotate4(x: JSONObject, seat: Int): JSONObject {
        val sw = seat % 2 == 1
        fun nS(o: Int) = (o - seat + 4) % 4
        fun at(a: org.json.JSONArray, n: Int) = a.get((n + seat) % 4)
        fun tcs(a: org.json.JSONArray?) = org.json.JSONArray().also { r ->
            if (a != null) for (i in 0 until a.length()) { val e = a.getJSONObject(i); r.put(JSONObject().put("seat", nS(e.getInt("seat"))).put("c", e.get("c"))) }
        }
        val r = JSONObject()
        r.put("m", 4)
        val H = x.getJSONArray("H"); val vo = x.getJSONArray("voids"); val nm = x.optJSONArray("NM")
        r.put("H", org.json.JSONArray().also { a -> for (n in 0 until 4) a.put(at(H, n)) })
        r.put("voids", org.json.JSONArray().also { a -> for (n in 0 until 4) a.put(at(vo, n)) })
        if (nm != null) r.put("NM", org.json.JSONArray().also { a -> for (n in 0 until 4) a.put(at(nm, n)) })
        r.put("trump", if (x.isNull("trump")) JSONObject.NULL else x.get("trump"))
        r.put("hakem", nS(x.getInt("hakem"))); r.put("turn", nS(x.getInt("turn")))
        r.put("trick", tcs(x.optJSONArray("trick"))); r.put("lastTrick", tcs(x.optJSONArray("lastTrick"))); r.put("shown", tcs(x.optJSONArray("shown")))
        val pa = x.optJSONArray("plays")
        r.put("plays", org.json.JSONArray().also { a ->
            if (pa != null) for (i in 0 until pa.length()) {
                val e = JSONObject(pa.getJSONObject(i).toString())
                e.put("seat", nS(e.getInt("seat"))); e.put("bs", if (e.getInt("bs") >= 0) nS(e.getInt("bs")) else -1)
                a.put(e)
            }
        })
        r.put("winSeat", if (x.optInt("winSeat", -1) >= 0) nS(x.getInt("winSeat")) else -1)
        val tk = x.getJSONArray("tk"); val sc = x.getJSONArray("sc")
        r.put("tk", if (sw) swapArr(tk) else tk); r.put("sc", if (sw) swapArr(sc) else sc)
        r.put("kt", if (x.isNull("kt")) JSONObject.NULL else (if (sw) 1 - x.getInt("kt") else x.getInt("kt")))
        r.put("seen", x.get("seen")); r.put("phase", x.getString("phase"))
        return r
    }

    /** this phone becomes the host of a game snapshot, sitting in seat [seat] of the old table (adoptHost) */
    fun adoptHost(x: JSONObject, seat: Int, msg: String?) {
        val nm = MP.myName.ifEmpty { "بازیکن" }
        val auto = !MP.leaving && !MP.conn && MP.rcOn
        Sched.newGen(); app.client.stopReconnect(); MP.conn = false; MP.fo = false
        try { bridge.drop(0) } catch (e: Exception) { }
        MP.role = "host"; MP.mode = x.getInt("m"); MP.cl.clear(); MP.pend.clear(); MP.started = true; MP.leaving = false
        MP.away.clear(); MP.hostName = nm; MP.lsy = ""; MP.over = false
        if (MP.room.isEmpty()) MP.room = MP.lastAddr.removePrefix("room:").ifEmpty { java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6) }
        MP.rem.fill(false); MP.qrem = false; app.client.ask = null; app.client.holdTxt = ""
        bridge.host(4, MP.room, nm)
        Hold.clear(); Hold.start("میزبانی به شما رسید.")
        val t = msg ?: ((if (auto) "میزبان قبلی قطع شد و میزبانی به شما رسید. " else "میزبانی به شما منتقل شد. ") + "بازیکنان به‌زودی دوباره وصل می‌شوند و تا آن موقع ربات جایشان بازی می‌کند.")
        val humA = x.optJSONArray("hum"); val hidA = x.optJSONArray("hid")
        fun hum(o: Int): String? = if (humA == null || o >= humA.length() || humA.isNull(o)) null else humA.optString(o).ifEmpty { null }
        fun hid(o: Int): String = if (hidA == null || o >= hidA.length() || hidA.isNull(o)) "" else hidA.optString(o)
        if (x.getInt("m") == 4) {
            for (o in 0 until 4) if (o != seat) hum(o)?.let { MP.away[(o - seat + 4) % 4] = Away(it, hid(o)) }
            app.resumeHost4(rotate4(x, seat), t, (0 until 4).map { hum((it + seat) % 4) })
        } else {
            val on = hum(0) ?: x.optString("BOTN").ifEmpty { "بازیکن" }
            MP.away[1] = Away(on, hid(0))
            app.resumeHost2(flip2(x), t, on)
        }
        mpRoster()
    }

    // ---------------------------------------------------------------- handing the host role to a guest

    private fun succOrder(): List<Int> = MP.cl.keys.filter { MP.cl[it]!!.seat != null }.sorted()
    fun xferTarget(): Int? = succOrder().firstOrNull()

    /** tells every seated guest his place in the line of successors (mpRoster) */
    fun mpRoster() {
        if (MP.role != "host" || !MP.started) return
        val ord = succOrder()
        for ((k, c) in MP.cl) if (c.seat != null) {
            val r = ord.indexOf(k)
            MP.send(k, JSONObject().put("t", "roster").put("succ", if (ord.isNotEmpty()) "room:" + MP.room else "").put("me", r == 0).put("rank", r).put("nm", c.name))
        }
        MP.lsy = ""; mpSync()
    }

    /** sends the current game to the successors whenever it changed (mpSync) */
    fun mpSync() {
        if (MP.role != "host" || !MP.started) return
        val ord = succOrder(); if (ord.isEmpty()) return
        val o = buildSnap() ?: return
        val str = o.toString()
        if (str == MP.lsy) return
        MP.lsy = str
        for (cid in ord) MP.send(cid, JSONObject().put("t", "sync").put("s", str))
    }

    fun xferAsk() {
        if (MP.role != "host" || !MP.started) return
        val ids = succOrder(); if (ids.isEmpty()) return
        val q = { cid: Int -> dlg.confirm("میزبانی همین الان به «" + MP.cl[cid]!!.name + "» منتقل شود؟ بعد از آن شما بازیکن عادی هستید و تا وصل شدن دوباره‌ی بازیکن‌ها، ربات جایشان بازی می‌کند.", { startTransfer(cid) }) }
        if (ids.size == 1) { q(ids[0]); return }
        dlg.list("میزبانی به کدام بازیکن منتقل شود؟", ids.map { cid -> item(MP.cl[cid]!!.name) { q(cid) } })
    }

    private fun xferMsg(t: String) {
        if (MP.mode == 4) { app.say(t); app.flow.log(t) } else { app.say(t); app.flow2.log2(t) }
    }

    fun startTransfer(pre: Int?, man: Boolean = false) {
        if (MP.role != "host" || !MP.started) return
        val tid = if (pre != null && MP.cl[pre]?.seat != null) pre else xferTarget()
        val sn = buildSnap()
        if (tid == null || sn == null || MP.cl[tid]?.addr.isNullOrEmpty()) { xferMsg("انتقال میزبانی ممکن نشد."); return }
        val tc = MP.cl[tid]!!; val addr = "room:" + MP.room; val oldName = MP.hostName
        MP.pend.clear()
        MP.send(tid, JSONObject().put("t", "xfer").put("s", sn.toString()).put("seat", tc.seat))
        for ((k, c) in MP.cl) if (k != tid && c.seat != null) MP.send(k, JSONObject().put("t", "migrate").put("addr", addr).put("nm", c.name))
        Sched.newGen()
        xferMsg("میزبانی در حال انتقال به " + tc.name + " است...")
        Sched.laterRaw(2200) { if (man) act.bridge.exitApp() else toClient(oldName, addr) }
    }

    /** this phone stops being the host and connects to the new one as a normal player (toClient) */
    private fun toClient(nm: String, addr: String) {
        MP.reset(); Sched.newGen()
        MP.role = "client"; app.client.holdTxt = ""; MP.leaving = false; MP.myName = nm
        MP.lastAddr = addr; MP.room = addr.removePrefix("room:"); MP.conn = false; MP.fo = true
        app.showClientScreen(); app.client.resetForTransfer()
        app.client.startReconnect()
        val t = "میزبانی منتقل شد و شما بازیکن عادی هستید. در حال اتصال به میزبان جدید..."
        app.say(t); app.client.c5log(t); app.renderClient()
    }

    // ---------------------------------------------------------------- host menu: add / remove a player

    private fun item(t: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(t, f)

    /** empty seats of the running game (freeSeats) */
    fun freeSeats(): List<Int> {
        if (MP.role != "host" || !MP.started) return emptyList()
        return (if (MP.mode == 4) listOf(1, 2, 3) else listOf(1)).filter { MP.cidOf(it) == null }
    }

    fun addAsk() {
        if (MP.role != "host" || !MP.started) return
        val seats = freeSeats()
        if (seats.isEmpty()) return
        val w = MP.cl.keys.filter { MP.cl[it]!!.joined && MP.cl[it]!!.seat == null }
        if (w.isEmpty()) {
            dlg.list("بازیکن جدیدی وصل نیست. از او بخواهید «به بازی دیگری می‌پیوندم» را بزند و گوشی میزبان را انتخاب کند؛ بعد «بررسی دوباره» را بزنید.",
                listOf(item("بررسی دوباره") { addAsk() }))
            return
        }
        val pick = { cid: Int ->
            if (seats.size == 1) addPlayer(cid, seats[0])
            else dlg.list("«" + MP.cl[cid]!!.name + "» جای کدام ربات بنشیند؟", seats.map { x ->
                item((if (MP.mode == 4) SEATT[x] else "حریف شما") + (MP.away[x]?.let { " (جای " + it.name + ")" } ?: "")) { addPlayer(cid, x) }
            })
        }
        if (w.size == 1) { pick(w[0]); return }
        dlg.list("کدام بازیکن به بازی اضافه شود؟", w.map { cid -> item(MP.cl[cid]!!.name) { pick(cid) } })
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val c = MP.cl[cid] ?: return
        if (MP.role != "host" || !MP.started || c.seat != null || MP.cidOf(seat) != null) return
        seatIn(cid, c, seat, c.name, true)
    }

    fun kickAsk() {
        if (MP.role != "host" || !MP.started) return
        val ids = MP.cl.keys.filter { MP.cl[it]!!.seat != null }
        if (ids.isEmpty()) return
        val q = { cid: Int ->
            dlg.confirm("«" + MP.cl[cid]!!.name + "» از بازی حذف شود؟ ربات جای او بازی می‌کند. او می‌تواند دوباره وارد بازی شود.", { kickPlayer(cid) })
        }
        if (ids.size == 1) { q(ids[0]); return }
        dlg.list("کدام بازیکن از بازی حذف شود؟", ids.map { cid -> item(MP.cl[cid]!!.name) { q(cid) } })
    }

    private fun kickPlayer(cid: Int) {
        val c = MP.cl[cid]
        if (MP.role != "host" || !MP.started || c == null || c.seat == null) return
        MP.send(cid, JSONObject().put("t", "kick")); bridge.drop(cid)
        mpDrop(cid, true)
    }

    /** a phone connects again while the game is running: give it back its seat (rejoin) */
    private fun rejoin(cid: Int, c: Peer, m: JSONObject) {
        if (c.seat != null) return
        val nm = m.optString("name", c.name).trim().take(24).ifEmpty { "بازیکن" }
        val id = m.optString("id").take(40)
        val same = { oid: String, oname: String -> if (id.isNotEmpty() && oid.isNotEmpty()) oid == id else oname == nm }
        for ((k, o) in LinkedHashMap(MP.cl)) {
            if (k != cid && o.seat != null && same(o.id, o.name)) { bridge.drop(k); mpDrop(k, false, true); break }
        }
        val ks = MP.away.keys.toList()
        val bn = ks.firstOrNull { same(MP.away[it]!!.id, MP.away[it]!!.name) }
        val seat = bn ?: (if (ks.size == 1) ks[0] else null)
        if (seat == null) {
            c.name = nm; c.joined = true
            MP.send(cid, JSONObject().put("t", "lobby").put("msg", "بازی در جریان است. وصل می‌مانید تا میزبان شما را به بازی اضافه کند."))
            return
        }
        seatIn(cid, c, seat, nm, false)
    }

    /** the phone takes its seat in the running game (seatIn) */
    fun seatIn(cid: Int, c: Peer, seat: Int, nm: String, add: Boolean) {
        MP.away.remove(seat)
        c.name = nm; c.seat = seat; c.joined = true
        MP.send(cid, JSONObject().put("t", "hi").put("seat", seat).put("host", MP.hostName))
        MP.send(cid, JSONObject().put("t", "go").put("mode", MP.mode).put("back", !add).put("add", add))
        mpRoster()
        if (Hold.on) MP.send(cid, JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + MP.hostName + "») ادامه را تأیید کند."))
        val t = if (add) "$nm به بازی اضافه شد و بازی را ادامه می‌دهد." else "$nm دوباره وصل شد و بازی را ادامه می‌دهد."
        if (MP.mode == 4) app.flow.seatIn4(cid, seat, nm, t) else app.flow2.seatIn2(cid, nm, t)
    }

    /** the name was changed in the rename box */
    fun applyRename(v: String) {
        try {
            if (MP.role == "client" && MP.conn) {
                MP.myName = v
                bridge.send(0, JSONObject().put("t", "rn").put("name", v).put("id", Prefs.devId()).put("g", savedGender()).toString())
            } else if (MP.role == "host") {
                val nm = uniqueName(v, null)
                MP.hostName = nm
                for ((k, c) in MP.cl) if (c.joined || c.seat != null) MP.send(k, JSONObject().put("t", "hn").put("name", nm))
                lobbyRender()
                if (MP.started) mpSync()
            }
        } catch (e: Exception) { }
    }

    /** transport events from the native layer (window.btEvt of the page) */
    fun onEvt(type: String, cid: Int, data: String) {
        when (type) {
            "conn" -> if (MP.role == "host") {
                val pr = data.split("\u0001")
                MP.cl[cid] = Peer(null, pr.getOrNull(0).orEmpty().ifEmpty { "بازیکن" }, pr.getOrNull(1).orEmpty())
            }
            "found" -> if (MP.role == "client" && !MP.conn) {
                val pr = data.split("\u0001")
                MP.found[pr[0]] = Found(pr.getOrNull(1).orEmpty(), pr.getOrNull(2).orEmpty())
                if (shown("l4")) foundRender()
            }
            "lost" -> if (MP.found.containsKey(data)) {
                MP.found.remove(data)
                if (MP.role == "client" && shown("l4")) foundRender()
            }
            "open" -> if (MP.role == "client") {
                bridge.stopScan(); MP.conn = true; app.client.stopReconnect()
                bridge.send(0, JSONObject().put("t", "hello").put("name", MP.myName.ifEmpty { "بازیکن" }).put("id", Prefs.devId()).put("g", savedGender()).toString())
            }
            "msg" -> {
                val m = try { JSONObject(data) } catch (e: Exception) { return }
                if (MP.role == "host") hostMsg(cid, m) else if (MP.role == "client") clMsg(m)
            }
            "drop" -> {
                if (MP.role == "host") mpDrop(cid)
                else if (MP.role == "client" && !MP.leaving) {
                    MP.conn = false
                    if (app.currentScreen() == "g5") app.client.onDrop()
                    else setLst("اتصال برقرار نشد یا قطع شد. دوباره امتحان کنید.")
                }
            }
            "err" -> setLst("خطا: $data")
            "perm" -> {
                val r = btRetry
                if (data == "1" && r != null && btN < 5) { btRetry = null; btN++; Sched.later(700) { r(true) } }
                else if (data == "s0") setLst("برای ادامه باید مجوزها را در تنظیمات برنامه روشن کنید. صفحهٔ تنظیمات باز شد؛ مجوزها را بدهید و برگردید تا برنامه خودش ادامه دهد.")
                else {
                    btRetry = null
                    setLst(if (data == "1") "اجازه داده شد. دوباره دکمه را بزنید."
                    else if (data == "w0") "وای‌فای هنوز خاموش است. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید و آن را روشن کنید."
                    else if (data == "l0") "موقعیت مکانی روشن نشد. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید."
                    else "اجازه‌ها داده نشد. بدون آن‌ها اتصال نزدیک کار نمی‌کند.")
                }
            }
        }
    }

    @Suppress("unused")
    private fun unusedColor() = Color.WHITE
}
