package com.example.hokm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

/** Animation speed (the page's ANI.f / ANI.m and ad()). */
object Anim {
    /** speed factor: 1 normal, 1.6 slow, 0.6 fast */
    @JvmField var f = 1.0
    var m = "norm"

    fun load() {
        when (Prefs.anim) {
            "slow" -> { f = 1.6; m = "slow" }
            "fast" -> { f = 0.6; m = "fast" }
            else -> { f = 1.0; m = "norm" }
        }
    }

    fun set(mode: String) {
        m = mode
        f = if (mode == "slow") 1.6 else if (mode == "fast") 0.6 else 1.0
        Prefs.anim = mode
    }

    /** a duration in ms scaled by the chosen speed */
    fun ad(ms: Int): Int = Math.round(ms * f).toInt()
    fun ad(ms: Long): Long = Math.round(ms * f)
    fun ad(ms: Double): Long = Math.round(ms * f)
}

/**
 * Sound effects, their timing queue and the background-music switch.
 * Ported from the page (sfx / qd / psnd / endSnd / afterSnd / music functions, same numbers).
 * The music itself is played by MusicService (foreground service).
 */
object Sound {
    private lateinit var ctx: Context

    // ---- state (MUS of the original) ----
    @JvmField var on = true
    @JvmField var vm = 0.5   // music volume 0..1
    @JvmField var ve = 1.0   // effects volume 0..1

    /** called when volume / on-off changed so the settings screen can refresh (uiVol) */
    var onChange: (() -> Unit)? = null

    fun init(c: Context) {
        ctx = c.applicationContext
        on = Prefs.music
        vm = Prefs.volM
        ve = Prefs.volE
        Anim.load()
        try {
            pool = SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs()).build()
            val afd = ctx.assets.openFd("sounds/card.mp3")
            try { cardId = pool!!.load(afd, 1) } finally { afd.close() }
        } catch (e: Exception) { pool = null }
        musicSync()
    }

    private fun attrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

    // ---- playback ----
    private var pool: SoundPool? = null
    private var cardId = 0
    private val active = HashMap<String, MediaPlayer>()

    private fun EF(): Double = ve

    /**
     * Effects are silent while the screen cannot show their animation (app in the background,
     * main menu open over a running game): animators freeze there but the game timers keep running,
     * so the sounds would come out of step. [App.resync] redraws the table when we come back.
     */
    @JvmField var hushApp = false
    @JvmField var hushMenu = false
    private fun hushed() = hushApp || hushMenu

    /** the app left the screen (home button, other app, screen lock): the music waits too. The main menu over a game does not stop it. */
    @JvmField var musicHeldApp = false

    fun syncHold() { try { MusicService.hold(musicHeldApp) } catch (e: Exception) { } }

    // ---- the background music steps down while a long effect (deal, trick, win / lose) plays ----
    private const val DUCK = 0.35f
    private var duckUntil = 0L

    /** lower the music for ms milliseconds (extends an earlier duck; the music comes back by itself) */
    private fun duckFor(ms: Long) {
        if (!on || ms < 1000L) return
        val end = Sched.now() + ms + 150L
        if (end > duckUntil) duckUntil = end
        try { MusicService.setDuck(DUCK) } catch (e: Exception) { }
        Sched.laterRaw(ms + 200L) {
            if (Sched.now() >= duckUntil) { duckUntil = 0L; try { MusicService.setDuck(1f) } catch (e: Exception) { } }
        }
    }

    private fun unduck() {
        duckUntil = 0L
        try { MusicService.setDuck(1f) } catch (e: Exception) { }
    }

    private fun playCard(vol: Float) {
        if (hushed()) return
        val p = pool ?: return
        p.play(cardId, vol, vol, 1, 0, 1f)
    }

    private fun playFile(n: String) {
        if (hushed()) return
        val old = active.remove(n)
        if (old != null) { try { old.stop() } catch (e: Exception) { }; try { old.release() } catch (e: Exception) { } }
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(attrs())
            val afd = ctx.assets.openFd("sounds/$n.mp3")
            try { mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
            val v = EF().toFloat()
            mp.setVolume(v, v)
            mp.setOnCompletionListener { m ->
                if (active[n] === m) active.remove(n)
                try { m.release() } catch (e: Exception) { }
            }
            mp.setOnErrorListener { m, _, _ ->
                if (active[n] === m) active.remove(n)
                try { m.release() } catch (e: Exception) { }
                true
            }
            mp.prepare()
            active[n] = mp
            mp.start()
            try { duckFor(mp.duration.toLong()) } catch (e: Exception) { }
        } catch (e: Exception) {
            try { mp.release() } catch (x: Exception) { }
        }
    }

    private var dealPl: MediaPlayer? = null

    /** the long recorded deal sound, slowed or sped like the animation speed; stops when the screen/game changes (generation g) */
    fun playDeal(file: String, g: Int) {
        if (hushed()) return
        try {
            try { dealPl?.stop() } catch (e: Exception) { }
            try { dealPl?.release() } catch (e: Exception) { }
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs())
            val afd = ctx.assets.openFd("sounds/$file.mp3")
            try { mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
            val v = EF().toFloat(); mp.setVolume(v, v)
            mp.prepare()
            try { mp.playbackParams = mp.playbackParams.setSpeed((1.0 / Anim.f).toFloat()) } catch (e: Exception) { }
            mp.setOnCompletionListener { m -> try { m.release() } catch (e: Exception) { }; if (dealPl === m) dealPl = null }
            dealPl = mp
            mp.start()
            try { duckFor((mp.duration * Anim.f).toLong()) } catch (e: Exception) { }
            Sched.laterRaw(250) { watchDeal(mp, g) }
        } catch (e: Exception) { }
    }

    private fun watchDeal(mp: MediaPlayer, g: Int) {
        if (dealPl !== mp) return
        if (g != Sched.GEN) { try { mp.stop() } catch (e: Exception) { }; try { mp.release() } catch (e: Exception) { }; dealPl = null; unduck(); return }
        Sched.laterRaw(250) { watchDeal(mp, g) }
    }

    private fun stopAll() {
        unduck()
        try { dealPl?.stop() } catch (e: Exception) { }
        for (m in active.values) { try { m.stop() } catch (e: Exception) { }; try { m.release() } catch (e: Exception) { } }
        active.clear()
    }

    // ---- the "draw" sound is a few quick card sounds ----
    // P = [minCount, extraCount, minVol, extraVol, gap, extraGap]
    private val SPP_DRAW = doubleArrayOf(2.0, 1.0, 0.5, 0.3, 230.0, 70.0)
    private class SPlan(val g: List<Double>, val d: Double)
    private var drawPlan: SPlan? = null

    private fun mkSPlan(): SPlan {
        val P = SPP_DRAW
        val N = (P[0] + Math.floor(Math.random() * P[1])).toInt()
        val g = ArrayList<Double>()
        var t = 0.0
        for (i in 0 until N) { g.add(t); t += P[4] + Math.random() * P[5] }
        return SPlan(g, g[N - 1] + 370)
    }

    /** one card landing on the table (random volume like the page's cardSnd) */
    fun cardSnd() {
        try {
            if (!on) return
            playCard(Math.min(1.0, (0.5 + Math.random() * 0.45) * EF()).toFloat())
        } catch (e: Exception) { }
    }

    /** play the effect called n (does nothing when sound is off) */
    fun sfx(n: String?) {
        if (n.isNullOrEmpty()) return
        try { if (n == "shuffle") Fx.shuffle(450) else { if (BNT.contains(n)) Fx.banner(n); Av.outcome(n) } } catch (e: Exception) { }
        if (!on) return
        try {
            if (n == "draw") {
                val pl = drawPlan ?: mkSPlan()
                drawPlan = null
                for (t in pl.g) {
                    Sched.later(t.toLong()) {
                        try {
                            if (!on) return@later
                            val vol = Math.min(1.0, (SPP_DRAW[2] + Math.random() * SPP_DRAW[3]) * EF())
                            playCard(vol.toFloat())
                        } catch (e: Exception) { }
                    }
                }
                return
            }
            if (n == "card") { playCard(EF().toFloat()); return }
            playFile(n)
        } catch (e: Exception) { }
    }

    // ---- sound queue: when each sound may start so they do not overlap ----
    /** estimated length (ms) of each effect */
    val EST = mapOf(
        "deal" to 1100, "shuffle" to 890, "draw" to 650, "card" to 600, "trick" to 1245,
        "kwin" to 3530, "klose" to 3530, "fwin" to 5045, "flose" to 3400, "tlose" to 1650,
        "win" to 2950, "lose" to 3350
    )

    /** CSO: ms after the start of card.mp3 where its peak lies (played this much early so the peak matches the card landing) */
    const val CSO = 250

    /** banners shown for the end-of-hand sounds (BNT keys) */
    private val BNT = setOf("win", "lose", "kwin", "klose", "fwin", "flose")

    private var SQ = 0L

    /** the sound queue is busy until [end] (the long deal sound) */
    fun reserve(end: Long) { SQ = Math.max(SQ, end) }
    private var SQK = ""

    /** TBU: the player's next turn waits until this time (set by the game flow) */
    @JvmField var TBU = 0L

    /** forget every pending reservation and stop the long sounds (a saved game is being resumed) */
    fun resetQueue() {
        SQ = 0L; TBU = 0L; cgT = 0L; drawPlan = null
        unduck()
        try { dealPl?.stop() } catch (e: Exception) { }
        try { dealPl?.release() } catch (e: Exception) { }
        dealPl = null
        for (m in active.values) { try { m.stop() } catch (e: Exception) { }; try { m.release() } catch (e: Exception) { } }
        active.clear()
    }

    /** SQ: end of the sound queue (used by afterSnd) */
    fun sq(): Long = SQ

    /** delay (ms) before sound n may start; also reserves its slot */
    fun qd(n: String): Long {
        if (!on) {
            val bd: Long = if (BNT.contains(n)) Anim.ad((if (n == "fwin" || n == "flose") 3300L else 2300L) + 150L) else 0L
            if (bd == 0L) return 0
            val nw = Sched.now(); val st = Math.max(nw, SQ)
            SQ = st + bd
            return st - nw
        }
        val now = Sched.now()
        val g = if (n == "shuffle") 0L else if (n == "deal") 100L else 200L
        var d = (EST[n] ?: 500).toDouble()
        if (n == "draw") { drawPlan = mkSPlan(); d = drawPlan!!.d }
        val st = Math.max(now, SQ + (if (n == "draw") Math.max(120L, (800 - d).toLong()) else g))
        SQ = st + d.toLong()
        SQK = n
        return st - now
    }

    /** psnd / psnd2: play n (queued when q), calling [onStart] right when it starts */
    fun psnd(n: String, q: Boolean, onStart: (() -> Unit)? = null) {
        val go = { if (onStart != null) try { onStart() } catch (e: Exception) { }; sfx(n) }
        if (q) {
            val d = qd(n)
            if (d > 0) Sched.later(d) { go() } else go()
        } else go()
    }

    /** play the same sound twice, queued (psnd2x) */
    fun psnd2x(n: String) { psnd(n, true); psnd(n, true) }

    // ---- card gate (spacing of rapid card sounds) ----
    private var cgT = 0L
    private const val CG_GAP = 800L
    fun cardGate(fn: () -> Unit) {
        val now = Sched.now(); val t = Math.max(now, cgT)
        if (t - now > 1100) return
        cgT = t + CG_GAP
        if (t > now) Sched.later(t - now) { fn() } else fn()
    }

    /** endSnd4 / endSnd2: the sound at the end of a hand or game (t = winning team/player, 0 = you). */
    fun endSnd(t: Int, kot: Boolean, gm: Boolean, onStart: (() -> Unit)?) {
        var dn = false
        val o2 = { if (!dn) { dn = true; onStart?.invoke() } }
        Sched.later(700) {
            if (kot) psnd(if (t == 0) "kwin" else "klose", true, o2)
            if (gm) psnd(if (t == 0) "fwin" else "flose", true, o2)
            if (!kot && !gm) psnd(if (t == 0) "win" else "lose", true, o2)
        }
    }

    /** afterSnd: run fn when the sound queue is done (immediately when announcements are off) */
    fun afterSnd(fn: () -> Unit) {
        if (!Prefs.a11y) { fn(); return }
        Sched.later(760) {
            val w = Math.max(0L, SQ - Sched.now())
            Sched.later(w) { fn() }
        }
    }

    // ---- music (played by MusicService) ----
    private const val MB = 1.8
    private val MG0 = 0.25 / MB

    /** perceptual volume curve of the music slider */
    fun MV(): Double {
        val v = vm
        if (v <= 0) return 0.0
        if (v <= 0.5) return v * v / MB
        return MG0 * Math.pow(1 / MG0, (v - 0.5) / 0.5)
    }

    fun musicSync() {
        try { MusicService.apply(ctx, on, MV().toFloat()) } catch (e: Exception) { }
        onChange?.invoke()
    }

    fun musicVolApply() { musicSync() }

    fun toggleMusic() {
        on = !on
        if (!on) stopAll()
        Prefs.music = on
        musicSync()
    }

    /** music slider, v = 0..100 */
    fun setVolM(v: Double) {
        vm = Math.max(0.0, Math.min(1.0, v / 100))
        Prefs.volM = vm
        musicVolApply()
        onChange?.invoke()
    }

    /** effects slider, v = 0..100 */
    fun setVolE(v: Double) {
        ve = Math.max(0.0, Math.min(1.0, v / 100))
        Prefs.volE = ve
        onChange?.invoke()
    }

    fun release() {
        stopAll()
        try { pool?.release() } catch (e: Exception) { }
        pool = null
    }
}
