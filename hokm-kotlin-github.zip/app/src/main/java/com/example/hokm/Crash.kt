package com.example.hokm

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Saves the reason of a crash into a file and shows it at the next start (with a copy button),
 * so the exact cause of "the app closes by itself" can be read and sent to the developer.
 */
object Crash {
    private const val FILE = "last_crash.txt"

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            record(app, t, e)
            if (old != null) old.uncaughtException(t, e)
            else {
                android.os.Process.killProcess(android.os.Process.myPid())
                System.exit(10)
            }
        }
    }

    fun record(ctx: Context, t: Thread?, e: Throwable) {
        try {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            val txt = "thread: " + (t?.name ?: "-") +
                "\nandroid: " + android.os.Build.VERSION.SDK_INT + "  " + android.os.Build.MODEL +
                "\n\n" + sw.toString()
            File(ctx.applicationContext.filesDir, FILE).writeText(txt)
        } catch (x: Throwable) { }
    }

    /** shows the saved crash report once (if there is one) */
    fun showIfAny(act: Activity) {
        try {
            val f = File(act.applicationContext.filesDir, FILE)
            if (!f.exists()) return
            val txt = f.readText()
            f.delete()
            if (txt.isEmpty() || act.isFinishing) return
            val tv = TextView(act)
            tv.text = txt
            tv.textSize = 12f
            tv.setTextIsSelectable(true)
            tv.setPadding(32, 24, 32, 24)
            val sv = ScrollView(act)
            sv.addView(tv)
            AlertDialog.Builder(act)
                .setTitle("دفعه‌ی قبل برنامه بسته شد؛ علت:")
                .setView(sv)
                .setPositiveButton("کپی") { _, _ ->
                    try {
                        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("crash", txt))
                    } catch (x: Throwable) { }
                }
                .setNegativeButton("بستن", null)
                .show()
        } catch (x: Throwable) { }
    }
}
