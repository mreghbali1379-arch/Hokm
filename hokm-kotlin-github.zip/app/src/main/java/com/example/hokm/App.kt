package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.accessibility.AccessibilityEvent
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.example.hokm.Cards.SN
import com.example.hokm.Cards.SU
import com.example.hokm.Cards.cname
import com.example.hokm.Cards.fa
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/**
 * The screens: main menu and the four-player table (the page's #menu and #g4), plus the menu logic.
 * Implements [Ui4] so the game flow can draw on it.
 */
class App(private val act: MainActivity) : Ui4 {
    val dlg = Dialogs(act)
    val flow = Flow4(this)
    val flow2 = Flow2(object : Ui2 {
        override fun render2() { this@App.render2() }
        override fun say2(t: String) { say(t) }
        override fun log2Now(t: String) { logNow(t) }
        override fun clearLog2() { clearLog() }
        override fun clearAct2() { ctl.removeAllViews() }
        override fun focusFirst2(what: String) { focusFirst(what) }
        override fun showNewGame2() {
            val b = dlg.btn("بازی جدید", false) { newGame() }
            b.tag = "act"
            ctl.addView(b)
            focusFirst("#a2 button")
        }
        override fun keepMsg2(on: Boolean) { }
        override fun pileUpd2() { this@App.updatePile() }
        override fun pickPrep(p: Int, face: Boolean, got: Card, out: Card) { this@App.pickPrep(p, got, out) }
        override fun asideTwo(out: List<Card>): Long? = this@App.asideTwo(out)
        override fun dsc2(p: Int, cards: List<Card>?): Long? = this@App.dsc2(p, cards)
    })

    private val scroll = ScrollView(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)

    private var screen = "menu"   // "menu" | "g4"

    // ---------------------------------------------------------------- shell

    /** builds the screens; called once after the object is constructed (so every property is initialised) */
    fun setup() {
        Px.init(act)
        act.root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        act.root.setBackgroundColor(Px.bg)
        act.root.fitsSystemWindows = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        scroll.isFillViewport = true
        scroll.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        act.root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        lobby = Lobby(act, dlg, this)
        client = Client(this)
        Fx.init(act)
        Av.groups = { avGroups() }
        buildHoldBar()
        Hold.ui = { holdUi() }
        Hold.logResume = { t -> if (MP.mode == 4) flow.log(t) else flow2.log2(t) }
        act.btEvt = { t, c, d -> lobby.onEvt(t, c, d) }
        buildMenu()
        buildG4()
        Sound.onChange = null
        showMenu()
        if (Prefs.name.isEmpty() || Prefs.gender.isEmpty()) dlg.nameAsk(false) { v -> Av.GN[v] = Prefs.gender; lobby.applyRename(v) }
    }

    lateinit var lobby: Lobby
    lateinit var client: Client

    fun currentScreen(): String = screen

    /** our side and the opponents at the table now, for the faces' reactions (avGroups) */
    private fun avGroups(): Pair<List<String>, List<String>>? = when (screen) {
        "g4" -> Pair(listOf(Av.me(), flow.NM[2]), listOf(flow.NM[1], flow.NM[3]))
        "g2" -> Pair(listOf(Av.me()), listOf(flow2.botName))
        "g5" -> {
            val fan = client.fan; val me = Av.me()
            if (fan.size == 1) Pair(listOf(me), listOf(fan[0].t))
            else { val g = { r: Int -> fan.firstOrNull { it.r == r }?.t ?: "" }; Pair(listOf(me, g(2)), listOf(g(1), g(3))) }
        }
        else -> null
    }

    // ---- the "game is held" bar at the bottom (holdUi of the page) ----
    private lateinit var holdBar: LinearLayout
    private lateinit var holdTv: TextView
    private lateinit var holdBtn: Button

    private fun buildHoldBar() {
        holdBar = LinearLayout(act); holdBar.orientation = LinearLayout.VERTICAL; holdBar.gravity = Gravity.CENTER_HORIZONTAL
        holdBar.setBackgroundColor(0xFF222222.toInt())
        holdBar.setPadding(Px.dp(10), Px.dp(12), Px.dp(10), Px.dp(12))
        holdBar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        holdTv = tv("", 15f, Color.WHITE); holdTv.gravity = Gravity.CENTER
        holdTv.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        holdBar.addView(holdTv)
        holdBtn = dlg.btn("ادامه بازی", false) { Hold.resume() }
        holdBar.addView(holdBtn)
        holdBar.visibility = View.GONE
        act.root.addView(holdBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }

    fun holdUi() {
        if (!::holdBar.isInitialized) return
        val host = MP.role == "host" && Hold.on
        val txt = if (host) Hold.txt else if (MP.role == "client") client.holdTxt else ""
        if (txt.isEmpty()) { holdBar.visibility = View.GONE; return }
        holdTv.text = txt
        holdBtn.visibility = if (host) View.VISIBLE else View.GONE
        holdBar.visibility = if (screen == "menu") View.GONE else View.VISIBLE
    }

    /** buttons in the action area of the guest screen (for "اتصال دوباره" / "خروج به منو") */
    fun clientButtons(items: List<Pair<String, () -> Unit>>) {
        ctl.removeAllViews()
        for (it in items) { val b = dlg.btn(it.first, false) { it.second() }; b.tag = "act"; ctl.addView(b) }
    }
    fun showClientScreen() { showScr("g5") }
    fun clientActionsClear() { ctl.removeAllViews() }

    // ---- "back to the game" while the menu is open over a running game (BG / goMain / bgResume of the page) ----
    private var bg = false
    private var bgScr = ""
    private lateinit var bgb: Button

    private fun uiBg() { if (::bgb.isInitialized) bgb.visibility = if (bg) View.VISIBLE else View.GONE }

    /** open the main menu without closing the running game */
    fun goMain() {
        val s = if (screen == "menu") "" else screen
        if (s.isEmpty()) { showMenu(); return }
        bgScr = s; bg = true
        panels("m1"); showScr("menu"); uiBg()
    }

    private fun bgResume() {
        val s = bgScr
        bg = false; uiBg()
        if (s.isNotEmpty()) showScr(s)
    }


    // used by the lobby screen
    fun moreButtonView(): View = moreButton()
    fun showScreen(x: String) { showScr(x) }
    fun showCreatePanel() { showCreate() }
    fun focusNode(v: View?) { if (v != null && Prefs.a11y) focusView(v) }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun item(t: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(t, f)

    private fun tv(t: String, size: Float, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    /** the round "⋮" button at the top corner (گزینه‌های بیشتر) */
    private fun moreButton(): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val b = TextView(act)
        b.text = "⋮"; b.textSize = 26f; b.setTextColor(Color.WHITE); b.gravity = Gravity.CENTER
        b.background = Px.rounded(0x59000000, 20)
        b.contentDescription = "گزینه‌های بیشتر"
        b.isClickable = true; b.isFocusable = true
        b.setOnClickListener { gMenu() }
        row.addView(b, lp(Px.dp(40), Px.dp(40)))
        return row
    }

    private fun showScr(x: String) {
        if (bg && x != "menu") { bgScr = x; uiBg(); return }
        screen = x
        content.removeAllViews()
        content.addView(if (x == "menu") menuV else if (x == "g6") lobby.view else g4V)
        if (x == "g5") { pBox[1]?.visibility = View.VISIBLE; pBox[3]?.visibility = View.VISIBLE }
        if (x == "g4" || x == "g2") {
            val v = if (x == "g2") View.INVISIBLE else View.VISIBLE
            pBox[1]?.visibility = v; pBox[3]?.visibility = v
        }
        holdUi()
    }

    // ---------------------------------------------------------------- menu (#menu)

    private lateinit var menuV: LinearLayout
    private lateinit var m1: LinearLayout
    private lateinit var m2: LinearLayout
    private lateinit var m3: LinearLayout
    private lateinit var m5: LinearLayout
    private lateinit var typeSpinner: Spinner

    private fun menuBtn(t: String, f: () -> Unit): Button {
        val b = dlg.btn(t, true, f)
        val l = lp(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    private fun panel(): LinearLayout {
        val p = LinearLayout(act); p.orientation = LinearLayout.VERTICAL; p.gravity = Gravity.CENTER_HORIZONTAL
        return p
    }

    private fun buildMenu() {
        menuV = LinearLayout(act); menuV.orientation = LinearLayout.VERTICAL
        menuV.addView(moreButton())
        val h1 = tv("بازی حکم", 30f, Px.tx, true); h1.gravity = Gravity.CENTER
        h1.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h1.isAccessibilityHeading = true
        menuV.addView(h1)

        m1 = panel()
        bgb = menuBtn("بازگشت به بازی") { bgResume() }
        bgb.visibility = View.GONE
        m1.addView(bgb)
        m1.addView(menuBtn("ایجاد بازی") { createAsk() })
        m1.addView(menuBtn("تنظیمات") { showSettings() })
        m1.addView(menuBtn("راهنما") { dlg.guide() })
        m1.addView(menuBtn("درباره") { dlg.about() })
        m1.addView(menuBtn("خروج") { exitAsk() })
        menuV.addView(m1)

        m3 = panel()
        m3.addView(tv("نوع بازی را انتخاب کنید:", 16f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        m3.addView(menuBtn("بازی با ربات") { showRobot() })
        m3.addView(menuBtn("بازی با چند گوشی") { lobby.showBT() })
        menuV.addView(m3)

        m5 = panel()
        m5.addView(tv("بازی با ربات:", 16f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        m5.addView(menuBtn("بازی جدید") { showSetup() })
        m5.addView(menuBtn("بازی‌های قبلی") { soloPrev() })
        menuV.addView(m5)

        m2 = panel()
        m2.addView(tv("نوع بازی حکم را انتخاب کنید:", 16f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        typeSpinner = Spinner(act)
        typeSpinner.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("دو نفره", "چهار نفره"))
        typeSpinner.speakLabel("نوع بازی حکم را انتخاب کنید")
        m2.addView(typeSpinner, lp(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), Px.dp(48)).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        m2.addView(menuBtn("شروع بازی") { typeGo() })
        menuV.addView(m2)
    }

    private fun panels(which: String) {
        m1.visibility = if (which == "m1") View.VISIBLE else View.GONE
        m2.visibility = if (which == "m2") View.VISIBLE else View.GONE
        m3.visibility = if (which == "m3") View.VISIBLE else View.GONE
        m5.visibility = if (which == "m5") View.VISIBLE else View.GONE
    }

    private fun notYet() {
        dlg.message("این بخش هنوز به نسخهٔ کاتلین اضافه نشده است و در مرحلهٔ بعد می‌آید.")
    }

    fun showMenu() {
        MP.reset(); bg = false; uiBg()
        if (::client.isInitialized) client.holdTxt = ""
        holdUi()
        Sched.newGen()
        panels("m1"); showScr("menu")
    }

    private fun showCreate() { panels("m3"); showScr("menu") }
    private fun showRobot() { panels("m5"); showScr("menu") }
    private fun showSetup() { typeSpinner.setSelection(0); panels("m2"); showScr("menu") }

    private fun typeGo() {
        if (typeSpinner.selectedItemPosition == 1) pickType(4) else pickType(2)
    }

    private fun pickType(n: Int) {
        soloId = null
        if (n == 4) start4() else start2()
    }

    private fun createAsk() {
        if (MP.role != "off") {
            dlg.confirm("یک بازی با چند گوشی در حال اجراست. اگر بازی جدید بسازید، آن بازی بسته می‌شود. ادامه می‌دهید؟", { MP.reset(); Sched.newGen(); showCreate() })
            return
        }
        showCreate()
    }

    private fun showSettings() {
        dlg.list("تنظیمات", listOf(
            item("تغییر نام") { renameAsk() },
            item("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) { a11yToggle(); showSettings() },
            item("تنظیمات صدا") { dlg.sound() },
            item("تنظیمات تصویر زمینه") { dlg.cards("bg") { applyBg() } },
            item("تنظیمات پشت کارت") { dlg.cards("back") { renderCur() } },
            item("سرعت انیمیشن") { animSpeedAsk() }
        ))
    }

    private fun renameAsk() { dlg.nameAsk(true) { v -> lobby.applyRename(v) } }

    private fun a11yToggle() {
        Prefs.a11y = !Prefs.a11y
        flow.resetSpk()
        applyA11y()
        if (Prefs.a11y && (screen == "g4" || screen == "g2")) logNow("دسترس‌پذیر بودن برنامه روشن شد.")
    }

    private fun animSpeedAsk() {
        fun mk(m: String, t: String) = item(t + (if (Anim.m == m) " ✓ (فعلی)" else "")) { Anim.set(m) }
        dlg.list("سرعت انیمیشن", listOf(mk("slow", "آهسته"), mk("norm", "عادی"), mk("fast", "سریع")), "بستن")
    }

    private fun quitAsk() {
        val g = if (MP.role == "off") (if (screen == "g4" || screen == "g2") " و بازی فعلی از بین می‌رود." else ".") else " و از بازی خارج می‌شوید."
        dlg.confirm("مطمئنید؟ برنامه کاملاً بسته می‌شود$g", { act.bridge.exitApp() })
    }

    private fun exitAsk() { quitAsk() }

    private fun askNew() {
        dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { newGame() })
    }

    fun newGame() {
        keepMsg(false)
        if (MP.role == "host") { lobby.hostBackToLobby(); return }
        Sched.newGen(); showScr("menu"); showSetup()
    }

    /** ⋮ menu of the game (host menu while a multi-phone game runs) */
    private fun gMenu() {
        val host = MP.role == "host" && MP.started
        val sc = if (bg) bgScr else screen
        val solo = MP.role == "off" && (sc == "g4" || sc == "g2")
        val guest = MP.role == "client" && sc == "g5"
        fun R(f: () -> Unit): () -> Unit = { if (bg) bgResume(); f() }
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (host || solo) items.add(item("بازی جدید", R { askNew() }))
        items.add(item("تغییر نام") { renameAsk() })
        if (lobby.freeSeats().isNotEmpty()) items.add(item("افزودن بازیکن", R { lobby.addAsk() }))
        if (MP.cl.values.any { it.seat != null }) items.add(item("حذف بازیکن", R { lobby.kickAsk() }))
        if (MP.cl.values.any { it.seat != null }) items.add(item("انتقال میزبانی", R { lobby.xferAsk() }))
        if (host) items.add(item("ذخیره") { lobby.saveGame() }) else if (solo) items.add(item("ذخیره") { saveSolo() })
        items.add(item("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) { a11yToggle() })
        items.add(item("سرعت انیمیشن") { animSpeedAsk() })
        items.add(item("تنظیمات صدا") { dlg.sound() })
        items.add(item("تنظیمات تصویر زمینه") { dlg.cards("bg") { applyBg() } })
        items.add(item("تنظیمات پشت کارت") { dlg.cards("back") { renderCur() } })
        if (host) items.add(item("خروج", R { hostExit() })) else if (solo || guest) items.add(item("خروج", R { quitAsk() }))
        dlg.list(if (host) "منوی میزبان" else "گزینه‌های بیشتر", items)
    }

    /** the host leaves the app: the host role goes to the first guest, a bot takes the seat (hostExit) */
    private fun hostExit() {
        if (MP.role != "host" || !MP.started) return
        val tid = lobby.xferTarget()
        dlg.confirm("مطمئنید؟ برنامه کاملاً بسته می‌شود." +
            (if (tid == null) " بازیکن دیگری در بازی نیست و بازی تمام می‌شود." else " میزبانی به " + MP.cl[tid]!!.name + " منتقل می‌شود و ربات جای شما بازی می‌کند."),
            { if (tid == null) act.bridge.exitApp() else lobby.startTransfer(tid, true) })
    }

    /** the phone's back button; true = handled (hokmBack of the page) */
    fun back(): Boolean {
        if (screen == "menu") {
            if (m2.visibility == View.VISIBLE) { showRobot(); return true }
            if (m5.visibility == View.VISIBLE) { showCreate(); return true }
            if (m3.visibility == View.VISIBLE) { showMenu(); return true }
            if (bg) { exitAsk(); return true }
            return false
        }
        if (screen == "g6") return lobby.back()
        if (screen == "g5") { goMain(); return true }
        if (screen == "g4" || screen == "g2") {
            dlg.confirm("بازی فعلی از بین می‌رود. به مرحله‌ی قبل برگردیم؟", { newGame() })
            return true
        }
        return false
    }

    // ---------------------------------------------------------------- save and previous games (against the bots)

    private var soloId: String? = null

    private fun saveSolo() {
        var ok = false
        try {
            val sn = if (screen == "g2") flow2.snapshot() else flow.snap()
            if (sn != null) {
                if (soloId == null) soloId = java.lang.Long.toString(System.currentTimeMillis(), 36) +
                    java.lang.Long.toString((Math.random() * 1679616.0).toLong(), 36)
                val old = Prefs.loadSolo()
                val a = JSONArray()
                val e = JSONObject()
                e.put("id", soloId); e.put("t", System.currentTimeMillis()); e.put("m", sn.getInt("m"))
                val sc0 = if (sn.getInt("m") == 2) sn.getJSONObject("Q").getJSONArray("sc") else sn.getJSONArray("sc")
                e.put("sc", JSONArray(sc0.toString())); e.put("bn", sn.optString("BOTN", "")); e.put("s", sn)
                a.put(e)
                for (i in 0 until old.length()) if (old.getJSONObject(i).optString("id") != soloId) a.put(old.getJSONObject(i))
                val cut = JSONArray()
                for (i in 0 until Math.min(30, a.length())) cut.put(a.get(i))
                ok = Prefs.putSolo(cut)
            }
        } catch (e: Exception) { ok = false }
        dlg.list(if (ok) "بازی ذخیره شد. هر وقت خواستید از «ایجاد بازی» ← «بازی با ربات» ← «بازی‌های قبلی» ادامه‌اش دهید." else "ذخیرهٔ بازی ممکن نشد.",
            emptyList(), "باشه")
    }

    private fun soloPrev() {
        val a = Prefs.loadSolo()
        if (a.length() == 0) {
            dlg.list("بازی ذخیره‌شده‌ای نیست. وسط بازی با ربات از «گزینه‌های بیشتر» دکمهٔ «ذخیره» را بزنید.", emptyList(), "باشه")
            return
        }
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale("fa", "IR"))
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (i in 0 until a.length()) {
            val e = a.getJSONObject(i)
            val sc = e.optJSONArray("sc")
            val t = (if (e.optInt("m") == 2) "دو نفره" else "چهار نفره") + " · امتیاز " +
                (if (sc != null) fa(sc.getInt(0)) + " به " + fa(sc.getInt(1)) else "—") + " · " + df.format(Date(e.optLong("t")))
            items.add(item(t) {
                dlg.list("این بازی:", listOf(
                    item("ادامهٔ بازی") { resumeSolo(e) },
                    item("حذف") {
                        val keep = JSONArray()
                        val cur = Prefs.loadSolo()
                        for (k in 0 until cur.length()) if (cur.getJSONObject(k).optString("id") != e.optString("id")) keep.put(cur.getJSONObject(k))
                        Prefs.putSolo(keep)
                        soloPrev()
                    }))
            })
        }
        dlg.list("بازی‌های قبلی", items)
    }

    /** continue a saved four-player game as host of a multi-phone game */
    fun resumeHost4(x: JSONObject, t: String, hum: List<String?>) {
        Sched.newGen()
        flow.restore(x, hum)
        showScr("g4"); clearLog(); clearCtl(); keepMsg(false)
        val e = flow.e
        if (flow.phase == "play") {
            primeResume4(); render(); flow.log(t); say(t); flow.next()
        } else if (flow.phase == "end" && (e.sc[0] >= 7 || e.sc[1] >= 7)) {
            primeResume4(); render(); keepMsg(true)
            showNewGameButton(if (Prefs.a11y) "بازی قبلاً تمام شده بود." else "")
        } else {
            flow.newHand(); flow.log(t)
        }
    }

    /** continue a saved two-player game as host of a multi-phone game */
    fun resumeHost2(x: JSONObject, t: String, opp: String) {
        Sched.newGen()
        showScr("g2"); clearLog(); keepMsg(false)
        primeResume2(x)
        flow2.resume(x, t, opp)
    }

    private fun resumeSolo(sv: JSONObject) {
        val x = sv.optJSONObject("s") ?: return
        Sched.newGen()
        soloId = sv.optString("id")
        val t = "بازی ذخیره‌شده ادامه پیدا کرد."
        if (x.optInt("m") == 2) { showScr("g2"); clearLog(); keepMsg(false); primeResume2(x); flow2.resume(x); return }
        flow.restore(x)
        showScr("g4"); clearLog(); clearCtl(); keepMsg(false)
        val e = flow.e
        if (flow.phase == "play") {
            primeResume4(); render(); flow.log(t); say(t); flow.next()
        } else if (flow.phase == "end" && (e.sc[0] >= 7 || e.sc[1] >= 7)) {
            primeResume4(); render(); keepMsg(true)
            showNewGameButton(if (Prefs.a11y) "بازی قبلاً تمام شده بود." else "")
        } else {
            flow.newHand(); flow.log(t)
        }
    }

    // ---------------------------------------------------------------- four-player table (#g4)

    private lateinit var g4V: LinearLayout
    private lateinit var topTr: TextView
    private lateinit var topHk: TextView
    private lateinit var topSc: TextView
    private lateinit var topTk: TextView
    private lateinit var table: LinearLayout
    private val pBox = arrayOfNulls<LinearLayout>(4)
    private lateinit var mid: FrameLayout
    private lateinit var msgBox: LinearLayout
    private lateinit var msgText: TextView
    private lateinit var ctl: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var logBox: LinearLayout
    private lateinit var handBox: LinearLayout

    private fun kv(label: String, value: String, valueColor: Int? = null): CharSequence {
        val sb = SpannableStringBuilder(label)
        val s = sb.length
        sb.append(value)
        sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (valueColor != null) sb.setSpan(ForegroundColorSpan(valueColor), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun buildG4() {
        g4V = LinearLayout(act); g4V.orientation = LinearLayout.VERTICAL
        g4V.addView(moreButton())
        val top = FlowLayout(act, Px.dp(10), Px.dp(2))
        topTr = tv("", 14f); topHk = tv("", 14f); topSc = tv("", 14f); topTk = tv("", 14f)
        for (t in listOf(topTr, topHk, topSc, topTk)) top.addView(t)
        g4V.addView(top, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin = Px.dp(6) })

        table = LinearLayout(act); table.orientation = LinearLayout.VERTICAL
        table.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        table.outlineProvider = ViewOutlineProvider.BACKGROUND
        table.clipToOutline = true
        for (i in 0 until 4) {
            val b = LinearLayout(act); b.orientation = LinearLayout.VERTICAL; b.gravity = Gravity.CENTER
            b.layoutDirection = View.LAYOUT_DIRECTION_RTL
            pBox[i] = b
        }
        table.addView(pBox[2], lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val row2 = LinearLayout(act); row2.orientation = LinearLayout.HORIZONTAL
        row2.layoutDirection = View.LAYOUT_DIRECTION_LTR   // physical: حریف ۱ left, حریف ۲ right
        mid = FrameLayout(act)
        mid.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        row2.addView(pBox[1], LinearLayout.LayoutParams(0, Px.dp(160), 1f))
        row2.addView(mid, LinearLayout.LayoutParams(0, Px.dp(160), 2f))
        row2.addView(pBox[3], LinearLayout.LayoutParams(0, Px.dp(160), 1f))
        table.addView(row2, lp(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(160)).also { it.topMargin = Px.dp(4); it.bottomMargin = Px.dp(4) })
        table.addView(pBox[0], lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        g4V.addView(table, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyBg()

        msgBox = LinearLayout(act); msgBox.orientation = LinearLayout.VERTICAL; msgBox.gravity = Gravity.CENTER_HORIZONTAL
        msgBox.minimumHeight = Px.dp(44)
        msgText = tv("", 14f); msgText.gravity = Gravity.CENTER
        msgBox.addView(msgText)
        g4V.addView(msgBox, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(8) })

        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL; ctl.gravity = Gravity.CENTER_HORIZONTAL
        g4V.addView(ctl)

        logScroll = ScrollView(act)
        logScroll.background = Px.rounded(0x11000000, 8)
        logScroll.setPadding(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6))
        logBox = LinearLayout(act); logBox.orientation = LinearLayout.VERTICAL
        // no live region / label on the container: it would read its label instead of the new lines.
        // Every new line is announced by logNow itself (the page's role="log" aria-live="polite").
        logScroll.addView(logBox)
        g4V.addView(logScroll, lp(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(140)).also { it.topMargin = Px.dp(6); it.bottomMargin = Px.dp(6) })
        logScroll.visibility = View.GONE

        handBox = LinearLayout(act); handBox.orientation = LinearLayout.VERTICAL; handBox.gravity = Gravity.CENTER_HORIZONTAL
        g4V.addView(handBox, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        applyA11y()
    }

    /** table look: plain felt or one of the rugs (applyBg) */
    private fun applyBg() {
        val n = Prefs.bg
        val bmp = if (n > 0) Assets.bitmap(act, Assets.bgPath(n)) else null
        if (bmp != null) table.background = CoverDrawable(bmp, 0x1F000000)
        else table.background = Px.rounded(Px.FELT, 16)
        table.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, Px.dp(16).toFloat()) }
        }
        table.clipToOutline = true
        renderCur()
    }

    /** body.na: with announcements off the message/log boxes are hidden */
    private fun applyA11y() {
        val on = Prefs.a11y
        logScroll.visibility = if (on) View.VISIBLE else View.GONE
        msgBox.visibility = if (on || keep) View.VISIBLE else View.GONE
    }

    private var keep = false
    /** redraw whichever table is showing */
    private fun renderCur() { if (screen == "g4") render() else if (screen == "g2") render2() else if (screen == "g5") renderClient() }

    override fun keepMsg(on: Boolean) {
        keep = on
        if (!on) { msgBox.removeAllViews(); msgBox.addView(msgText) }
        applyA11y()
    }

    // ---------------------------------------------------------------- Ui4

    override fun say(t: String) { msgText.text = t }

    override fun logNow(t: String) {
        if (!Prefs.a11y) return
        val d = tv(t, 13f)
        d.setPadding(0, Px.dp(3), 0, Px.dp(3))
        logBox.addView(d)
        announce(t)
        Sched.laterRaw(6000) { logBox.removeView(d) }
        while (logBox.childCount > 12) logBox.removeViewAt(0)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** speaks a line through the screen reader (like the page's polite live log); does nothing when no screen reader runs */
    private fun announce(t: String) {
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logBox.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    override fun clearLog() { logBox.removeAllViews() }
    override fun clearCtl() { ctl.removeAllViews() }

    override fun showNewGameButton(text: String) {
        msgBox.removeAllViews()
        if (text.isNotEmpty()) { msgText.text = text; msgBox.addView(msgText) }
        val b = dlg.btn("بازی جدید", false) { newGame() }
        b.tag = "newgame"
        msgBox.addView(b)
        applyA11y()
    }

    private fun trumpCardView(i: Int, fn: () -> Unit = { flow.setTrump(i) }): View {
        val b = FrameLayout(act)
        val iv = ImageView(act)
        iv.setImageBitmap(Assets.bitmap(act, Assets.cardPath(Card(i, 14))))
        iv.adjustViewBounds = true
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        b.addView(iv, FrameLayout.LayoutParams(Px.dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
        b.contentDescription = "انتخاب حکم " + SN[i]
        b.isClickable = true; b.isFocusable = true
        b.setOnClickListener { fn() }
        b.tag = "pick"
        val l = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); l.setMargins(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6))
        b.layoutParams = l
        return b
    }

    override fun showPick() {
        handBox.removeAllViews()
        val pk = LinearLayout(act); pk.orientation = LinearLayout.VERTICAL; pk.gravity = Gravity.CENTER_HORIZONTAL
        pk.addView(tv("حکم را انتخاب کنید:", 15f).also { it.gravity = Gravity.CENTER })
        val row = FlowLayout(act)
        for (i in 0 until 4) row.addView(trumpCardView(i))
        pk.addView(row)
        handBox.addView(pk)
        renderHandOnly(true)
        try {
            val e = flow.e; val ctr = Fx.center(mid); val oi = (0 - e.hakem + 4) % 4
            handViews.forEachIndexed { i, b ->
                val kk = key1(e.H[0][i])
                planFly(Fx.hn.toString() + "h" + kk, b, ctr, Deal.dl(i, oi, 4, Deal.part(4, handViews.size), handViews.size, Anim.ad(340).toLong()), Anim.ad(340).toLong(), 0.4f, Fx.rotOf(kk))
            }
        } catch (ex: Exception) { }
    }

    override fun renderHandOnly() { renderHandOnly(false) }

    private fun cardImage(c: Card, w: Int): ImageView {
        val iv = ImageView(act)
        iv.setImageBitmap(Assets.bitmap(act, Assets.cardPath(c)))
        iv.adjustViewBounds = true
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        iv.layoutParams = ViewGroup.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        return iv
    }

    /** the card views of the player's hand, in order (the page's button.card list) */
    private val handViews = ArrayList<View>()

    private fun renderHandOnly(pickMode: Boolean) {
        handViews.clear()
        if (!pickMode) handBox.removeAllViews()
        val w = FlowLayout(act, Px.dp(4), Px.dp(4))
        val e = flow.e
        val L = if (flow.phase == "play" && e.turn == 0 && !flow.busy && !flow.waiting) e.legal(0) else emptyList()
        for (c in e.H[0]) {
            val b = FrameLayout(act)
            b.addView(cardImage(c, Px.dp(50)))
            b.contentDescription = cname(c) + (if (c.s == e.trump) "، حکم" else "") + (if (L.contains(c)) "" else "، قابل بازی نیست")
            b.isFocusable = true
            if (L.contains(c)) {
                b.isClickable = true
                b.background = Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD)
                b.tag = "ok"
                b.setOnClickListener { flow.humanPlay(c) }
            } else {
                b.alpha = 0.45f
                b.isEnabled = false
            }
            w.addView(b)
        }
        handBox.addView(w)
    }

    private fun fanView(n: Int, top: Boolean): View {
        val f = LinearLayout(act)
        f.orientation = if (top) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        f.gravity = Gravity.CENTER
        f.minimumHeight = Px.dp(42)
        f.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        f.tag = "fan"
        val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back))
        for (i in 0 until Math.max(0, Math.min(n, 13))) {
            val iv = ImageView(act)
            iv.setImageBitmap(bmp)
            iv.adjustViewBounds = true
            val l = LinearLayout.LayoutParams(Px.dp(28), Px.dp(39))
            if (top) l.setMargins(-Px.dp(9), 0, -Px.dp(9), 0)
            else { l.setMargins(0, -Px.dp(16), 0, -Px.dp(16)); iv.rotation = 90f }
            f.addView(iv, l)
        }
        return f
    }

    override fun render() {
        val e = flow.e
        topTr.text = kv("حکم: ", if (e.trump < 0) "—" else SU[e.trump] + " " + SN[e.trump],
            if (e.trump == 1 || e.trump == 2) 0xFFEE3344.toInt() else null)
        topHk.text = kv("حاکم: ", flow.NM[e.hakem])
        topSc.text = SpannableStringBuilder("دست: شما+یار ").also {
            it.append(kv("", fa(e.sc[0]))); it.append(" | حریف "); it.append(kv("", fa(e.sc[1])))
        }
        topTk.text = SpannableStringBuilder("این دست: ").also {
            it.append(kv("", fa(e.tk[0]))); it.append(" - "); it.append(kv("", fa(e.tk[1])))
        }
        val dt: List<TC> = if (e.trick.isNotEmpty()) e.trick else flow.shown
        val rug = Prefs.bg > 0
        for (i in 0 until 4) {
            val p = pBox[i]!!
            p.removeAllViews()
            val act_ = flow.phase == "play" && e.turn == i
            val pc = dt.firstOrNull { it.seat == i }
            val n = TextView(act)
            n.text = flow.NM[i] + (if (i == e.hakem) " 👑" else "")
            n.textSize = 11f
            n.setTextColor(if (act_) 0xFFFFE36B.toInt() else Color.WHITE)
            if (act_) n.setTypeface(n.typeface, Typeface.BOLD)
            n.setPadding(Px.dp(6), Px.dp(2), Px.dp(6), Px.dp(2))
            n.background = Px.rounded(if (rug) 0x99000000.toInt() else 0x33000000, 8)
            if (Prefs.a11y && pc != null) n.contentDescription = n.text.toString() + ": " + cname(pc.c)
            p.addView(Av.view(act, if (i == 0) Av.me() else flow.NM[i], 44,
                act_ || (flow.phase == "pick" && e.hakem == i), act_))
            p.addView(n)
            if (i > 0) p.addView(fanView(e.H[i].size, i == 2))
        }
        mid.removeAllViews()
        for (t in dt) {
            val slot = FrameLayout(act)
            val win = e.trick.isEmpty() && t.seat == flow.winSeat
            if (win) slot.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD)
            slot.addView(cardImage(t.c, Px.dp(50)))
            val g = when (t.seat) {
                0 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                1 -> Gravity.LEFT or Gravity.CENTER_VERTICAL
                else -> Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            mid.addView(slot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, g))
        }
        if (flow.phase != "pick") renderHandOnly(false)
        else if (e.hakem != 0) {
            handBox.removeAllViews()
            handBox.addView(fanView(if (e.H[0].isNotEmpty()) e.H[0].size else 5, true))
        }
        post4()
        flow.mpSnap4()
    }

    // ---- motion effects after a redraw (post4 / post2 / postc of the page) ----
    private var fxGen = -1
    private var fxMid: List<Int> = emptyList()
    private var fxTrump = -1
    private var fxColl = ""
    private var fxCollDone = ""
    private var fxPrime = false

    /** the next state the host sends is the table as it already is (rejoin / added / new host): show it without any card flying or sound */
    fun primeClientFx() { fxPrime = true }

    private fun slotCard(i: Int): View? = (mid.getChildAt(i) as? FrameLayout)?.getChildAt(0)

    // ---- four-player table: dealing, cards of the opponents, played cards, hand, trump, collecting (st4 / post4) ----
    private class St4(val g: Int, val hn: Int, val mid: List<Int>, val cnt: IntArray, val hand: List<Int>, val trump: Int) { var back = false }
    private var last4: St4? = null

    /**
     * After a saved game is put back: tell post4() that the cards on the table / in the hands are
     * already there, so nothing is "dealt" again (no flying cards, no 50 rapid card sounds),
     * and forget the sound/deal timing left over from the game that was playing before.
     */
    private fun primeResume4() {
        Sound.resetQueue()
        Deal.reset()
        Spk.reset()
        Fx.deal4 = false; Fx.first5 = null
        val e = flow.e
        val dt: List<TC> = if (e.trick.isNotEmpty()) e.trick else flow.shown
        val st = St4(Sched.GEN, Fx.hn, dt.map { key1(it.c) }, IntArray(4) { e.H[it].size },
            e.H[0].map { key1(it) }, e.trump)
        last4 = st
        // the hand-collection animation of a finished trick must not replay either
        if (e.trick.isEmpty() && flow.shown.size == 4) {
            val ck = Fx.hn.toString() + "c" + flow.shown.joinToString(".") { key1(it.c).toString() }
            coll4 = ck
        }
    }
    /** two-player resume: the cards on the table are already there (only when the saved hand is being played) */
    private fun primeResume2(x: JSONObject) {
        Sound.resetQueue(); Deal.reset(); Spk.reset(); Fx.pkEnd = 0L
        if (x.optJSONObject("Q")?.optString("phase") == "play") primeClientFx()
    }
    private var coll4 = ""
    private var collDone4 = ""

    private fun key1(c: Card) = c.s * 20 + c.r
    private fun src4(s: Int) = if (s == 0) Fx.center(handBox) else Fx.center(pBox[s])
    private fun nm4(s: Int) = if (s == 0) Av.me() else Av.clean(flow.NM[s])
    private fun dealSz(nw: Int) = if (nw >= 8) 4 else Math.max(1, nw)
    private fun fanImgs(v: ViewGroup?): List<View> {
        if (v == null) return emptyList()
        for (i in 0 until v.childCount) { val c = v.getChildAt(i); if (c.tag == "fan" && c is ViewGroup) return (0 until c.childCount).map { c.getChildAt(it) } }
        return emptyList()
    }
    private fun planFly(id: String, v: View?, from: android.graphics.PointF?, pl: Deal.Plan, dur: Long, s: Float, rot: Float = 0f) {
        Fx.fly(id, v, from, dur, s, rot, pl.o ?: 0.35f, pl.delay, false, pl.snd)
    }

    private fun post4() {
        val e = flow.e; val pv = last4
        val dt: List<TC> = if (e.trick.isNotEmpty()) e.trick else flow.shown
        val hakem = e.hakem; val phase = flow.phase
        val cur = St4(Sched.GEN, Fx.hn, dt.map { key1(it.c) }, IntArray(4) { e.H[it].size },
            (if (phase == "pick" && hakem != 0) emptyList<Card>() else e.H[0]).map { key1(it) }, e.trump)
        val same = pv != null && pv.g == cur.g
        last4 = cur
        val hn = cur.hn; val ctr = Fx.center(mid)
        var cnt0 = if (same) pv!!.cnt else IntArray(4)
        var hand0: List<Int> = if (same) pv!!.hand else emptyList()
        if (Fx.deal4) {
            cnt0 = IntArray(4); hand0 = emptyList()
            if (cur.cnt.any { it > 0 }) { Fx.deal4 = false; Fx.first5 = e.H[0].map { key1(it) }.toSet() }
        }
        // cards on the table
        for ((i, t) in dt.withIndex()) {
            val kk = key1(t.c); val id = hn.toString() + "t" + kk; val isNew = same && !pv!!.mid.contains(kk)
            if (isNew || Fx.has(id)) {
                val sc = slotCard(i); val s0 = src4(t.seat)
                Fx.fly(id, sc, s0, Anim.ad(360).toLong(), 0.5f, Fx.rotOf(kk), snd = isNew)
                if (isNew) Fx.handFx(id, s0, Fx.center(sc), nm4(t.seat))
            }
        }
        // the opponents' cards fly from the middle while dealing
        for (i in 1..3) {
            val ims = fanImgs(pBox[i]); val nw = ims.size - cnt0[i]; val oi = (i - hakem + 4) % 4
            for (j in ims.indices) {
                val id = hn.toString() + "f" + i + "-" + j
                if (j >= cnt0[i] || Fx.has(id)) planFly(id, ims[j], ctr, Deal.dl(j - cnt0[i], oi, 4, Deal.part(4, nw), nw, Anim.ad(320).toLong()), Anim.ad(320).toLong(), 0.4f)
            }
        }
        // my face-down cards while another player picks the trump
        if (phase == "pick" && hakem != 0) {
            val ims = fanImgs(handBox); val oi = (0 - hakem + 4) % 4
            ims.forEachIndexed { j, im ->
                val id = hn.toString() + "b" + j
                if (Fx.deal4 || Fx.has(id) || !same || !pv!!.back) planFly(id, im, ctr, Deal.dl(j, oi, 4, Deal.part(4, ims.size), ims.size, Anim.ad(320).toLong()), Anim.ad(320).toLong(), 0.4f)
            }
            cur.back = true
        }
        // my own cards
        val hs = e.H[0]
        if (handViews.size == hs.size && !(phase == "pick" && hakem != 0)) {
            val f5 = Fx.first5
            val nws = hs.filter { !hand0.contains(key1(it)) && !(f5 != null && hakem != 0 && f5.contains(key1(it))) }
            val oi = (0 - hakem + 4) % 4
            hs.forEachIndexed { i, c ->
                val kk = key1(c); val id = hn.toString() + "h" + kk; val isNew = !hand0.contains(kk)
                if (isNew && f5 != null && hakem != 0 && f5.contains(kk)) {
                    Fx.fly(id, handViews[i], ctr, Anim.ad(280).toLong(), 0.55f, 0f, 0.35f, i * Anim.ad(40).toLong(), true, false)
                } else if (isNew || Fx.has(id)) {
                    val k = nws.indexOf(c)
                    planFly(id, handViews[i], ctr, Deal.dl(if (k < 0) 0 else k, oi, 4, Deal.part(4, nws.size), nws.size, Anim.ad(340).toLong()), Anim.ad(340).toLong(), 0.4f, Fx.rotOf(kk))
                }
            }
        }
        if (same && pv!!.trump < 0 && e.trump >= 0) Fx.trumpFlash(e.trump)
        // collecting a finished trick
        if (e.trick.isEmpty() && flow.shown.size == 4) {
            val ck = hn.toString() + "c" + flow.shown.joinToString(".") { key1(it.c).toString() }
            if (collDone4 == ck) { for (i in 0 until mid.childCount) mid.getChildAt(i).visibility = View.INVISIBLE }
            else if (coll4 != ck) {
                coll4 = ck
                Sched.later(Anim.ad(1000)) {
                    if (coll4 != ck || flow.shown.size != 4 || e.trick.isNotEmpty()) return@later
                    collDone4 = ck
                    Fx.takeAway((0 until mid.childCount).map { slotCard(it) }, src4(flow.winSeat), Anim.ad(520).toLong())
                }
            }
        }
    }

    /**
     * Newly played cards fly in from their player, the trump is flashed when it gets chosen, and a finished
     * trick is collected by its winner one second later.
     * keys/seats: the cards in the middle and who played them; coll: the cards of a finished trick (or null).
     */
    private fun postFx(keys: List<Int>, seats: List<Int>, names: List<String>, trump: Int, coll: List<Int>?, collSeat: Int,
                       srcOf: (Int) -> android.graphics.PointF?, still: () -> Boolean) {
        val prime = fxPrime; fxPrime = false
        val same = fxGen == Sched.GEN && !prime
        for (i in keys.indices) {
            val kk = keys[i]; val id = Fx.hn.toString() + "t" + kk; val isNew = same && !fxMid.contains(kk)
            if (isNew || Fx.has(id)) {
                val sc = slotCard(i); val s0 = srcOf(seats[i])
                Fx.fly(id, sc, s0, Anim.ad(360).toLong(), 0.5f, Fx.rotOf(kk), snd = isNew)
                if (isNew) Fx.handFx(id, s0, Fx.center(sc), names.getOrElse(i) { "" })
            }
        }
        if (same && fxTrump < 0 && trump >= 0) Fx.trumpFlash(trump)
        if (coll != null) {
            val ck = Sched.GEN.toString() + "c" + coll.joinToString(".")
            if (prime) fxColl = ck
            if (fxCollDone == ck) { for (i in 0 until keys.size) mid.getChildAt(i)?.visibility = View.INVISIBLE }
            else if (fxColl != ck) {
                fxColl = ck
                Sched.later(Anim.ad(1000)) {
                    if (fxColl != ck || !still()) return@later
                    fxCollDone = ck
                    Fx.takeAway((0 until keys.size).map { slotCard(it) }, srcOf(collSeat), Anim.ad(520).toLong())
                }
            }
        }
        fxGen = Sched.GEN; fxMid = keys; fxTrump = trump
    }

    /** the guest's table, drawn from the state the host sent (c5render) */
    fun renderClient() {
        val c = client
        val ask = c.ask
        val p4 = (if (c.fan.isNotEmpty()) c.fan.size == 3 else c.mode == 4) && c.v4
        pBox[1]?.visibility = if (p4) View.VISIBLE else View.INVISIBLE
        pBox[3]?.visibility = if (p4) View.VISIBLE else View.INVISIBLE
        topTr.text = kv("حکم: ", if (c.tr < 0) "—" else SU[c.tr] + " " + SN[c.tr], if (c.tr == 1 || c.tr == 2) 0xFFEE3344.toInt() else null)
        topHk.text = kv("حاکم: ", c.hkn.ifEmpty { "—" })
        topSc.text = SpannableStringBuilder("دست: " + (if (p4) "شما+یار " else "شما ")).also {
            it.append(kv("", fa(c.scv[0]))); it.append(" | حریف "); it.append(kv("", fa(c.scv[1])))
        }
        topTk.text = SpannableStringBuilder("این دست: ").also {
            it.append(kv("", fa(c.tkv[0]))); it.append(" - "); it.append(kv("", fa(c.tkv[1])))
        }
        val rug = Prefs.bg > 0
        val nz = { q: String -> q.replace(" (یار)", "") }
        fun nameChip(text: String, active: Boolean, played: CT?): TextView {
            val n = TextView(act)
            n.text = text; n.textSize = 11f
            n.setTextColor(if (active) 0xFFFFE36B.toInt() else Color.WHITE)
            if (active) n.setTypeface(n.typeface, Typeface.BOLD)
            n.setPadding(Px.dp(6), Px.dp(2), Px.dp(6), Px.dp(2))
            n.background = Px.rounded(if (rug) 0x99000000.toInt() else 0x33000000, 8)
            if (Prefs.a11y && played != null) n.contentDescription = text + ": " + cname(played.c)
            return n
        }
        for (i in 1..3) pBox[i]?.removeAllViews()
        pBox[1]?.visibility = if (p4) View.VISIBLE else View.INVISIBLE
        pBox[3]?.visibility = if (p4) View.VISIBLE else View.INVISIBLE
        for (x in c.fan) {
            val p = pBox[x.r] ?: continue
            val played = c.table.firstOrNull { it.n != "شما" && nz(it.n) == nz(x.t) }
            p.addView(Av.view(act, x.t, 44, (c.ph == "play" && c.tn == x.r) || (c.ph == "pick" && c.hr == x.r), c.ph == "play" && c.tn == x.r))
            p.addView(nameChip(x.t + (if (c.hr == x.r) " 👑" else ""), c.ph == "play" && c.tn == x.r, played))
            p.addView(fanView(x.n, x.r == 2))
        }
        val me = pBox[0]!!
        me.removeAllViews()
        me.addView(Av.view(act, Av.me(), 44, (c.ph == "play" && c.tn == 0) || (c.ph == "pick" && c.hr == 0), c.ph == "play" && c.tn == 0))
        me.addView(nameChip("شما" + (if (c.hr == 0) " 👑" else ""), c.ph == "play" && c.tn == 0, c.table.firstOrNull { it.n == "شما" }))
        mid.removeAllViews()
        for (x in c.table) {
            val slot = FrameLayout(act)
            if (c.wr >= 0 && c.wr == x.r) slot.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD)
            slot.addView(cardImage(x.c, Px.dp(50)))
            val g = when (x.r) {
                0 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                1 -> Gravity.LEFT or Gravity.CENTER_VERTICAL
                else -> Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            mid.addView(slot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, g))
        }
        // actions
        ctl.removeAllViews()
        val k = ask?.optString("k") ?: ""
        if (k == "disc") {
            val b = dlg.btn("تأیید کنار گذاشتن دو کارت انتخاب‌شده", false) {
                if (c.sel.size != 2) c.c5log("باید دقیقاً دو کارت انتخاب کنید.")
                else c.answer(org.json.JSONArray().also { a -> c.sel.forEach { a.put(org.json.JSONObject().put("s", it.s).put("r", it.r)) } })
            }
            b.tag = "act"; ctl.addView(b)
        } else if (k == "draw") {
            val up = ask!!.getJSONObject("d").getJSONObject("up")
            val upC = Card(up.getInt("s"), up.getInt("r"))
            val row = FlowLayout(act)
            fun pk(path: String, desc: String, fn: () -> Unit): View {
                val b = FrameLayout(act)
                val iv = ImageView(act)
                iv.setImageBitmap(Assets.bitmap(act, path)); iv.adjustViewBounds = true
                iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                b.addView(iv, FrameLayout.LayoutParams(Px.dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
                b.contentDescription = desc; b.isClickable = true; b.isFocusable = true; b.tag = "act"
                b.setOnClickListener { fn() }
                val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                l.setMargins(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6)); b.layoutParams = l
                return b
            }
            row.addView(pk(Assets.cardPath(upC), "برداشتن کارت رو: " + cname(upC)) { c.answer("face") })
            row.addView(pk(Assets.backPath(Prefs.back), "برداشتن کارت پنهان") { c.answer("hidden") })
            ctl.addView(row)
        }
        // hand
        handBox.removeAllViews()
        var target: ViewGroup = handBox
        if (p4 || k == "trump") {
            if (k == "trump") {
                val pkv = LinearLayout(act); pkv.orientation = LinearLayout.VERTICAL; pkv.gravity = Gravity.CENTER_HORIZONTAL
                pkv.addView(tv("حکم را انتخاب کنید:", 15f).also { it.gravity = Gravity.CENTER })
                val r = FlowLayout(act)
                for (i in 0 until 4) r.addView(trumpCardView(i) { c.answer(i) })
                pkv.addView(r); handBox.addView(pkv)
            }
            if (c.ph == "pick" && c.hr != 0 && k != "trump") handBox.addView(fanView(if (c.bk > 0) c.bk else 5, true))
            else { val w = FlowLayout(act, Px.dp(4), Px.dp(4)); handBox.addView(w); target = w }
        } else { val w = FlowLayout(act, Px.dp(4), Px.dp(4)); handBox.addView(w); target = w }
        val src = if (k == "trump" || k == "disc") c.askCards("hand") else c.hand
        val hand = src.sortedWith { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r }
        val lg = if (k == "play") c.askCards("cards") else emptyList()
        for ((i, cd) in hand.withIndex()) {
            val b = FrameLayout(act)
            b.addView(cardImage(cd, Px.dp(50)))
            var desc = cname(cd) + (if (c.tr >= 0 && cd.s == c.tr) "، حکم" else "")
            b.isFocusable = true
            if (k == "disc") {
                val on = c.sel.any { it.s == cd.s && it.r == cd.r }
                b.isClickable = true; b.tag = "hand"
                b.background = if (on) Px.rounded(Color.TRANSPARENT, 7, 3, 0xFFEE3344.toInt()) else Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD)
                desc += if (on) "، انتخاب شده" else "، انتخاب نشده"
                b.setOnClickListener {
                    c.toggleSel(cd)
                    val vs = ArrayList<View>(); collectTag(handBox, "hand", vs)
                    vs.getOrNull(i)?.let { focusView(it) }
                }
            } else if (k == "play" && lg.any { it.s == cd.s && it.r == cd.r }) {
                b.isClickable = true; b.tag = "ok"
                b.background = Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD)
                b.setOnClickListener { c.answer(org.json.JSONObject().put("s", cd.s).put("r", cd.r)) }
            } else {
                b.alpha = 0.45f; b.isEnabled = false
                if (p4 || c.ph == "play" || k == "play") desc += "، قابل بازی نیست"
            }
            b.contentDescription = desc
            target.addView(b)
        }
        val full = if (p4) 4 else 2
        postFx(c.table.map { it.c.s * 20 + it.c.r }, c.table.map { it.r }, c.table.map { if (it.n == "شما") Av.me() else Av.clean(it.n) }, c.tr,
            if (c.wr >= 0 && c.table.size == full) c.table.map { it.c.s * 20 + it.c.r } else null, c.wr,
            { r -> if (r == 0) Fx.center(handBox) else Fx.center(pBox[r]) }, { client.wr >= 0 && client.table.size == full })
    }

    override fun focusFirst(what: String) {
        if (!Prefs.a11y && (what.startsWith("#hand") || what.startsWith(".pick") || what.startsWith("#a2") || what.startsWith("#msg"))) return
        val d = Math.max(0L, flow.spkEnd() - Sched.now())
        if (d > 0) Sched.laterRaw(d) { focusNow(what) } else focusNow(what)
    }

    private fun findTag(v: View, tag: String): View? {
        if (v.tag == tag && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findTag(v.getChildAt(i), tag)?.let { return it }
        return null
    }

    private fun focusNow(what: String) {
        val v = (if (what.contains("pick")) findTag(g4V, "pick")
        else if (what.startsWith("#a2")) findTag(g4V, "act")
        else if (what.contains(".ok")) findTag(g4V, "ok")
        else if (what.startsWith("#hand2")) (findTag(g4V, "hand") ?: findTag(g4V, "ok"))
        else if (what.contains("msg")) findTag(g4V, "newgame") else null) ?: return
        v.requestFocus()
        v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        v.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
    }

    // ---------------------------------------------------------------- start

    fun start4() {
        showScr("g4")
        flow.start4()
    }

    fun start2() {
        showScr("g2")
        flow2.start2(true)
    }

    private fun focusView(v: View) {
        v.requestFocus()
        v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
        v.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
    }

    private fun playerName2(i: Int, text: String, pc: TP?, active: Boolean): TextView {
        val n = TextView(act)
        n.text = text
        n.textSize = 11f
        n.setTextColor(if (active) 0xFFFFE36B.toInt() else Color.WHITE)
        if (active) n.setTypeface(n.typeface, Typeface.BOLD)
        n.setPadding(Px.dp(6), Px.dp(2), Px.dp(6), Px.dp(2))
        n.background = Px.rounded(if (Prefs.bg > 0) 0x99000000.toInt() else 0x33000000, 8)
        if (Prefs.a11y && pc != null) n.contentDescription = text + ": " + cname(pc.c)
        return n
    }

    // ---- the pile of put-aside cards in the middle of the two-player table (pileUpd2 / pileSpot / asideCards) ----

    private fun pileView(n: Int): View {
        val f = FrameLayout(act)
        f.tag = "pile"
        f.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        val im = ImageView(act); im.setImageBitmap(Assets.bitmap(act, Assets.backPath(Prefs.back))); im.scaleType = ImageView.ScaleType.FIT_XY
        f.addView(im, FrameLayout.LayoutParams(Px.dp(44), Px.dp(64)))
        val b = TextView(act)
        b.text = n.toString(); b.textSize = 11f; b.setTextColor(Color.WHITE)
        b.background = Px.rounded(0xBB000000.toInt(), 9); b.setPadding(Px.dp(5), 0, Px.dp(5), 0)
        f.addView(b, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.RIGHT or Gravity.BOTTOM).also { it.setMargins(0, 0, -Px.dp(6), -Px.dp(6)) })
        return f
    }

    /** shows, updates or removes the pile on the two-player table */
    private fun updatePile() {
        if (screen != "g2") return
        for (i in mid.childCount - 1 downTo 0) if (mid.getChildAt(i).tag == "pile") mid.removeViewAt(i)
        val n = flow2.pile
        if (n <= 0) return
        mid.addView(pileView(n), FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.LEFT or Gravity.TOP).also { it.setMargins(Px.dp(8), Px.dp(8), 0, 0) })
    }

    /** the middle of the pile in root coordinates */
    private fun pileSpot(): android.graphics.PointF {
        val c = Fx.center(mid) ?: return android.graphics.PointF(60f * Px.d, 220f * Px.d)
        return android.graphics.PointF(c.x - mid.width / 2f + Px.dp(8 + 22), c.y - mid.height / 2f + Px.dp(8 + 32))
    }

    /** the two 2s appear on both sides of the table's middle, are shown, and fly to the pile */
    private fun asideTwo(out: List<Card>): Long? {
        val c = Fx.center(mid) ?: return null
        if (mid.width == 0) return null
        val mx = act.root.width / 2f
        val to = pileSpot()
        return Fx.asideCards(out.mapIndexed { i, cd ->
            Fx.AItem(cd, null, android.graphics.PointF(mx + (if (i == 1) 72 else -72) * Px.d, c.y), 550, 650, i * Anim.ad(420), Px.dp(80).toFloat())
        }, to)
    }

    /** a player's two discarded cards fly to the pile (yours from your hand, the opponent's from his cards) */
    private fun dsc2(p: Int, cards: List<Card>?): Long? {
        val to = pileSpot()
        val items = ArrayList<Fx.AItem>()
        if (p == 0 && cards != null && cards.isNotEmpty()) {
            val vs = ArrayList<View>(); collectTag(handBox, "hand", vs)
            val hs = Cards.sorted2(flow2.e.hands[0])
            val f = Fx.center(handBox) ?: android.graphics.PointF(200f * Px.d, 420f * Px.d)
            cards.forEachIndexed { i, cd ->
                val v = vs.getOrNull(hs.indexOf(cd)); val c = Fx.center(v)
                items.add(Fx.AItem(cd, c ?: f, null, 0, 650, Anim.ad(800) + i * Anim.ad(420), if (c != null && v != null) Math.min(Px.dp(60).toFloat(), v.width.toFloat()) else Px.dp(46).toFloat()))
            }
        } else {
            val o = pBox[2]!!
            val fan = (0 until o.childCount).map { o.getChildAt(it) }.firstOrNull { it is LinearLayout } as? LinearLayout
            val f = Fx.center(o) ?: android.graphics.PointF(200f * Px.d, 110f * Px.d)
            val dw = Math.max(Anim.ad(900).toLong(), if (Deal.wait() > 0) Deal.wait() + Anim.ad(600) else 0L).toInt()
            for (i in 0..1) {
                val v = fan?.getChildAt(i); val c = Fx.center(v)
                items.add(Fx.AItem(null, c ?: f, null, 0, 650, dw + i * Anim.ad(420), if (c != null && v != null) v.width.toFloat() else Px.dp(40).toFloat()))
            }
        }
        return Fx.asideCards(items, to)
    }

    // ---- the two-player drawing animation (pickRun / pk2E of the page) ----
    private class PickD(val k: String, val t: Long, val got: Card, val out: Card, val fr: List<android.graphics.PointF?>, val fw: List<Float>)
    private var pickD: PickD? = null
    private var pkHide: Pair<Long, () -> View?>? = null

    private fun pickPrep(p: Int, got: Card, out: Card) {
        var fr: List<android.graphics.PointF?> = listOf(null, null); var fw = listOf(0f, 0f)
        if (p == 0) {
            val vs = ArrayList<View>(); collectTag(ctl, "act", vs)
            if (vs.size >= 2) { fr = vs.take(2).map { Fx.center(it) }; fw = vs.take(2).map { it.width.toFloat() } }
        }
        pickD = PickD(if (p == 0) "me" else "opp", Sched.now(), got, out, fr, fw)
    }

    /** the view that shows the card just taken: your new card in the hand, or the last of the opponent's cards */
    private fun pickTarget(k: String, got: Card): View? {
        if (k == "me") {
            val hand = handBox.getChildAt(handBox.childCount - 1) as? ViewGroup ?: return null
            val i = Cards.sorted2(flow2.e.hands[0]).indexOf(got)
            return if (i >= 0) hand.getChildAt(i) else null
        }
        val o = pBox[2] ?: return null
        val fan = (0 until o.childCount).map { o.getChildAt(it) }.lastOrNull { it is LinearLayout } as? LinearLayout ?: return null
        return fan.getChildAt(fan.childCount - 1)
    }

    private fun runPick() {
        val h = pkHide
        if (h != null && Sched.now() < h.first) h.second()?.visibility = View.INVISIBLE
        val pd = pickD ?: return
        pickD = null
        if (Sched.now() - pd.t > 2500) return
        val tg = pickTarget(pd.k, pd.got)
        val ctr = Fx.center(mid)
        val pile = pileSpot()
        val to = Fx.center(tg)
        if (tg == null || to == null || ctr == null) {
            Sound.cardSnd(); Sched.laterRaw(Anim.ad(420).toLong()) { Sound.cardSnd() }
            flow2.pickLand(); return
        }
        tg.visibility = View.INVISIBLE
        pkHide = Pair(Sched.now() + Anim.ad(420) + Anim.ad(500) + Anim.ad(600) + Anim.ad(120)) { pickTarget(pd.k, pd.got) }
        val dp44 = Px.dp(44).toFloat()
        val fr = if (pd.k == "me" && pd.fr[0] != null && pd.fr[1] != null) listOf(pd.fr[0]!!, pd.fr[1]!!)
        else listOf(android.graphics.PointF(ctr.x - 44 * Px.d, ctr.y), android.graphics.PointF(ctr.x + 44 * Px.d, ctr.y))
        val fw = if (pd.k == "me" && pd.fr[0] != null && pd.fr[1] != null) pd.fw else listOf(Px.dp(46).toFloat(), Px.dp(46).toFloat())
        val back = Assets.bitmap(act, Assets.backPath(Prefs.back))
        val faces = if (pd.k == "me") listOf(Assets.bitmap(act, Assets.cardPath(pd.got)), Assets.bitmap(act, Assets.cardPath(pd.out))) else listOf(back, back)
        Fx.pickRun(faces, fr, fw, to, tg.width.toFloat(), pile, dp44, { try { tg.visibility = View.VISIBLE } catch (e: Exception) { }; pkHide = null }, { flow2.pickLand() })
    }

    /** the two-player table (render20) */
    fun render2() {
        val e = flow2.e
        val ph = flow2.phase
        topTr.text = kv("حکم: ", if (e.trump < 0) "—" else SU[e.trump] + " " + SN[e.trump], if (e.trump == 1 || e.trump == 2) 0xFFEE3344.toInt() else null)
        topHk.text = kv("حاکم: ", if (e.hk == 0) "شما" else flow2.botName)
        topSc.text = SpannableStringBuilder("دست: شما ").also { it.append(kv("", fa(e.sc[0]))); it.append(" | حریف "); it.append(kv("", fa(e.sc[1]))) }
        topTk.text = SpannableStringBuilder("این دست: ").also { it.append(kv("", fa(e.tk[0]))); it.append(" - "); it.append(kv("", fa(e.tk[1]))) }
        val dt: List<TP> = if (e.trick.isNotEmpty()) e.trick else e.shown
        fun act(p: Int) = ph == "play" && flow2.turn == p
        val opp = pBox[2]!!; opp.removeAllViews()
        opp.addView(Av.view(act, flow2.botName, 44, act(1), act(1)))
        opp.addView(playerName2(1, flow2.botName + (if (e.hk == 1) " 👑" else ""), dt.firstOrNull { it.p == 1 }, act(1)))
        opp.addView(fanView(e.hands[1].size, true))
        val me = pBox[0]!!; me.removeAllViews()
        me.addView(Av.view(act, Av.me(), 44, act(0), act(0)))
        me.addView(playerName2(0, "شما" + (if (e.hk == 0) " 👑" else ""), dt.firstOrNull { it.p == 0 }, act(0)))
        mid.removeAllViews()
        for (t in dt) {
            val slot = FrameLayout(act)
            if (e.trick.isEmpty() && t.p == flow2.turn) slot.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD)
            slot.addView(cardImage(t.c, Px.dp(50)))
            val g = if (t.p == 0) Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL else Gravity.TOP or Gravity.CENTER_HORIZONTAL
            mid.addView(slot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, g))
        }
        updatePile()
        // action area (a2)
        ctl.removeAllViews()
        if (ph == "disc") {
            val b = dlg.btn("تأیید کنار گذاشتن دو کارت انتخاب‌شده", false) { flow2.confirmDisc() }
            b.tag = "act"; ctl.addView(b)
        } else if (ph == "draw" && flow2.ch == 0) {
            if (!Prefs.a11y) ctl.addView(tv("یک کارت بردارید:", 13f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(4), 0, Px.dp(4)) })
            val row = FlowLayout(act)
            fun pk(bmpPath: String, desc: String, fn: () -> Unit): View {
                val b = FrameLayout(act)
                val iv = ImageView(act)
                iv.setImageBitmap(Assets.bitmap(act, bmpPath)); iv.adjustViewBounds = true
                iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                b.addView(iv, FrameLayout.LayoutParams(Px.dp(64), ViewGroup.LayoutParams.WRAP_CONTENT))
                b.contentDescription = desc; b.isClickable = true; b.isFocusable = true; b.tag = "act"
                b.setOnClickListener { fn() }
                val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                l.setMargins(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6)); b.layoutParams = l
                return b
            }
            val up = flow2.up!!
            row.addView(pk(Assets.cardPath(up), "برداشتن کارت رو: " + cname(up)) { flow2.take2(0, true) })
            row.addView(pk(Assets.backPath(Prefs.back), "برداشتن کارت پنهان") { flow2.take2(0, false) })
            ctl.addView(row)
        }
        // hand
        handBox.removeAllViews()
        if (ph == "trump") {
            val pkv = LinearLayout(act); pkv.orientation = LinearLayout.VERTICAL; pkv.gravity = Gravity.CENTER_HORIZONTAL
            pkv.addView(tv("حکم را انتخاب کنید:", 15f).also { it.gravity = Gravity.CENTER })
            val r = FlowLayout(act)
            for (i in 0 until 4) r.addView(trumpCardView(i) { flow2.pickTrump2(i) })
            pkv.addView(r); handBox.addView(pkv)
        }
        val w = FlowLayout(act, Px.dp(4), Px.dp(4))
        val L = if (ph == "play" && flow2.turn == 0 && !flow2.busy) e.legal2(0) else emptyList()
        val sorted = Cards.sorted2(e.hands[0])
        for (c in sorted) {
            val b = FrameLayout(act)
            b.addView(cardImage(c, Px.dp(50)))
            var desc = cname(c) + (if (c.s == e.trump) "، حکم" else "")
            b.isFocusable = true
            if (ph == "disc") {
                val on = flow2.sel.contains(c)
                b.isClickable = true; b.tag = "hand"
                b.background = if (on) Px.rounded(Color.TRANSPARENT, 7, 3, 0xFFEE3344.toInt()) else Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD)
                desc += if (on) "، انتخاب شده" else "، انتخاب نشده"
                val idx = sorted.indexOf(c)
                b.setOnClickListener {
                    flow2.toggleSel(c)
                    val vs = ArrayList<View>(); collectTag(handBox, "hand", vs)
                    vs.getOrNull(idx)?.let { focusView(it) }
                }
            } else if (ph == "play" && L.contains(c)) {
                b.isClickable = true; b.tag = "ok"
                b.background = Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD)
                b.setOnClickListener { flow2.humanPlay(c) }
            } else {
                b.alpha = 0.45f; b.isEnabled = false
                if (ph == "play") desc += "، قابل بازی نیست"
            }
            b.contentDescription = desc
            w.addView(b)
        }
        handBox.addView(w)
        postFx(dt.map { it.c.s * 20 + it.c.r }, dt.map { it.p }, dt.map { if (it.p == 0) Av.me() else Av.clean(flow2.botName) }, e.trump,
            if (e.trick.isEmpty() && e.shown.size == 2) e.shown.map { it.c.s * 20 + it.c.r } else null, flow2.turn,
            { p -> if (p == 0) Fx.center(handBox) else Fx.center(pBox[2]) }, { e.shown.size == 2 && e.trick.isEmpty() })
        runPick()
        flow2.mpSnap2()
    }

    private fun collectTag(v: View, tag: String, out: MutableList<View>) {
        if (v.tag == tag) out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) collectTag(v.getChildAt(i), tag, out)
    }
}
