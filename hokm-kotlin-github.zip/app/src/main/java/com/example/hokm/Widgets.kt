package com.example.hokm

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.LruCache
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Spinner

/** dp helper and theme colors (the page's --bg / --tx / --felt, light and dark). */
object Px {
    var d = 1f
    var night = false
    fun dp(v: Int): Int = Math.round(v * d)
    fun dp(v: Float): Int = Math.round(v * d)

    val bg get() = if (night) 0xFF171A18.toInt() else 0xFFF4F1EA.toInt()
    val tx get() = if (night) 0xFFEEEEEE.toInt() else 0xFF1D1D1B.toInt()
    const val FELT = 0xFF1F6B47.toInt()
    const val BTN = 0xFF1F6B47.toInt()
    const val GOLD = 0xFFFFD34D.toInt()

    fun init(c: Context) {
        d = c.resources.displayMetrics.density
        night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
        return g
    }
}

/** Card pictures and table backgrounds from the assets folder, cached. */
object Assets {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(k: String, v: Bitmap): Int = v.byteCount
    }

    fun bitmap(ctx: Context, path: String): Bitmap? {
        cache.get(path)?.let { return it }
        return try {
            ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }?.also { cache.put(path, it) }
        } catch (e: Exception) { null }
    }

    private val CSN = arrayOf("spades", "hearts", "diamonds", "clubs")
    private val CRN = mapOf(11 to "J", 12 to "Q", 13 to "K", 14 to "A")

    fun cardPath(c: Card) = "cards/" + CSN[c.s] + "_" + (CRN[c.r] ?: c.r.toString()) + ".png"
    fun backPath(n: Int) = "cards/backs/b" + n.toString().padStart(2, '0') + ".png"
    fun bgPath(n: Int) = "cards/bg/r$n.jpg"
    fun bgThumb(n: Int) = "cards/bg/r${n}t.jpg"
}

/** Draws a bitmap scaled to cover its bounds (CSS: center / cover) with a 12% dark veil. */
class CoverDrawable(private val bmp: Bitmap, private val veil: Int) : Drawable() {
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    override fun draw(c: Canvas) {
        val b = bounds
        val s = Math.max(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val w = bmp.width * s; val h = bmp.height * s
        val l = b.left + (b.width() - w) / 2; val t = b.top + (b.height() - h) / 2
        c.save(); c.clipRect(b)
        c.drawBitmap(bmp, null, android.graphics.RectF(l, t, l + w, t + h), p)
        c.drawColor(veil)
        c.restore()
    }
    override fun setAlpha(a: Int) { p.alpha = a }
    override fun setColorFilter(f: ColorFilter?) { p.colorFilter = f }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/** Wrapping row layout, rows centered (CSS: display:flex; flex-wrap:wrap; justify-content:center; gap). */
class FlowLayout(ctx: Context, private val hgap: Int = 0, private val vgap: Int = 0) : ViewGroup(ctx) {
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec) - paddingLeft - paddingRight
        var x = 0; var rowH = 0; var y = 0; var usedW = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            measureChild(c, MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.UNSPECIFIED)
            val w = c.measuredWidth; val h = c.measuredHeight
            if (x > 0 && x + w > maxW) { y += rowH + vgap; x = 0; rowH = 0 }
            x += w + hgap; rowH = Math.max(rowH, h); usedW = Math.max(usedW, x - hgap)
        }
        y += rowH
        val wMode = MeasureSpec.getMode(wSpec)
        val width = if (wMode == MeasureSpec.EXACTLY) MeasureSpec.getSize(wSpec) else usedW + paddingLeft + paddingRight
        setMeasuredDimension(width, y + paddingTop + paddingBottom)
    }

    override fun onLayout(ch: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL
        val rows = ArrayList<ArrayList<View>>(); var cur = ArrayList<View>(); var x = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == View.GONE) continue
            if (cur.isNotEmpty() && x + c.measuredWidth > maxW) { rows.add(cur); cur = ArrayList(); x = 0 }
            cur.add(c); x += c.measuredWidth + hgap
        }
        if (cur.isNotEmpty()) rows.add(cur)
        var y = paddingTop
        for (row in rows) {
            var rw = -hgap; var rh = 0
            for (c in row) { rw += c.measuredWidth + hgap; rh = Math.max(rh, c.measuredHeight) }
            var px = paddingLeft + (maxW - rw) / 2
            val ordered = if (rtl) row.reversed() else row
            for (c in ordered) {
                c.layout(px, y + (rh - c.measuredHeight) / 2, px + c.measuredWidth, y + (rh - c.measuredHeight) / 2 + c.measuredHeight)
                px += c.measuredWidth + hgap
            }
            y += rh + vgap
        }
    }
}


/**
 * A drop-down list for the screen reader: it says its label and the item that is chosen now ("جنسیت شما: زن"),
 * like a labelled <select> of the page. (A plain contentDescription would hide the chosen item.)
 */
fun Spinner.speakLabel(label: String) {
    accessibilityDelegate = object : View.AccessibilityDelegate() {
        override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(host, info)
            info.contentDescription = label + ": " + (selectedItem?.toString() ?: "")
        }
    }
}
