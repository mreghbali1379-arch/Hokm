package com.example.hokm

import android.app.Activity
import android.content.Intent
import org.json.JSONObject

/** "بازی‌های قبلی": the games saved by hand, with continue and delete. */
object PreviousGames {

    fun show(a: Activity) {
        val slots = Slots.all(a)
        if (slots.isEmpty()) {
            SettingsUi.toast(a, "هنوز بازی ذخیره‌شده‌ای ندارید.")
            return
        }
        SettingsUi.list(
            a, "بازی‌های قبلی",
            slots.map { s -> (s.title + " — " + Slots.dateText(s.time)) to { open(a, s) } },
            "بستن"
        )
    }

    private fun open(a: Activity, s: Slots.Slot) {
        SettingsUi.list(
            a, s.title,
            listOf(
                "ادامهٔ بازی" to { resume(a, s) },
                "حذف" to { SettingsUi.confirm(a, "این بازی ذخیره‌شده حذف شود؟") { Slots.delete(a, s.id) } }
            ),
            "بستن"
        )
    }

    private fun resume(a: Activity, s: Slots.Slot) {
        try {
            when (s.kind) {
                "4" -> {
                    val o = JSONObject(s.data)
                    SaveStore.putRaw(a, o.getString("g"))
                    val n = o.optJSONArray("n")
                    if (n != null) SaveStore.saveNames(a, (0 until n.length()).map { n.getString(it) })
                    a.startActivity(Intent(a, SoloGameActivity::class.java).putExtra("resume", true))
                }
                "2" -> {
                    DuoSaveStore.putRaw(a, s.data)
                    a.startActivity(Intent(a, DuoGameActivity::class.java).putExtra("resume", true))
                }
                "mp" -> a.startActivity(Intent(a, MpActivity::class.java).putExtra("slot", s.id))
            }
        } catch (e: Exception) {
            SettingsUi.toast(a, "این بازی ذخیره‌شده خراب است و باز نشد.")
        }
    }
}
