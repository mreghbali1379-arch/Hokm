package com.example.hokm

import org.json.JSONObject

/**
 * What the multi-phone screen needs from a table that runs on the host phone: the four-player table
 * ([MpHostEngine]) or the two-player table ([MpHostEngine2]).
 */
interface TableEngine {
    /** Names of the humans by seat ("" = robot). */
    val names: Array<String>
    val human: BooleanArray
    val started: Boolean

    /** Number of seats: 4 or 2. */
    val seats: Int

    fun displayName(seat: Int): String
    fun seatJoin(seat: Int, name: String)
    fun seatLeave(seat: Int)

    /** A message from a human (see the engines for the kinds). */
    fun action(seat: Int, o: JSONObject)
    fun start()
    fun stop()

    /** Sends the current view of the table again to [seat]. */
    fun sync(seat: Int)

    fun snapshot(): String
    fun restore(s: String): Boolean
    fun resume(note: String)

    /**
     * Called after [restore] on the phone that takes over as host and sits in [oldSeat]: the table may have to be
     * turned around so that the host is always the first player. Returns the host's seat from now on.
     */
    fun reseatHost(oldSeat: Int): Int = oldSeat
}
