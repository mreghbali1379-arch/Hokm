package com.example.hokm.engine

/**
 * Scoring shared by the 2-player and the 4-player game.
 * A "tally" is IntArray(3): [tricks of team 0, tricks of team 1, team that started a kot (-1 = nobody)].
 */
object Scoring {
    /** Returned by [points] while the hand is not decided yet. */
    const val NONE = Int.MIN_VALUE

    /** Value of a bam (13-0) in points. */
    const val BAM = 7

    /** Adds a trick to team w and remembers who first reached 7 while the other had 0. */
    fun adv(t: IntArray, w: Int) {
        t[w]++
        if (t[2] == -1 && t[w] >= 7 && t[1 - w] == 0) t[2] = w
    }

    /**
     * Hand result from the point of view of [team]: +points if it wins, -points if it loses,
     * [NONE] while undecided. [hakemTeam] = the team (4 players) or seat (2 players) of the hakem.
     */
    fun points(t: IntArray, team: Int, hakemTeam: Int): Int {
        val w = if (t[0] >= 7) 0 else if (t[1] >= 7) 1 else -1
        if (w < 0) return NONE
        if (t[1 - w] == 0) {
            if (t[w] < 13) return NONE
            return if (w == team) BAM else -BAM
        }
        val p = if (t[2] == w) (if (w == hakemTeam) 2 else 3) else 1
        return if (w == team) p else -p
    }

    /** Chance of winning the whole match (first to 7) from score a-b with a to move, used by the bots. */
    val MW: Array<DoubleArray> = run {
        val w = Array(8) { a -> DoubleArray(8) { b -> if (a >= 7) 1.0 else 0.0 } }
        for (a in 6 downTo 0) for (b in 6 downTo 0) w[a][b] = 0.5 * w[a + 1][b] + 0.5 * w[a][b + 1]
        w
    }
}

/** Value of each possible hand result (-7..+7 points) for a bot; index = points + 7. */
class ResultValues(private val useMatchWin: Boolean = true) {
    val lv = DoubleArray(15) { 0.5 }

    /** Sets the values for team [me] given the match score [sc]. */
    fun set(me: Int, sc: IntArray) {
        if (!useMatchWin) {
            for (p in -7..7) lv[p + 7] = 0.5 + p / 14.0
            return
        }
        val a = minOf(7, sc[me])
        val b = minOf(7, sc[1 - me])
        for (p in -7..7) {
            val v = when {
                p > 0 -> Scoring.MW[minOf(7, a + p)][b]
                p < 0 -> Scoring.MW[a][minOf(7, b - p)]
                else -> Scoring.MW[a][b]
            }
            lv[p + 7] = v + 0.004 * p
        }
    }
}
