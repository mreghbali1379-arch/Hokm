package com.example.hokm

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText

/** Card faces, card backs and table backgrounds from assets/cards. */
object CardArt {
    private val SUITS = arrayOf("spades", "hearts", "diamonds", "clubs")
    private val FACES = mapOf(11 to "J", 12 to "Q", 13 to "K", 14 to "A")
    private val cache = object : LruCache<String, Bitmap>(70) {}

    private fun load(ctx: Context, path: String): Bitmap? {
        val hit = cache.get(path)
        if (hit != null) return hit
        return try {
            ctx.assets.open(path).use { BitmapFactory.decodeStream(it) }?.also { cache.put(path, it) }
        } catch (e: Exception) {
            null
        }
    }

    fun face(ctx: Context, c: Card): Bitmap? = load(ctx, "cards/" + SUITS[c.s] + "_" + (FACES[c.r] ?: c.r.toString()) + ".png")

    fun back(ctx: Context, n: Int): Bitmap? = load(ctx, "cards/backs/b" + n.toString().padStart(2, '0') + ".png")

    fun rugThumb(ctx: Context, n: Int): Bitmap? = load(ctx, "cards/bg/r" + n + "t.jpg")

    /** The table background chosen in the settings (plain green or a rug). */
    fun background(ctx: Context): Drawable {
        val n = Prefs.bg(ctx)
        if (n > 0) {
            val b = load(ctx, "cards/bg/r$n.jpg")
            if (b != null) {
                val d = BitmapDrawable(ctx.resources, b)
                d.gravity = Gravity.FILL
                return d
            }
        }
        return ColorDrawable(0xFF1F6B47.toInt())
    }

    /** Width in pixels of a card when [columns] cards sit next to each other on the screen. */
    fun cardWidth(ctx: Context, columns: Int): Int {
        val d = ctx.resources.displayMetrics
        return (d.widthPixels - (32 * d.density).toInt()) / columns - (6 * d.density).toInt()
    }

    fun asButton(v: View) {
        v.accessibilityDelegate = object : View.AccessibilityDelegate() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.className = Button::class.java.name
            }
        }
    }

    /** A card the player can tap. Disabled cards are dimmed; a selected card has a yellow frame. */
    fun cardButton(ctx: Context, c: Card, width: Int, enabled: Boolean, selected: Boolean, onClick: () -> Unit): ImageView {
        val iv = ImageView(ctx)
        iv.setImageBitmap(face(ctx, c))
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = (3 * ctx.resources.displayMetrics.density).toInt()
        iv.setPadding(pad, pad, pad, pad)
        iv.setBackgroundColor(if (selected) Color.YELLOW else Color.TRANSPARENT)
        iv.contentDescription = CardText.cardName(c) + (if (selected) "، انتخاب‌شده" else "")
        iv.isEnabled = enabled
        iv.alpha = if (enabled) 1f else 0.45f
        iv.isFocusable = true
        iv.isClickable = enabled
        asButton(iv)
        iv.setOnClickListener { if (iv.isEnabled) onClick() }
        iv.layoutParams = android.widget.GridLayout.LayoutParams().also {
            it.width = width
            it.height = width * 210 / 150
            val m = (2 * ctx.resources.displayMetrics.density).toInt()
            it.setMargins(m, m, m, m)
        }
        return iv
    }

    /** A face-down card (for hidden cards); [onClick] may be null. */
    fun backView(ctx: Context, width: Int, desc: String, onClick: (() -> Unit)?): ImageView {
        val iv = ImageView(ctx)
        iv.setImageBitmap(back(ctx, Prefs.back(ctx)))
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.contentDescription = desc
        if (onClick != null) {
            iv.isFocusable = true
            iv.isClickable = true
            asButton(iv)
            iv.setOnClickListener { onClick() }
        }
        iv.layoutParams = android.widget.LinearLayout.LayoutParams(width, width * 210 / 150)
        return iv
    }

    /** Puts a small face-down card (the chosen card back) at the end of [tv]. */
    fun markBack(tv: TextView) {
        val ctx = tv.context
        val b = back(ctx, Prefs.back(ctx)) ?: return
        val d = BitmapDrawable(ctx.resources, b)
        val h = (62 * ctx.resources.displayMetrics.density).toInt()
        d.setBounds(0, 0, h * 150 / 210, h)
        tv.setCompoundDrawablesRelative(tv.compoundDrawablesRelative[0], null, d, null)
        tv.compoundDrawablePadding = (8 * ctx.resources.displayMetrics.density).toInt()
    }

    /** Puts a small picture of [c] at the end of [tv] (nothing when null). It is not read by screen readers. */
    fun mark(tv: TextView, c: Card?) {
        val ctx = tv.context
        if (c == null) {
            tv.setCompoundDrawablesRelative(tv.compoundDrawablesRelative[0], null, null, null)
            return
        }
        val b = face(ctx, c) ?: return
        val d = BitmapDrawable(ctx.resources, b)
        val h = (62 * ctx.resources.displayMetrics.density).toInt()
        d.setBounds(0, 0, h * 150 / 210, h)
        tv.setCompoundDrawablesRelative(tv.compoundDrawablesRelative[0], null, d, null)
        tv.compoundDrawablePadding = (8 * ctx.resources.displayMetrics.density).toInt()
    }
}
