package com.example.hokm

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.InputFilter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.example.hokm.engine.CardText

/** Dialogs shared by the menu and the games: name, card back, background, sound, accessibility, about. */
object SettingsUi {

    private fun dp(a: Activity, v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    fun toast(a: Activity, t: String) {
        Toast.makeText(a, t, Toast.LENGTH_SHORT).show()
    }

    /** A list of actions in a dialog. */
    fun list(a: Activity, title: String, items: List<Pair<String, () -> Unit>>, close: String = "انصراف") {
        AlertDialog.Builder(a)
            .setTitle(title)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .setNegativeButton(close, null)
            .show()
    }

    fun confirm(a: Activity, message: String, yes: () -> Unit) {
        AlertDialog.Builder(a)
            .setMessage(message)
            .setPositiveButton("بله") { _, _ -> yes() }
            .setNegativeButton("خیر", null)
            .show()
    }

    // ------------------------------------------------------------------ name and gender

    fun nameDialog(a: Activity, cancellable: Boolean, done: () -> Unit) {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), dp(a, 4))
        val q = TextView(a)
        q.text = "نام شما چیست؟ در بازی با چند گوشی بقیهٔ بازیکنان همین نام را می‌بینند."
        box.addView(q)
        val et = EditText(a)
        et.setText(if (Prefs.hasName(a)) Prefs.name(a) else "")
        et.filters = arrayOf(InputFilter.LengthFilter(20))
        et.contentDescription = "نام شما"
        box.addView(et)
        val g = TextView(a)
        g.text = "جنسیت شما (برای آدمکی که سر میز برای شما می‌نشیند):"
        g.setPadding(0, dp(a, 12), 0, 0)
        box.addView(g)
        val rg = RadioGroup(a)
        val rf = RadioButton(a)
        rf.id = 401
        rf.text = "زن"
        val rm = RadioButton(a)
        rm.id = 402
        rm.text = "مرد"
        rg.addView(rf)
        rg.addView(rm)
        rg.check(if (Prefs.gender(a) == "m") 402 else 401)
        box.addView(rg)
        val err = TextView(a)
        err.setTextColor(Color.RED)
        box.addView(err)
        val b = AlertDialog.Builder(a).setView(box).setPositiveButton("تأیید", null)
        if (cancellable) b.setNegativeButton("انصراف", null)
        val dlg = b.create()
        dlg.setCancelable(cancellable)
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    err.text = "نام را وارد کنید."
                } else {
                    Prefs.setName(a, n)
                    Prefs.setGender(a, if (rg.checkedRadioButtonId == 402) "m" else "f")
                    dlg.dismiss()
                    done()
                }
            }
        }
        dlg.show()
    }

    // ------------------------------------------------------------------ card back and background

    fun backDialog(a: Activity, onChange: () -> Unit) {
        val cur = Prefs.back(a)
        val grid = GridLayout(a)
        grid.columnCount = 4
        val w = (a.resources.displayMetrics.widthPixels - dp(a, 80)) / 4
        var dlg: AlertDialog? = null
        for (n in 1..35) {
            val iv = ImageView(a)
            iv.setImageBitmap(CardArt.back(a, n))
            val pad = dp(a, 3)
            iv.setPadding(pad, pad, pad, pad)
            iv.setBackgroundColor(if (n == cur) Color.YELLOW else Color.TRANSPARENT)
            iv.contentDescription = "طرح " + CardText.fa(n) + (if (n == cur) "، انتخاب‌شده" else "")
            iv.isFocusable = true
            iv.isClickable = true
            CardArt.asButton(iv)
            iv.setOnClickListener {
                Prefs.setBack(a, n)
                dlg?.dismiss()
                onChange()
            }
            val lp = GridLayout.LayoutParams()
            lp.width = w
            lp.height = w * 210 / 150
            lp.setMargins(dp(a, 2), dp(a, 2), dp(a, 2), dp(a, 2))
            grid.addView(iv, lp)
        }
        val sv = ScrollView(a)
        sv.addView(grid)
        dlg = AlertDialog.Builder(a).setTitle("تنظیمات پشت کارت").setView(sv).setNegativeButton("بستن", null).create()
        dlg.show()
    }

    fun bgDialog(a: Activity, onChange: () -> Unit) {
        val cur = Prefs.bg(a)
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8))
        var dlg: AlertDialog? = null
        for (n in 0..4) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(a, 6), dp(a, 6), dp(a, 6), dp(a, 6))
            val label = if (n == 0) "سبز ساده" else "فرش " + CardText.fa(n)
            val thumb = ImageView(a)
            if (n == 0) thumb.setImageDrawable(ColorDrawable(0xFF1F6B47.toInt())) else thumb.setImageBitmap(CardArt.rugThumb(a, n))
            thumb.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            row.addView(thumb, LinearLayout.LayoutParams(dp(a, 60), dp(a, 90)))
            val t = TextView(a)
            t.text = label
            t.textSize = 18f
            t.setPadding(dp(a, 12), 0, 0, 0)
            t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            row.addView(t)
            row.contentDescription = label + (if (n == cur) "، انتخاب‌شده" else "")
            row.setBackgroundColor(if (n == cur) 0x44FFEB3B else Color.TRANSPARENT)
            row.isFocusable = true
            row.isClickable = true
            CardArt.asButton(row)
            row.setOnClickListener {
                Prefs.setBg(a, n)
                dlg?.dismiss()
                onChange()
            }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val sv = ScrollView(a)
        sv.addView(col)
        dlg = AlertDialog.Builder(a).setTitle("تنظیمات تصویر زمینه").setView(sv).setNegativeButton("بستن", null).create()
        dlg.show()
    }

    // ------------------------------------------------------------------ sound, speed, accessibility, about

    fun speedDialog(a: Activity, snd: Sound) {
        val opts = listOf("بدون پخش (رد شدن)" to 0f, "آهسته" to 1f, "عادی" to 2f, "سریع" to 4f)
        list(
            a, "سرعت پخش کارت‌ها",
            opts.map { (t, v) -> (t + (if (snd.dealSpeed == v) " ✓ (فعلی)" else "")) to { snd.setDealSpeed(v) } },
            "بستن"
        )
    }

    /** Speed of the small movements (cards appearing, landing on the table, faces). */
    fun animDialog(a: Activity) {
        val cur = Prefs.anim(a)
        val opts = listOf("آهسته" to "slow", "عادی" to "norm", "سریع" to "fast")
        list(
            a, "سرعت انیمیشن",
            opts.map { (t, v) -> (t + (if (cur == v) " ✓ (فعلی)" else "")) to { Prefs.setAnim(a, v) } },
            "بستن"
        )
    }

    fun soundDialog(a: Activity, snd: Sound) {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(a, 20), dp(a, 12), dp(a, 20), dp(a, 4))
        val on = CheckBox(a)
        on.text = "صدا و موسیقی"
        on.isChecked = snd.on
        on.setOnCheckedChangeListener { _, b -> snd.setOn(b) }
        box.addView(on)
        fun slider(title: String, value: Float, change: (Float) -> Unit) {
            val t = TextView(a)
            t.text = title
            t.setPadding(0, dp(a, 12), 0, 0)
            box.addView(t)
            val sb = SeekBar(a)
            sb.max = 100
            sb.progress = Math.round(value * 100)
            sb.contentDescription = title
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) change(p / 100f)
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
            box.addView(sb)
        }
        slider("صدای آهنگ", snd.volMusic) { snd.setMusicVolume(it) }
        slider("صدای افکت‌ها", snd.volFx) { snd.setFxVolume(it) }
        snd.addDealSpeedControl(a, box)
        AlertDialog.Builder(a).setTitle("تنظیمات صدا").setView(box).setPositiveButton("بستن", null).show()
    }

    /** Applies the "accessibility helpers" setting: automatic reading of messages on or off. */
    fun applyA11y(a: Activity, msg: TextView) {
        msg.accessibilityLiveRegion = if (Prefs.a11y(a)) View.ACCESSIBILITY_LIVE_REGION_POLITE else View.ACCESSIBILITY_LIVE_REGION_NONE
    }

    fun a11yLabel(a: Activity): String = "دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y(a)) "روشن" else "خاموش")

    fun a11yToggle(a: Activity, onChange: () -> Unit) {
        Prefs.setA11y(a, !Prefs.a11y(a))
        toast(a, "دسترس‌پذیر بودن برنامه " + (if (Prefs.a11y(a)) "روشن شد." else "خاموش شد."))
        onChange()
    }

    fun aboutDialog(a: Activity) {
        val v = try {
            val pi = a.packageManager.getPackageInfo(a.packageName, 0)
            @Suppress("DEPRECATION")
            val code: Long = if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
            "نسخهٔ ساخت: " + pi.versionName + " (" + code + ")"
        } catch (e: Exception) {
            ""
        }
        AlertDialog.Builder(a)
            .setTitle("درباره")
            .setMessage("بازی حکم\n\nحکم چهار نفره و دو نفره، با ربات یا با چند گوشی (بلوتوث یا وای‌فای)، قابل استفاده با صفحه‌خوان.\n\n$v")
            .setPositiveButton("بستن", null)
            .show()
    }
}
