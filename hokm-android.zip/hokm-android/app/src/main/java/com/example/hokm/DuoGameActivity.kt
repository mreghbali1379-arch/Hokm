package com.example.hokm

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.CheckBox
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.example.hokm.engine.Bot2
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import com.example.hokm.engine.Deck
import com.example.hokm.engine.Entry2
import com.example.hokm.engine.Game2
import com.example.hokm.engine.HakemDraw
import com.example.hokm.engine.Phase2
import com.example.hokm.engine.Result2
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * Two-player Hokm against a robot, built from ordinary Android views.
 * Each round: both throw away two of five cards, the hakem names the trump, then 20 steps of drawing
 * (see Game2) give 13 cards each, then 13 tricks are played.
 * Game state is changed on the main thread only; the robot thinks on a background thread.
 */
class DuoGameActivity : Activity() {

    private enum class Stage { WAIT, DISCARD, TRUMP, DRAW, PLAY }

    private val g = Game2()
    private val bot = Bot2(g)
    private val ui = Handler(Looper.getMainLooper())
    private val pool: ExecutorService = Executors.newSingleThreadExecutor()
    private var gen = 0
    private var busy = true
    private var stage = Stage.WAIT

    private lateinit var scoreView: TextView
    private lateinit var msgView: TextView
    private lateinit var tableViews: Array<TextView>
    private lateinit var handGrid: GridLayout
    private lateinit var pickRow: LinearLayout
    private lateinit var drawRow: LinearLayout
    private lateinit var takeUpBtn: Button
    private lateinit var takeDownBtn: Button
    private lateinit var confirmBtn: Button
    private lateinit var newGameBtn: Button
    private lateinit var skipBtn: Button
    private lateinit var log: GameLog
    private lateinit var board: AvatarBoard
    private var lastHand = 0
    private lateinit var narrator: DrawNarrator

    private val selected = ArrayList<Card>()
    private var shown: List<Entry2> = emptyList()
    private var shownWinner = -1
    private var lastWinner = -1

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private var rootView: View? = null
    private var oppName: String = BotNames.pick(1)[0]

    private fun who(p: Int): String = if (p == 0) "شما" else oppName

    private fun sortedHand(): List<Card> {
        val h = ArrayList(g.hands[0])
        Deck.sortHand(h)
        return h
    }

    private fun handText(): String = sortedHand().joinToString("، ") { CardText.cardName(it) }

    private fun suitName(t: Int): String = CardText.SUIT_NAMES[t]

    // ------------------------------------------------------------------ screen

    private lateinit var snd: Sound

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        snd = Sound.get(this)
        log = GameLog(this)
        board = AvatarBoard(ui, 2) { p -> avatarFor(p, true) }
        narrator = DrawNarrator(ui, snd)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        scoreView = label(16f, true)
        col.addView(scoreView, matchWrap())

        msgView = label(18f, false)
        SettingsUi.applyA11y(this, msgView)
        msgView.setBackgroundColor(0x33000000)
        msgView.setPadding(dp(8), dp(8), dp(8), dp(8))
        col.addView(msgView, matchWrap().also { it.topMargin = dp(8) })

        val table = LinearLayout(this)
        table.orientation = LinearLayout.VERTICAL
        table.setPadding(dp(8), dp(8), dp(8), dp(8))
        table.setBackgroundColor(0x22FFFFFF)
        tableViews = Array(2) { label(17f, false) }
        for (p in 0 until 2) table.addView(tableViews[p], matchWrap())
        col.addView(table, matchWrap().also { it.topMargin = dp(8) })

        pickRow = LinearLayout(this)
        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.visibility = View.GONE
        for (t in 0 until 4) {
            val b = Button(this)
            b.isAllCaps = false
            b.text = suitName(t) + " " + CardText.SUIT_SYMBOLS[t]
            b.contentDescription = "حکم " + suitName(t)
            b.setTextColor(if (t == 1 || t == 2) Color.RED else Color.BLACK)
            b.setOnClickListener { pickTrump(t) }
            pickRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(pickRow, matchWrap().also { it.topMargin = dp(8) })

        drawRow = LinearLayout(this)
        drawRow.orientation = LinearLayout.HORIZONTAL
        drawRow.visibility = View.GONE
        takeUpBtn = tool("کارت رو") { humanTake(true) }
        takeDownBtn = tool("کارت پشت") { humanTake(false) }
        drawRow.addView(takeUpBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        drawRow.addView(takeDownBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(drawRow, matchWrap().also { it.topMargin = dp(8) })

        handGrid = GridLayout(this)
        handGrid.columnCount = 5
        col.addView(handGrid, matchWrap().also { it.topMargin = dp(8) })

        confirmBtn = tool("کنار گذاشتن دو کارت انتخاب‌شده") { confirmDiscard() }
        confirmBtn.visibility = View.GONE
        col.addView(confirmBtn, matchWrap().also { it.topMargin = dp(8) })

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(tool("دست قبل") { readLastTrick() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("وضعیت") { readStatus() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("گزینه‌ها") { showOptions() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("منو") { finish() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(tools, matchWrap().also { it.topMargin = dp(12) })
        col.addView(tool("کارت‌های بازی‌شده در این دست") { readTable() }, matchWrap().also { it.topMargin = dp(4) })

        skipBtn = tool("رد کردن پخش کارت‌ها") {
            snd.skipDeal()
            narrator.skip()
        }
        skipBtn.visibility = View.GONE
        col.addView(skipBtn, matchWrap().also { it.topMargin = dp(8) })

        newGameBtn = tool("بازی جدید") { startMatch() }
        newGameBtn.visibility = View.GONE
        col.addView(newGameBtn, matchWrap().also { it.topMargin = dp(8) })

        col.addView(log.view, matchWrap().also { it.topMargin = dp(16) })

        val sv = ScrollView(this)
        sv.background = CardArt.background(this)
        rootView = sv
        sv.addView(col)
        setContentView(sv)

        if (intent.getBooleanExtra("resume", false)) {
            when (DuoSaveStore.load(this, g)) {
                DuoSaveStore.PLAY -> resumePlay()
                DuoSaveStore.ROUND -> startRound()
                else -> startMatch()
            }
        } else {
            startMatch()
        }
    }

    /** Continues a saved game in the middle of the 13 tricks. */
    private fun resumePlay() {
        gen++
        newGameBtn.visibility = View.GONE
        selected.clear()
        stage = Stage.PLAY
        busy = true
        shown = ArrayList(g.trick)
        shownWinner = -1
        lastWinner = -1
        renderAll()
        say("بازی قبلی ادامه پیدا کرد. حکم " + suitName(g.trump) + " است. کارت‌های شما: " + handText() + ".")
        nextPlay(true)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun label(size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(Color.WHITE)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun tool(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { action() }
        return b
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        gen++
        ui.removeCallbacksAndMessages(null)
        pool.shutdownNow()
        snd.release()
    }

    // ------------------------------------------------------------------ options, save, look

    private fun applyLook() {
        rootView?.background = CardArt.background(this)
        SettingsUi.applyA11y(this, msgView)
    }

    private fun showOptions() {
        SettingsUi.list(
            this, "گزینه‌های بیشتر",
            listOf(
                "بازی جدید" to { SettingsUi.confirm(this, "بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.") { startMatch() } },
                "تغییر نام" to { SettingsUi.nameDialog(this, true) {} },
                "ذخیره" to { saveSlot() },
                SettingsUi.a11yLabel(this) to { SettingsUi.a11yToggle(this) { applyLook() } },
                "سرعت انیمیشن" to { SettingsUi.animDialog(this) },
                "سرعت پخش کارت‌ها" to { SettingsUi.speedDialog(this, snd) },
                "تنظیمات صدا" to { SettingsUi.soundDialog(this, snd) },
                "تنظیمات تصویر زمینه" to { SettingsUi.bgDialog(this) { applyLook() } },
                "تنظیمات پشت کارت" to { SettingsUi.backDialog(this) { renderAll() } },
                "خروج" to { finish() }
            ),
            "بستن"
        )
    }

    /** Saves the game as a named entry of "بازی‌های قبلی" (leaving a round that is not in play repeats that round). */
    private fun saveSlot() {
        val data = DuoSaveStore.dump(g, stage == Stage.PLAY)
        Slots.add(this, "2", "بازی دونفره با ربات، امتیاز " + CardText.fa(g.sc[0]) + " به " + CardText.fa(g.sc[1]), data)
        SettingsUi.toast(this, "بازی ذخیره شد.")
    }

    private fun endSounds(h: Result2) {
        val mine = h.team == 0
        if (h.kot) snd.sfx(if (mine) "kwin" else "klose")
        if (h.gameOver) snd.sfx(if (mine) "fwin" else "flose")
        if (!h.kot && !h.gameOver) snd.sfx(if (mine) "win" else "lose")
    }

    private fun showSoundDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))

        val on = CheckBox(this)
        on.text = "صدا و موسیقی"
        on.isChecked = snd.on
        on.setOnCheckedChangeListener { _, b -> snd.setOn(b) }
        box.addView(on)

        fun slider(title: String, value: Float, change: (Float) -> Unit) {
            val t = TextView(this)
            t.text = title
            t.setPadding(0, dp(12), 0, 0)
            box.addView(t)
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = Math.round(value * 100)
            sb.contentDescription = title
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) change(p / 100f)
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
            box.addView(sb)
        }
        slider("صدای آهنگ", snd.volMusic) { snd.setMusicVolume(it) }
        slider("صدای افکت‌ها", snd.volFx) { snd.setFxVolume(it) }
        snd.addDealSpeedControl(this, box)

        AlertDialog.Builder(this)
            .setTitle("صدا")
            .setView(box)
            .setPositiveButton("بستن", null)
            .show()
    }

    // ------------------------------------------------------------------ drawing

    private fun say(t: String) {
        msgView.text = t
        log.add(t)
    }

    private fun renderScore() {
        val trumpText = if (g.trump in 0..3) suitName(g.trump) + " " + CardText.SUIT_SYMBOLS[g.trump] else "—"
        scoreView.text = "امتیاز: شما " + CardText.fa(g.sc[0]) + "، حریف " + CardText.fa(g.sc[1]) +
            " | دست‌ها: شما " + CardText.fa(g.tk[0]) + "، حریف " + CardText.fa(g.tk[1]) +
            " | حکم: " + trumpText
    }

    private fun femaleOf(p: Int): Boolean =
        if (p == 0) Prefs.gender(this) == "f" else BotNames.isFemale(oppName)

    private fun avatarFor(p: Int, pop: Boolean) {
        if (!::tableViews.isInitialized) return
        Avatars.apply(tableViews[p], if (p == 0) "شما" else oppName, femaleOf(p), board.get(p))
        if (pop) Anim.pop(tableViews[p])
    }

    private fun endMoods(team: Int) {
        for (p in 0 until 2) board.set(p, if (p == team) "joy" else "sad", 3500)
    }

    private fun renderTable() {
        for (p in 0 until 2) {
            val e = shown.firstOrNull { it.p == p }
            var t = who(p) + ": " + (if (e != null) CardText.cardName(e.c) else "—")
            if (e != null && p == shownWinner) t += " (برنده)"
            val before = tableViews[p].text.toString()
            tableViews[p].text = t
            CardArt.mark(tableViews[p], e?.c)
            avatarFor(p, false)
            if (e != null && before.endsWith("—")) Anim.pop(tableViews[p])
        }
    }

    private fun renderHand() {
        handGrid.removeAllViews()
        val legal: List<Card> = if (stage == Stage.PLAY && !busy) g.legal(0) else emptyList()
        val w = CardArt.cardWidth(this, 5)
        for (c in sortedHand()) {
            val sel = stage == Stage.DISCARD && selected.contains(c)
            val en = when (stage) {
                Stage.DISCARD -> !busy
                Stage.PLAY -> legal.contains(c)
                else -> false
            }
            handGrid.addView(CardArt.cardButton(this, c, w, en, sel) { onCardTapped(c) })
        }
        if (g.hands[0].size - lastHand >= 3) Anim.dealIn(handGrid)
        lastHand = g.hands[0].size
    }

    private fun renderAll() {
        renderScore()
        renderTable()
        renderHand()
        confirmBtn.visibility = if (stage == Stage.DISCARD && !busy) View.VISIBLE else View.GONE
        pickRow.visibility = if (stage == Stage.TRUMP) View.VISIBLE else View.GONE
        drawRow.visibility = if (stage == Stage.DRAW && !busy) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ round flow

    private fun startMatch() {
        gen++
        newGameBtn.visibility = View.GONE
        DuoSaveStore.clear(this)
        log.clear()
        oppName = BotNames.pick(1)[0]
        // the draw: dealing cards one by one, the first ace makes its owner the hakem
        val d = HakemDraw.generate(2)
        g.newMatch(d.h)
        shown = emptyList()
        shownWinner = -1
        lastWinner = -1
        busy = true
        skipBtn.visibility = View.VISIBLE
        val my = gen
        narrator.run(d, listOf("شما", oppName), !snd.willDeal(), { say(it) }) {
            skipBtn.visibility = View.GONE
            if (my == gen) {
                board.set(d.h, "joy", 3500)
                board.set(1 - d.h, "sad", 3500)
                startRound()
            }
        }
    }

    private fun startRound() {
        gen++
        busy = true
        stage = Stage.WAIT
        g.startRound()
        DuoSaveStore.saveRound(this, g)
        snd.sfx("shuffle")
        selected.clear()
        shown = emptyList()
        shownWinner = -1
        renderAll()
        say("کارت‌ها پخش می‌شود...")
        dealThen("deal2") { roundBegins() }
    }

    /** Plays a dealing sound (skippable), then runs [then]; at once when dealing sound is off. */
    private fun dealThen(name: String, then: () -> Unit) {
        if (!snd.willDeal()) {
            then()
            return
        }
        skipBtn.visibility = View.VISIBLE
        val my = gen
        snd.deal(name) {
            skipBtn.visibility = View.GONE
            if (my == gen) then()
        }
    }

    /** The five cards are dealt: the hakem now discards and names the trump. */
    private fun roundBegins() {
        if (g.hk == 0) {
            stage = Stage.DISCARD
            busy = false
            renderAll()
            say("شما حاکم هستید. پنج کارت شما: " + handText() + ". دو کارت را برای کنار گذاشتن انتخاب کنید.")
            return
        }
        say("حریف حاکم است و حکم را انتخاب می‌کند...")
        val my = gen
        try {
            pool.execute {
                val ch = try {
                    bot.choose2Hakem(g.hands[1], 1)
                } catch (e: Exception) {
                    Bot2.choose2Heur(g.hands[1])
                }
                ui.post { if (my == gen) botIsHakem(ch) }
            }
        } catch (e: Exception) {
            // activity is closing
        }
    }

    private fun botIsHakem(ch: Bot2.Choice) {
        g.trump = ch.trump
        g.botKeep(ch.keep)
        stage = Stage.DISCARD
        busy = false
        renderAll()
        say("حریف حاکم است، دو کارتش را کنار گذاشت و حکم را تعیین کرد: " + suitName(ch.trump) +
            ". پنج کارت شما: " + handText() + ". دو کارت را برای کنار گذاشتن انتخاب کنید.")
    }

    private fun onCardTapped(c: Card) {
        when (stage) {
            Stage.DISCARD -> {
                if (selected.contains(c)) selected.remove(c) else if (selected.size < 2) selected.add(c)
                renderHand()
            }
            Stage.PLAY -> {
                if (busy || g.phase != Phase2.PLAY || g.turn != 0) return
                if (!g.legal(0).contains(c)) return
                busy = true
                doPlay(0, c)
            }
            else -> {}
        }
    }

    private fun confirmDiscard() {
        if (stage != Stage.DISCARD || busy) return
        if (selected.size != 2) {
            say("باید دقیقاً دو کارت انتخاب کنید.")
            return
        }
        g.humanDiscard(ArrayList(selected))
        selected.clear()
        if (g.hk == 0) {
            stage = Stage.TRUMP
            renderAll()
            say("دو کارت کنار گذاشته شد. کارت‌های شما: " + handText() + ". حکم را انتخاب کنید.")
        } else {
            beginDraw("دو کارت کنار گذاشته شد. حکم " + suitName(g.trump) + " است. ")
        }
    }

    private fun pickTrump(t: Int) {
        if (stage != Stage.TRUMP) return
        g.trump = t
        g.botKeep(Bot2.keepThree(g.hands[1], t))
        beginDraw("حکم " + suitName(t) + " شد. ")
    }

    private fun beginDraw(prefix: String) {
        g.beginDraw()
        drawNext(prefix)
    }

    private fun drawNext(prefix: String) {
        if (!g.nextPair()) {
            g.startPlay()
            DuoSaveStore.saveFull(this, g)
            stage = Stage.PLAY
            busy = true
            renderAll()
            say(prefix + "کارت‌ها پخش شد. کارت‌های شما: " + handText() + ".")
            nextPlay(true)
            return
        }
        if (g.ch == 0) {
            stage = Stage.DRAW
            busy = false
            val up = g.up!!
            takeUpBtn.text = "کارت رو: " + CardText.cardName(up)
            takeUpBtn.contentDescription = "برداشتن کارت رو، " + CardText.cardName(up)
            takeDownBtn.text = "کارت پشت"
            CardArt.mark(takeUpBtn, up)
            CardArt.markBack(takeDownBtn)
            takeDownBtn.contentDescription = "برداشتن کارت پشت که دیده نمی‌شود"
            renderAll()
            say(prefix + "مرحله " + CardText.fa(g.step + 1) + " از ۲۰. کارت رو: " + CardText.cardName(up) +
                ". یکی را بردارید؛ دیگری دور ریخته می‌شود.")
            return
        }
        stage = Stage.DRAW
        busy = true
        renderAll()
        say(prefix + "حریف کارتش را انتخاب می‌کند...")
        val my = gen
        ui.postDelayed({
            if (my != gen) return@postDelayed
            try {
                pool.execute {
                    val face = try { bot.drawFace() } catch (e: Exception) { true }
                    ui.post {
                        if (my == gen) {
                            g.take(1, face)
                            drawNext("")
                        }
                    }
                }
            } catch (e: Exception) {
                // activity is closing
            }
        }, 500)
    }

    private fun humanTake(face: Boolean) {
        if (stage != Stage.DRAW || busy || g.ch != 0) return
        val got = if (face) g.up!! else g.dn!!
        busy = true
        g.take(0, face)
        drawNext("کارت گرفته‌شده: " + CardText.cardName(got) + ". ")
    }

    // ------------------------------------------------------------------ playing

    private fun nextPlay(afterDeal: Boolean = false) {
        if (g.phase != Phase2.PLAY) return
        if (g.turn == 0) {
            busy = false
            renderAll()
            val prefix = if (afterDeal) msgView.text.toString() + " " else ""
            say(prefix + "نوبت شماست. " +
                (if (g.trick.isEmpty()) "شما شروع می‌کنید." else "خال زمین: " + suitName(g.trick[0].c.s) + "."))
            for (i in 0 until handGrid.childCount) {
                val v = handGrid.getChildAt(i)
                if (v.isEnabled) {
                    v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    break
                }
            }
            return
        }
        busy = true
        renderAll()
        val my = gen
        ui.postDelayed({
            if (my != gen) return@postDelayed
            try {
                pool.execute {
                    val c = try {
                        bot.pickCard()
                    } catch (e: Exception) {
                        g.legal(1).random()
                    }
                    ui.post { if (my == gen && g.phase == Phase2.PLAY && g.turn == 1) doPlay(1, c) }
                }
            } catch (e: Exception) {
                // activity is closing
            }
        }, 700)
    }

    private fun doPlay(p: Int, c: Card) {
        val hkBefore = g.hk
        if (g.trick.isEmpty()) {
            shown = emptyList()
            shownWinner = -1
        }
        val res = g.play(p, c)
        snd.card()
        val rh = res.hand
        if (rh == null) DuoSaveStore.saveFull(this, g)
        else if (rh.gameOver) DuoSaveStore.clear(this)
        else DuoSaveStore.saveRound(this, g)
        val played = who(p) + " " + CardText.cardName(c) + (if (p == 0) " بازی کردید" else " بازی کرد") +
            (if (c.s == g.trump) " (حکم)." else ".")
        if (!res.trickDone) {
            shown = ArrayList(g.trick)
            renderAll()
            say(played)
            nextPlay()
            return
        }
        val w = res.winner
        lastWinner = w
        snd.sfx(if (w == 0) "trick" else "tlose")
        board.set(w, "happy", 1800)
        shown = g.lastTrick
        shownWinner = w
        val won = if (w == 0) "شما دست را بردید." else "حریف دست را برد."
        val trickMsg = played + " " + won + " دست‌ها: شما " + CardText.fa(g.tk[0]) + "، حریف " + CardText.fa(g.tk[1]) + "."
        renderAll()
        val hand = res.hand
        val my = gen
        if (hand != null) {
            say(trickMsg + " " + handMessage(hand, hkBefore))
            endSounds(hand)
            endMoods(hand.team)
            if (hand.gameOver) {
                newGameBtn.visibility = View.VISIBLE
            } else {
                ui.postDelayed({ if (my == gen) startRound() }, 4000)
            }
            return
        }
        say(trickMsg)
        ui.postDelayed({
            if (my != gen) return@postDelayed
            shown = emptyList()
            shownWinner = -1
            nextPlay()
        }, 1500)
    }

    private fun handMessage(h: Result2, hk: Int): String {
        val t = h.team
        val bn = if (t == hk) "بام" else "پر بام"
        if (h.bam) {
            return if (t == 0) "شما $bn کردید و بازی را بردید!" else "حریف $bn کرد و بازی را برد."
        }
        if (h.gameOver) {
            return if (t == 0) "شما بازی را بردید!" else "حریف بازی را برد."
        }
        val extra = if (h.kot) {
            if (t == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)"
        } else " (۱ امتیاز)"
        return (if (t == 0) "شما این دست را بردید" else "حریف این دست را برد") + extra + "."
    }

    // ------------------------------------------------------------------ reading aids

    /** The cards on the table now (or of the trick that just ended). */
    private fun readTable() {
        val dt = if (g.trick.isNotEmpty()) g.trick else shown
        say(
            if (dt.isNotEmpty()) "روی زمین: " + dt.joinToString("، ") { who(it.p) + " " + CardText.cardName(it.c) } + "."
            else "روی زمین کارتی نیست."
        )
    }

    private fun readLastTrick() {
        if (g.lastTrick.isEmpty()) {
            say("هنوز دستی بازی نشده.")
            return
        }
        say("دست قبل: " + g.lastTrick.joinToString("، ") { who(it.p) + " " + CardText.cardName(it.c) } +
            ". برنده: " + who(lastWinner) + ".")
    }

    private fun readStatus() {
        val sb = StringBuilder()
        if (g.trump in 0..3) sb.append("حکم: ").append(suitName(g.trump)).append(". ")
        sb.append("امتیاز: شما ").append(CardText.fa(g.sc[0])).append("، حریف ").append(CardText.fa(g.sc[1])).append(". ")
        sb.append("دست‌ها: شما ").append(CardText.fa(g.tk[0])).append("، حریف ").append(CardText.fa(g.tk[1])).append(". ")
        if (g.trick.isNotEmpty()) {
            sb.append("روی میز: ")
                .append(g.trick.joinToString("، ") { who(it.p) + " " + CardText.cardName(it.c) }).append(". ")
        }
        if (g.hands[0].isNotEmpty()) sb.append("کارت‌های شما: ").append(handText()).append(".")
        say(sb.toString())
    }

    override fun onBackPressed() {
        finish()
    }
}
