package com.example.hokm

import android.content.Context

/** Events arrive on background threads: type = conn / open / msg / drop / found / lost / err. */
typealias LinkEmit = (type: String, cid: Int, data: String) -> Unit

/** A way to connect phones: Nearby (Bluetooth), same Wi-Fi network, or Wi-Fi Direct. */
interface Link {
    fun startHost(maxClients: Int, roomId: String?, name: String?)
    fun stopHost()
    fun startScan()
    fun stopScan()
    fun connect(target: String?, name: String?)
    fun send(id: Int, msg: String?)
    fun drop(id: Int)
    fun closeAll()
    fun shutdown()
}

object Net {
    const val BT = "bt"
    const val LAN = "lan"
    const val DIRECT = "direct"

    fun create(ctx: Context, mode: String, emit: LinkEmit): Link {
        val app = ctx.applicationContext
        return when (mode) {
            LAN -> NetLink(app, false, emit)
            DIRECT -> NetLink(app, true, emit)
            else -> NearbyLink(app, emit)
        }
    }
}
