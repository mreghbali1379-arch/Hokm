package com.example.hokm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.Priority
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

/**
 * Four players on several phones, built from ordinary views. One phone hosts (it runs [MpHostEngine] and plays
 * for empty seats with robots), the others join. Screens: setup -> (host lobby | list of games -> guest lobby) -> table.
 * If a player leaves in the middle of a game a robot takes his seat; a new player can take a robot's seat later.
 */
class MpActivity : Activity() {

    companion object {
        private const val REQ_PERM = 21
        private const val REQ_BT = 22
        private const val REQ_WIFI = 23
        private const val REQ_LOC = 24

        /** True while a multi-phone game is open (even when the player went to the main menu). */
        @Volatile var active = false
        private var instance: MpActivity? = null

        /** Closes the running multi-phone game (its connection and table); used by the main menu. */
        fun closeCurrent() {
            val i = instance
            instance = null
            active = false
            if (i != null) {
                i.teardown()
                i.finish()
            }
        }

        /** Closes a running multi-phone game (before a new one is created). */
        fun closeSession() {
            val i = instance
            instance = null
            active = false
            if (i != null) {
                i.teardown()
                i.finish()
            }
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var snd: Sound

    private var mode = Net.BT
    private var myName = "بازیکن"
    private var link: Link? = null
    private var engine: TableEngine? = null
    private var role = 0 // 0 = none, 1 = host, 2 = guest
    private var gameN = 4 // number of players at the table: 2 or 4
    private var table2: Mp2Screen? = null
    private var handoffSeat = -1
    private val seatOfLink = HashMap<Int, Int>()
    private val linkOfSeat = HashMap<Int, Int>()
    private val found = LinkedHashMap<String, Array<String>>() // target -> [room, host name]
    private var inGame = false
    private var guestSeat = 0
    private var mySeat = 0 // the host's own seat (0 at first; another seat after a host change)
    private var room = ""
    private val pendingConn = HashMap<Int, String>()
    private val waitingSeats = HashSet<Int>() // seats of players expected to reconnect to a new host
    private val waiting = LinkedHashMap<Int, String>() // connected players without a seat: link id -> name

    // backup of the table kept by guests, and the state of reconnecting after the host left
    private var snapStr: String? = null
    private var snapRoom = ""
    private var snapHostSeat = 0
    private var rejoining = false
    private var rejoinAttempts = 0
    private var rejoinElected = false

    // the table screen
    private var lastState: JSONObject? = null
    private var localBusy = false
    private lateinit var scoreView: TextView
    private lateinit var msgView: TextView
    private lateinit var tableViews: Array<TextView>
    private lateinit var handGrid: GridLayout
    private lateinit var pickRow: LinearLayout
    private lateinit var restartBtn: Button
    private lateinit var log: GameLog

    // other screens
    private var statusView: TextView? = null
    private var nameEdit: EditText? = null
    private var seatViews: Array<TextView>? = null
    private var startBtn: Button? = null
    private var listBox: LinearLayout? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ small view helpers

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun label(size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(Color.WHITE)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun button(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { action() }
        return b
    }

    private fun newCol(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        return col
    }

    private fun setScreen(col: LinearLayout) {
        val sv = ScrollView(this)
        sv.background = CardArt.background(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun heading(col: LinearLayout, text: String) {
        val t = label(26f, true)
        t.text = text
        t.setPadding(0, 0, 0, dp(12))
        if (Build.VERSION.SDK_INT >= 28) t.isAccessibilityHeading = true
        col.addView(t, matchWrap())
    }

    private fun status(col: LinearLayout): TextView {
        val t = label(17f, false)
        t.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        t.setBackgroundColor(0x33000000)
        t.setPadding(dp(8), dp(8), dp(8), dp(8))
        col.addView(t, matchWrap().also { it.topMargin = dp(8) })
        statusView = t
        return t
    }

    private fun setStatus(s: String) {
        statusView?.text = s
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        snd = Sound.get(this)
        instance = this
        try {
            val bm = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?
            @Suppress("MissingPermission")
            val n = bm?.adapter?.name
            if (!n.isNullOrEmpty()) myName = n
        } catch (e: Exception) {
        }
        myName = Prefs.name(this)
        mode = Prefs.net(this)
        val slotId = intent.getLongExtra("slot", -1L)
        if (slotId >= 0L) resumeSlot(slotId) else showSetup()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
            active = false
        }
        teardown()
        snd.release()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (role != 0) toMenu() else finish()
    }

    /** Goes to the main menu but keeps the game and the connection ("بازگشت به بازی" there comes back). */
    private fun toMenu() {
        if (role == 0) {
            finish()
            return
        }
        startActivity(Intent(this, MenuActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }

    /** Leaves the game for good. */
    private fun leaveGame() {
        SettingsUi.confirm(this, "از بازی خارج می‌شوید؟ اتصال شما قطع می‌شود.") {
            teardown()
            finish()
        }
    }

    /** Shows a sentence in the message area of whichever table is on screen. */
    private fun note(t: String) {
        if (gameN == 2) table2?.say(t) else if (inGame) msgView.text = t
    }

    /** Closes the connection and the table (if any). */
    private fun teardown() {
        engine?.stop()
        engine = null
        link?.shutdown()
        link = null
        role = 0
        active = false
        gameN = 4
        table2 = null
        handoffSeat = -1
        inGame = false
        lastState = null
        seatOfLink.clear()
        linkOfSeat.clear()
        found.clear()
        pendingConn.clear()
        waitingSeats.clear()
        waiting.clear()
        snapStr = null
        rejoining = false
        mySeat = 0
        ui.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ permissions and switches

    private var afterReady: (() -> Unit)? = null

    private fun ensureReady(then: () -> Unit) {
        afterReady = then
        stepPerm()
    }

    private fun readyDone() {
        val f = afterReady
        afterReady = null
        f?.invoke()
    }

    private fun readyFail(msg: String) {
        afterReady = null
        setStatus(msg)
    }

    private fun neededPerms(): Array<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        l.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        return l.toTypedArray()
    }

    private fun granted(p: String): Boolean = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun hasPerm(): Boolean {
        for (p in neededPerms()) {
            if (p == Manifest.permission.ACCESS_COARSE_LOCATION || p == Manifest.permission.ACCESS_FINE_LOCATION) continue
            if (!granted(p)) return false
        }
        return granted(Manifest.permission.ACCESS_COARSE_LOCATION) || granted(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun wifiOn(): Boolean = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager?
        wm == null || wm.isWifiEnabled
    } catch (e: Exception) {
        true
    }

    private fun locOn(): Boolean = try {
        val lm = (getSystemService(Context.LOCATION_SERVICE) as LocationManager?)
        if (lm == null) true
        else if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    } catch (e: Exception) {
        true
    }

    private fun needsLocation(): Boolean = mode != Net.LAN

    private fun stepPerm() {
        if (hasPerm()) stepBluetooth() else requestPermissions(neededPerms(), REQ_PERM)
    }

    private fun stepBluetooth() {
        if (mode != Net.BT) {
            stepWifi()
            return
        }
        val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?)?.adapter
        if (ad == null) {
            readyFail("این گوشی بلوتوث ندارد؛ از وای‌فای استفاده کنید.")
            return
        }
        try {
            if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) != ConnectionResult.SUCCESS) {
                readyFail("سرویس‌های گوگل‌پلی روی این گوشی در دسترس نیست؛ از وای‌فای استفاده کنید.")
                return
            }
        } catch (e: Exception) {
            readyFail("سرویس‌های گوگل‌پلی روی این گوشی در دسترس نیست؛ از وای‌فای استفاده کنید.")
            return
        }
        if (ad.isEnabled) {
            stepWifi()
        } else {
            try {
                setStatus("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن بلوتوث را بدهید.")
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BT)
            } catch (e: Exception) {
                readyFail("روشن کردن خودکار بلوتوث ممکن نشد. آن را از تنظیمات گوشی روشن کنید.")
            }
        }
    }

    private fun stepWifi() {
        if (mode != Net.BT && !wifiOn()) {
            try {
                val action = if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(action), REQ_WIFI)
            } catch (e: Exception) {
                readyFail("روشن کردن وای‌فای ممکن نشد. آن را از تنظیمات گوشی روشن کنید.")
            }
            return
        }
        stepLocation()
    }

    private fun stepLocation() {
        if (!needsLocation() || locOn()) {
            readyDone()
            return
        }
        try {
            val lr = LocationRequest.Builder(Priority.PRIORITY_LOW_POWER, 10000L).build()
            val req = LocationSettingsRequest.Builder().addLocationRequest(lr).build()
            LocationServices.getSettingsClient(this).checkLocationSettings(req)
                .addOnSuccessListener { readyDone() }
                .addOnFailureListener { e ->
                    if (e is ResolvableApiException) {
                        try {
                            setStatus("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن موقعیت مکانی را بدهید.")
                            e.startResolutionForResult(this@MpActivity, REQ_LOC)
                        } catch (x: Exception) {
                            readyFail("موقعیت مکانی را از تنظیمات گوشی روشن کنید.")
                        }
                    } else {
                        readyFail("موقعیت مکانی را از تنظیمات گوشی روشن کنید.")
                    }
                }
        } catch (t: Throwable) {
            readyFail("موقعیت مکانی را از تنظیمات گوشی روشن کنید.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM) return
        if (hasPerm()) {
            stepBluetooth()
            return
        }
        readyFail("اجازه‌ها لازم است. از تنظیمات برنامه، اجازهٔ بلوتوث، دستگاه‌های نزدیک و موقعیت مکانی را بدهید و دوباره امتحان کنید.")
        var blocked = false
        for (i in permissions.indices) {
            if (i < grantResults.size && grantResults[i] != PackageManager.PERMISSION_GRANTED &&
                !shouldShowRequestPermissionRationale(permissions[i])
            ) blocked = true
        }
        if (blocked) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            } catch (e: Exception) {
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BT -> if (resultCode == RESULT_OK) stepWifi() else readyFail("بلوتوث روشن نشد.")
            REQ_WIFI -> if (wifiOn()) stepLocation() else readyFail("وای‌فای روشن نشد.")
            REQ_LOC -> if (!needsLocation() || locOn()) readyDone() else readyFail("موقعیت مکانی روشن نشد.")
        }
    }

    // ------------------------------------------------------------------ screens: setup

    private fun showSetup() {
        teardown()
        val col = newCol()
        heading(col, "بازی چندنفره")

        val ne = EditText(this)
        ne.hint = "نام شما"
        ne.setText(myName)
        ne.setTextColor(Color.WHITE)
        ne.setHintTextColor(0x99FFFFFF.toInt())
        ne.inputType = InputType.TYPE_CLASS_TEXT
        ne.filters = arrayOf(InputFilter.LengthFilter(20))
        ne.contentDescription = "نام شما"
        col.addView(ne, matchWrap())
        nameEdit = ne

        val gl = label(16f, false)
        gl.text = "جنسیت شما (برای آدمکی که سر میز برای شما می‌نشیند):"
        gl.setPadding(0, dp(8), 0, 0)
        col.addView(gl, matchWrap())
        val gg = RadioGroup(this)
        gg.orientation = RadioGroup.HORIZONTAL
        val gf = RadioButton(this)
        gf.id = 111
        gf.text = "زن"
        gf.setTextColor(Color.WHITE)
        val gm = RadioButton(this)
        gm.id = 112
        gm.text = "مرد"
        gm.setTextColor(Color.WHITE)
        gg.addView(gf)
        gg.addView(gm)
        if (Prefs.gender(this) == "m") gm.isChecked = true else gf.isChecked = true
        gg.setOnCheckedChangeListener { _, id -> Prefs.setGender(this, if (id == 112) "m" else "f") }
        col.addView(gg, matchWrap())

        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.VERTICAL
        fun radio(id: Int, text: String): RadioButton {
            val r = RadioButton(this)
            r.id = id
            r.text = text
            r.setTextColor(Color.WHITE)
            rg.addView(r)
            return r
        }
        val rb = radio(101, "بلوتوث (نزدیک، پیشنهادی)")
        val rl = radio(102, "وای‌فای مشترک (روتر یا هات‌اسپات)")
        val rd = radio(103, "وای‌فای مستقیم")
        when (mode) {
            Net.LAN -> rl.isChecked = true
            Net.DIRECT -> rd.isChecked = true
            else -> rb.isChecked = true
        }
        val hint = label(15f, false)
        fun hintText(): String = when (mode) {
            Net.LAN -> "همه‌ی گوشی‌ها باید به یک شبکه‌ی وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها. بعد میزبان بازی را باز می‌کند و بقیه نامش را در فهرست می‌بینند."
            Net.DIRECT -> "وای‌فای همه‌ی گوشی‌ها باید روشن و گوشی‌ها نزدیک هم باشند. لازم نیست به مودم یا شبکه‌ای وصل شوید؛ بقیه مستقیم به گوشی میزبان وصل می‌شوند."
            else -> "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن در تنظیمات بلوتوث نیست."
        }
        hint.text = hintText()
        rg.setOnCheckedChangeListener { _, id ->
            mode = when (id) {
                102 -> Net.LAN
                103 -> Net.DIRECT
                else -> Net.BT
            }
            Prefs.setNet(this, mode)
            hint.text = hintText()
        }
        col.addView(rg, matchWrap().also { it.topMargin = dp(8) })
        col.addView(hint, matchWrap())

        col.addView(button("میزبان بازی می‌شوم") {
            readName()
            ensureReady { startHosting() }
        }, matchWrap().also { it.topMargin = dp(12) })
        col.addView(button("به بازی دیگری می‌پیوندم") {
            readName()
            ensureReady { startJoining() }
        }, matchWrap().also { it.topMargin = dp(8) })
        col.addView(button("بازی‌های قبلی") { PreviousGames.show(this) }, matchWrap().also { it.topMargin = dp(8) })
        col.addView(button("منو") { finish() }, matchWrap().also { it.topMargin = dp(8) })

        status(col)
        setStatus("روش اتصال را انتخاب کنید. همهٔ بازیکنان باید از یک روش استفاده کنند.")
        setScreen(col)
    }

    private fun readName() {
        val n = nameEdit?.text?.toString()?.trim() ?: ""
        myName = if (n.isEmpty()) "بازیکن" else n
        Prefs.setName(this, myName)
    }

    // ------------------------------------------------------------------ host

    private fun makeLink(): Link = Net.create(this, mode) { t, c, d -> ui.post { onLinkEvent(t, c, d) } }

    private fun startHosting() {
        val l = makeLink()
        link = l
        role = 1
        active = true
        mySeat = 0
        room = (1000 + Random.nextInt(9000)).toString()
        val eng = newEngine()
        engine = eng
        eng.seatJoin(mySeat, myName)
        l.startHost(eng.seats - 1, room, myName)
        showHostLobby()
    }

    /** Switches the table being hosted between two and four players and opens a fresh lobby. */
    private fun setGameN(n: Int) {
        if (n == gameN) return
        engine?.stop()
        engine = null
        link?.shutdown()
        link = null
        seatOfLink.clear()
        linkOfSeat.clear()
        pendingConn.clear()
        waiting.clear()
        gameN = n
        startHosting()
    }

    /** Seat arrangement is not available yet: tell the player instead of failing. */
    private fun arrangeAsk() {
        setStatus("چینش بازیکن‌ها هنوز در این نسخه فعال نیست.")
    }

    private fun newEngine(): TableEngine =
        if (gameN == 2) MpHostEngine2(ui, { seat, json -> deliverTo(seat, json) }, { sendSnaps() })
        else MpHostEngine(ui, { seat, json -> deliverTo(seat, json) }, { sendSnaps() })

    /** Gives every guest a fresh backup copy of the table, so one of them can take over if this phone leaves. */
    private fun sendSnaps() {
        val e = engine ?: return
        if (!e.started || seatOfLink.isEmpty()) return
        val msg = JSONObject().put("t", "snap").put("s", e.snapshot()).put("room", room).put("hostSeat", mySeat).toString()
        for (id in seatOfLink.keys) link?.send(id, msg)
    }

    private fun deliverTo(seat: Int, json: String) {
        if (seat == mySeat) {
            try {
                onGameMessage(JSONObject(json))
            } catch (e: Exception) {
            }
        } else {
            val id = linkOfSeat[seat] ?: return
            link?.send(id, json)
        }
    }

    private fun showHostLobby() {
        val col = newCol()
        heading(col, "میزبان بازی")
        val info = label(16f, false)
        info.text = "بازیکن‌های نزدیک می‌توانند به بازی شما بپیوندند. هر صندلی خالی را یک ربات پر می‌کند. هر وقت آماده بودید بازی را شروع کنید؛ بعد از شروع هم کسی می‌تواند جای یک ربات بنشیند."
        col.addView(info, matchWrap())
        val views = Array(gameN) { label(18f, false) }
        for (v in views) {
            v.setPadding(0, dp(6), 0, dp(6))
            col.addView(v, matchWrap())
        }
        seatViews = views
        col.addView(button("نوع بازی: " + (if (gameN == 2) "دو نفره" else "چهار نفره") + " (برای تغییر بزنید)") {
            setGameN(if (gameN == 2) 4 else 2)
        }, matchWrap().also { it.topMargin = dp(8) })
        if (gameN == 4) {
            col.addView(button("چینش بازیکن‌ها") { arrangeAsk() }, matchWrap().also { it.topMargin = dp(8) })
        }
        val sb = button("شروع بازی") {
            val e = engine
            if (e != null) {
                var others = 0
                for (s in 0 until e.seats) if (e.human[s] && s != mySeat) others++
                if (others == 0) {
                    setStatus(
                        if (gameN == 2) "برای بازی دو نفره باید یک بازیکن بپیوندد."
                        else "برای بازی چهار نفره باید دست‌کم یک بازیکن بپیوندد."
                    )
                } else {
                    e.start()
                }
            }
        }
        col.addView(sb, matchWrap().also { it.topMargin = dp(12) })
        startBtn = sb
        col.addView(button("لغو") { showSetup() }, matchWrap().also { it.topMargin = dp(8) })
        status(col)
        setStatus("منتظر بازیکن‌ها...")
        setScreen(col)
        refreshLobby()
    }

    private fun lobbyNames(): List<String> {
        val e = engine ?: return emptyList()
        return (0 until e.seats).map { s -> if (e.human[s]) e.displayName(s) else "" }
    }

    private fun refreshLobby() {
        val e = engine ?: return
        val views = seatViews ?: return
        for (s in 0 until minOf(e.seats, views.size)) {
            views[s].text = "صندلی " + CardText.fa(s + 1) + ": " +
                (if (e.human[s]) e.displayName(s) + (if (s == mySeat) " (میزبان)" else "") else "ربات")
        }
    }

    private fun broadcastLobby() {
        val e = engine ?: return
        refreshLobby()
        val names = JSONArray()
        for (s in 0 until e.seats) names.put(if (e.human[s]) e.displayName(s) else "")
        for ((id, seat) in seatOfLink) {
            val o = JSONObject().put("t", "lobby").put("seat", seat).put("names", names).put("n", e.seats)
            link?.send(id, o.toString())
        }
    }

    private fun onHostEvent(type: String, cid: Int, data: String) {
        val e = engine ?: return
        val l = link ?: return
        when (type) {
            "conn" -> {
                // the player's seat is chosen when his "hello" arrives
                pendingConn[cid] = data.substringBefore('\u0001').trim()
            }
            "msg" -> {
                val o = try { JSONObject(data) } catch (x: Exception) { return }
                val seat = seatOfLink[cid]
                if (seat == null) {
                    if (o.optString("t") == "hello") handleHello(cid, o)
                    return
                }
                e.action(seat, o)
            }
            "drop" -> {
                pendingConn.remove(cid)
                waiting.remove(cid)
                val seat = seatOfLink.remove(cid) ?: return
                linkOfSeat.remove(seat)
                val nm = e.displayName(seat)
                e.seatLeave(seat)
                if (!e.started) {
                    broadcastLobby()
                    setStatus("$nm از بازی رفت.")
                }
            }
            "err" -> setStatus(data)
        }
    }

    /** A phone that connected says who it is and which seat it wants (-1 = any free one). */
    private fun handleHello(cid: Int, o: JSONObject) {
        val e = engine ?: return
        val l = link ?: return
        var name = o.optString("name").trim()
        if (name.isEmpty()) name = pendingConn[cid] ?: ""
        if (name.isEmpty()) name = "بازیکن"
        pendingConn.remove(cid)
        val req = o.optInt("seat", -1)
        fun free(s: Int) = s != mySeat && linkOfSeat[s] == null
        var seat = -1
        if (req in 0 until e.seats && free(req) && (waitingSeats.contains(req) || !e.human[req])) {
            seat = req
        } else {
            for (x in 0 until e.seats) {
                if (free(x) && !e.human[x] && !waitingSeats.contains(x)) {
                    seat = x
                    break
                }
            }
        }
        if (seat < 0 || (e.started && req < 0)) {
            // no free seat, or the game is already running: stay connected and wait until the host adds this player
            waiting[cid] = name
            l.send(
                cid,
                JSONObject().put("t", "wait").put(
                    "msg",
                    if (e.started) "بازی شروع شده است. وصل می‌مانید تا میزبان شما را به بازی اضافه کند."
                    else "جای خالی برای شما نیست. وصل می‌مانید تا جایی خالی شود یا میزبان شما را اضافه کند."
                ).toString()
            )
            setStatus("$name وصل شد و منتظر است.")
            return
        }
        waitingSeats.remove(seat)
        seatOfLink[cid] = seat
        linkOfSeat[seat] = cid
        l.send(cid, JSONObject().put("t", "seat").put("seat", seat).toString())
        e.seatJoin(seat, name)
        if (!e.started) {
            broadcastLobby()
            setStatus(e.displayName(seat) + " به بازی پیوست.")
        }
    }

    // ------------------------------------------------------------------ guest

    private fun startJoining() {
        val l = makeLink()
        link = l
        role = 2
        active = true
        found.clear()
        l.startScan()
        showJoinList()
    }

    private fun showJoinList() {
        val col = newCol()
        heading(col, "پیوستن به بازی")
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        col.addView(box, matchWrap())
        listBox = box
        col.addView(button("برگشت") { showSetup() }, matchWrap().also { it.topMargin = dp(12) })
        status(col)
        setStatus("در حال جست‌وجوی بازی‌های نزدیک...")
        setScreen(col)
        refreshFound()
    }

    private fun refreshFound() {
        val box = listBox ?: return
        box.removeAllViews()
        for ((target, info) in found) {
            val host = if (info[1].isEmpty()) "میزبان" else info[1]
            val b = button("بازی " + host + " (کد " + info[0] + ")") {
                setStatus("در حال اتصال به $host ...")
                link?.stopScan()
                link?.connect(target, myName)
            }
            box.addView(b, matchWrap().also { it.topMargin = dp(6) })
        }
        if (found.isNotEmpty()) setStatus(CardText.fa(found.size) + " بازی پیدا شد. یکی را انتخاب کنید.")
    }

    private fun showGuestLobby(names: List<String>) {
        val col = newCol()
        heading(col, "منتظر شروع بازی")
        for (s in 0 until maxOf(names.size, 2)) {
            val v = label(18f, false)
            v.setPadding(0, dp(6), 0, dp(6))
            val n = if (s < names.size) names[s] else ""
            v.text = "صندلی " + CardText.fa(s + 1) + ": " + (if (n.isEmpty()) "ربات" else n) + (if (s == guestSeat) " (شما)" else "")
            col.addView(v, matchWrap())
        }
        col.addView(button("خروج") { showSetup() }, matchWrap().also { it.topMargin = dp(12) })
        status(col)
        setStatus("به بازی پیوستید. منتظر شروع میزبان باشید.")
        setScreen(col)
    }

    private fun onGuestEvent(type: String, data: String) {
        when (type) {
            "found" -> {
                val p = data.split('\u0001')
                if (p.isNotEmpty()) {
                    found[p[0]] = arrayOf(if (p.size > 1) p[1] else "", if (p.size > 2) p[2] else "")
                    if (!inGame) refreshFound()
                }
            }
            "lost" -> {
                found.remove(data)
                if (!inGame) refreshFound()
            }
            "open" -> {
                val again = rejoining
                rejoining = false
                setStatus("وصل شد. منتظر میزبان...")
                link?.send(0, JSONObject().put("t", "hello").put("name", myName).put("seat", if (again) guestSeat else -1).toString())
            }
            "msg" -> {
                val o = try { JSONObject(data) } catch (e: Exception) { return }
                when (o.optString("t")) {
                    "seat" -> guestSeat = o.optInt("seat", 0)
                    "lobby" -> if (!inGame) {
                        gameN = o.optInt("n", gameN)
                        val a = o.optJSONArray("names")
                        val names = ArrayList<String>()
                        if (a != null) for (i in 0 until a.length()) names.add(a.optString(i))
                        guestSeat = o.optInt("seat", guestSeat)
                        showGuestLobby(names)
                    }
                    "state" -> onGameMessage(o)
                    "snap" -> {
                        snapStr = o.optString("s")
                        snapRoom = o.optString("room")
                        snapHostSeat = o.optInt("hostSeat")
                    }
                    "full" -> {
                        showSetup()
                        setStatus("این بازی پر است.")
                    }
                    "kicked" -> {
                        showSetup()
                        setStatus("میزبان شما را از بازی حذف کرد.")
                    }
                    "wait" -> showWaiting(o.optString("msg"))
                    "handoff" -> {
                        // the host gives the table to another player: that one takes over, the rest reconnect
                        snapStr = o.optString("s")
                        snapRoom = o.optString("room")
                        snapHostSeat = o.optInt("hostSeat")
                        handoffSeat = o.optInt("seat", -1)
                        gameN = o.optInt("n", gameN)
                        note("میزبان بازی را به بازیکن دیگری می‌دهد...")
                    }
                }
            }
            "drop" -> {
                if (rejoining) return
                val sn = snapStr
                if (inGame && sn != null && sn.isNotEmpty()) startMigration() else {
                    showSetup()
                    setStatus("ارتباط با میزبان قطع شد.")
                }
            }
            "err" -> if (rejoining) rejoinFailed() else setStatus(data)
        }
    }

    // ------------------------------------------------------------------ host change and coming back

    private fun leaveWith(msg: String) {
        showSetup()
        setStatus(msg)
    }

    private fun migrationCandidates(): List<Int> {
        val s = snapStr ?: return emptyList()
        return try {
            val hm = JSONObject(s).getJSONArray("human")
            (0 until gameN).filter { hm.optBoolean(it) && it != snapHostSeat }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** The host is gone. The player with the lowest seat among the rest becomes the new host (after trying once to reach the old one). */
    private fun startMigration() {
        val cand = migrationCandidates()
        if (!cand.contains(guestSeat)) {
            leaveWith("ارتباط با میزبان قطع شد.")
            return
        }
        rejoinElected = cand.minOrNull() == guestSeat
        if (handoffSeat >= 0) {
            // a planned change: the chosen player takes over at once
            rejoinElected = handoffSeat == guestSeat
            if (rejoinElected) {
                handoffSeat = -1
                becomeHost()
                return
            }
        }
        rejoining = true
        rejoinAttempts = 0
        localBusy = true
        if (gameN != 2 && inGame) {
            for (i in 0 until handGrid.childCount) handGrid.getChildAt(i).isEnabled = false
            pickRow.visibility = View.GONE
        }
        note("ارتباط با میزبان قطع شد. در حال پیدا کردن میزبان...")
        attemptRejoin()
    }

    private fun attemptRejoin() {
        link?.connect("room:$snapRoom", myName)
    }

    private fun rejoinFailed() {
        rejoinAttempts++
        if (rejoinElected && rejoinAttempts >= 1) {
            becomeHost()
            return
        }
        if (rejoinAttempts >= 8) {
            leaveWith("میزبان پیدا نشد.")
            return
        }
        note("هنوز میزبان پیدا نشد. دوباره تلاش می‌کنم...")
        ui.postDelayed({ if (rejoining && role == 2) attemptRejoin() }, 3000)
    }

    /** This phone continues the game as the host, from the last backup copy. */
    private fun becomeHost() {
        rejoining = false
        val sn = snapStr
        if (sn == null) {
            leaveWith("بازی بازیابی نشد.")
            return
        }
        link?.shutdown()
        val l = makeLink()
        link = l
        role = 1
        active = true
        handoffSeat = -1
        mySeat = guestSeat
        room = snapRoom
        seatOfLink.clear()
        linkOfSeat.clear()
        pendingConn.clear()
        val eng = newEngine()
        engine = eng
        if (!eng.restore(sn)) {
            leaveWith("بازی بازیابی نشد.")
            return
        }
        eng.human[snapHostSeat] = false
        eng.names[snapHostSeat] = ""
        eng.human[mySeat] = true
        eng.names[mySeat] = myName
        mySeat = eng.reseatHost(mySeat)
        waitingSeats.clear()
        for (x in 0 until eng.seats) if (eng.human[x] && x != mySeat) waitingSeats.add(x)
        l.startHost(eng.seats - 1, room, myName)
        localBusy = false
        eng.resume("میزبان قبلی رفت. شما میزبان جدید هستید و بقیه دوباره وصل می‌شوند.")
        // players who do not come back within 15 seconds are replaced by robots
        ui.postDelayed({
            val e2 = engine
            if (e2 != null) {
                for (x in waitingSeats.toList()) {
                    if (linkOfSeat[x] == null) {
                        waitingSeats.remove(x)
                        e2.seatLeave(x)
                    }
                }
            }
        }, 15000)
    }

    private fun onLinkEvent(type: String, cid: Int, data: String) {
        if (link == null) return
        if (role == 1) onHostEvent(type, cid, data) else if (role == 2) onGuestEvent(type, data)
    }

    // ------------------------------------------------------------------ the table

    private fun build2() {
        val t = Mp2Screen(this, snd, { o -> sendAction(o) }, { showOptions() }, { toMenu() }, { engine?.start() }, { role == 1 })
        table2 = t
        setScreen(t.col)
    }

    private fun buildTable() {
        if (gameN == 2) {
            build2()
            return
        }
        val col = newCol()
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        scoreView = label(16f, true)
        col.addView(scoreView, matchWrap())

        msgView = label(18f, false)
        msgView.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        msgView.setBackgroundColor(0x33000000)
        msgView.setPadding(dp(8), dp(8), dp(8), dp(8))
        col.addView(msgView, matchWrap().also { it.topMargin = dp(8) })

        val table = LinearLayout(this)
        table.orientation = LinearLayout.VERTICAL
        table.setPadding(dp(8), dp(8), dp(8), dp(8))
        table.setBackgroundColor(0x22FFFFFF)
        tableViews = Array(4) { label(17f, false) }
        for (t in tableViews) table.addView(t, matchWrap())
        col.addView(table, matchWrap().also { it.topMargin = dp(8) })

        pickRow = LinearLayout(this)
        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.visibility = View.GONE
        for (t in 0 until 4) {
            val b = Button(this)
            b.isAllCaps = false
            b.text = CardText.SUIT_NAMES[t] + " " + CardText.SUIT_SYMBOLS[t]
            b.contentDescription = "حکم " + CardText.SUIT_NAMES[t]
            b.setTextColor(if (t == 1 || t == 2) Color.RED else Color.BLACK)
            b.setOnClickListener { sendAction(JSONObject().put("t", "trump").put("s", t)) }
            pickRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(pickRow, matchWrap().also { it.topMargin = dp(8) })

        handGrid = GridLayout(this)
        handGrid.columnCount = 5
        col.addView(handGrid, matchWrap().also { it.topMargin = dp(8) })

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        fun tool(text: String, action: () -> Unit) =
            tools.addView(button(text, action), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tool("دست قبل") { readLastTrick() }
        tool("وضعیت") { readStatus() }
        tool("گزینه‌ها") { showOptions() }
        tool("منو") { toMenu() }
        col.addView(tools, matchWrap().also { it.topMargin = dp(12) })
        col.addView(button("کارت‌های بازی‌شده در این دست") { readTable() }, matchWrap().also { it.topMargin = dp(4) })

        restartBtn = button("بازی جدید") { engine?.start() }
        restartBtn.visibility = View.GONE
        col.addView(restartBtn, matchWrap().also { it.topMargin = dp(8) })

        log = GameLog(this)
        col.addView(log.view, matchWrap().also { it.topMargin = dp(16) })

        setScreen(col)
    }

    private fun sendAction(o: JSONObject) {
        if (role == 1) {
            engine?.action(mySeat, o)
        } else if (role == 2) {
            link?.send(0, o.toString())
        }
    }

    private fun idsOf(a: JSONArray?): List<Int> {
        val l = ArrayList<Int>()
        if (a != null) for (i in 0 until a.length()) l.add(a.optInt(i))
        return l
    }

    private fun pairsOf(a: JSONArray?): List<IntArray> {
        val l = ArrayList<IntArray>()
        if (a != null) for (i in 0 until a.length()) {
            val p = a.optJSONArray(i) ?: continue
            l.add(intArrayOf(p.optInt(0), p.optInt(1)))
        }
        return l
    }

    private fun cardOf(id: Int) = Card(id / 20, id % 20)

    private fun onGameMessage(o: JSONObject) {
        if (!inGame) {
            gameN = o.optInt("n", 4)
            inGame = true
            buildTable()
        }
        lastState = o
        localBusy = false
        if (gameN == 2) table2?.update(o) else render(o)
    }

    private fun seatLabel(o: JSONObject, seat: Int): String {
        val me = o.optInt("seat")
        if (seat == me) return "شما"
        val names = o.optJSONArray("names")
        val n = names?.optString(seat) ?: ""
        return (if (n.isEmpty()) "صندلی " + CardText.fa(seat + 1) else n) + (if (seat % 2 == me % 2) " (یار)" else "")
    }

    private fun render(o: JSONObject) {
        val me = o.optInt("seat")
        val team = me % 2
        val sc = idsOf(o.optJSONArray("sc"))
        val tk = idsOf(o.optJSONArray("tk"))
        val trump = o.optInt("trump", -1)
        val trumpText = if (trump in 0..3) CardText.SUIT_NAMES[trump] + " " + CardText.SUIT_SYMBOLS[trump] else "—"
        if (sc.size == 2 && tk.size == 2) {
            scoreView.text = "امتیاز: شما " + CardText.fa(sc[team]) + "، حریف " + CardText.fa(sc[1 - team]) +
                " | دست‌ها: شما " + CardText.fa(tk[team]) + "، حریف " + CardText.fa(tk[1 - team]) + " | حکم: " + trumpText
        }
        val tb = pairsOf(o.optJSONArray("table"))
        val tw = o.optInt("tableWin", -1)
        for (rel in 0 until 4) {
            val seat = (me + rel) % 4
            val e = tb.firstOrNull { it[0] == seat }
            var t = seatLabel(o, seat) + ": " + (if (e != null) CardText.cardName(cardOf(e[1])) else "—")
            if (e != null && seat == tw) t += " (برنده)"
            tableViews[rel].text = t
            CardArt.mark(tableViews[rel], if (e != null) cardOf(e[1]) else null)
        }
        val legal = idsOf(o.optJSONArray("legal"))
        handGrid.removeAllViews()
        val cw = CardArt.cardWidth(this, 5)
        for (id in idsOf(o.optJSONArray("hand"))) {
            val c = cardOf(id)
            handGrid.addView(CardArt.cardButton(this, c, cw, !localBusy && legal.contains(id), false) {
                if (!localBusy) {
                    localBusy = true
                    for (i in 0 until handGrid.childCount) handGrid.getChildAt(i).isEnabled = false
                    sendAction(JSONObject().put("t", "play").put("id", id))
                }
            })
        }
        pickRow.visibility = if (o.optBoolean("canPick")) View.VISIBLE else View.GONE
        val over = o.optBoolean("over")
        restartBtn.visibility = if (over && role == 1) View.VISIBLE else View.GONE
        val say = o.optString("say")
        if (say.isNotEmpty()) {
            val full = if (over && role == 2) "$say منتظر میزبان برای بازی جدید باشید." else say
            msgView.text = full
            log.add(full)
        }
        val sfx = o.optJSONArray("sfx")
        if (sfx != null) for (i in 0 until sfx.length()) {
            val n = sfx.optString(i)
            if (n == "card") snd.card() else snd.sfx(n)
        }
        if (legal.isNotEmpty()) {
            for (i in 0 until handGrid.childCount) {
                val v = handGrid.getChildAt(i)
                if (v.isEnabled) {
                    v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    break
                }
            }
        }
    }

    // ------------------------------------------------------------------ options, kick, save, saved games

    private fun applyLook() {
        try {
            val t2 = table2
            if (gameN == 2 && t2 != null) {
                (t2.col.parent as? View)?.background = CardArt.background(this)
                SettingsUi.applyA11y(this, t2.msgView)
            } else if (inGame) {
                (msgView.parent?.parent as? View)?.background = CardArt.background(this)
                SettingsUi.applyA11y(this, msgView)
            }
        } catch (e: Exception) {
        }
    }

    private fun showOptions() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        val e = engine
        if (role == 1 && e != null) {
            items.add("بازی جدید" to {
                SettingsUi.confirm(this, "بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.") { engine?.start() }
            })
            items.add("افزودن بازیکن" to { addAsk() })
            items.add("حذف بازیکن" to { kickAsk() })
            items.add("انتقال میزبانی" to { handoffAsk() })
            items.add("ذخیره" to { saveGame() })
        }
        items.add("تغییر نام" to {
            SettingsUi.nameDialog(this, true) { myName = Prefs.name(this) }
        })
        items.add(SettingsUi.a11yLabel(this) to { SettingsUi.a11yToggle(this) { applyLook() } })
        items.add("سرعت انیمیشن" to { SettingsUi.animDialog(this) })
        items.add("سرعت پخش کارت‌ها" to { SettingsUi.speedDialog(this, snd) })
        items.add("تنظیمات صدا" to { SettingsUi.soundDialog(this, snd) })
        items.add("تنظیمات تصویر زمینه" to { SettingsUi.bgDialog(this) { applyLook() } })
        items.add("تنظیمات پشت کارت" to { SettingsUi.backDialog(this) { if (gameN == 2) table2?.redraw() else lastState?.let { render(it) } } })
        items.add("منوی اصلی (بازی می‌ماند)" to { toMenu() })
        items.add((if (role == 1) "خروج از بازی (میزبانی به دیگری می‌رسد)" else "خروج از بازی") to { if (role == 1) hostExit() else leaveGame() })
        SettingsUi.list(this, "گزینه‌های بیشتر", items, "بستن")
    }

    // ------------------------------------------------------------------ add a waiting player, hand over the table

    private fun freeRobotSeats(): List<Int> {
        val e = engine ?: return emptyList()
        return (0 until e.seats).filter { it != mySeat && !e.human[it] && linkOfSeat[it] == null }
    }

    /** Host only: a connected player who has no seat yet takes a robot's seat. */
    private fun addAsk() {
        val e = engine ?: return
        val seats = freeRobotSeats()
        if (seats.isEmpty()) {
            SettingsUi.toast(this, "جای خالی نیست. اگر بخواهید می‌توانید یکی را از بازی حذف کنید.")
            return
        }
        val ids = waiting.keys.toList()
        if (ids.isEmpty()) {
            SettingsUi.list(
                this, "بازیکن جدیدی وصل نیست. از او بخواهید «پیوستن به بازی» را بزند و گوشی میزبان را انتخاب کند؛ بعد «بررسی دوباره» را بزنید.",
                listOf("بررسی دوباره" to { addAsk() }), "بستن"
            )
            return
        }
        fun pickSeat(cid: Int) {
            if (seats.size == 1) {
                addPlayer(cid, seats[0])
                return
            }
            SettingsUi.list(
                this, "«" + (waiting[cid] ?: "") + "» جای کدام ربات بنشیند؟",
                seats.map { s -> e.displayName(s) to { addPlayer(cid, s) } }
            )
        }
        if (ids.size == 1) {
            pickSeat(ids[0])
            return
        }
        SettingsUi.list(this, "کدام بازیکن به بازی اضافه شود؟", ids.map { cid -> (waiting[cid] ?: "") to { pickSeat(cid) } })
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val e = engine ?: return
        val name = waiting.remove(cid) ?: return
        if (linkOfSeat[seat] != null || e.human[seat] || seat == mySeat) {
            waiting[cid] = name
            return
        }
        seatOfLink[cid] = seat
        linkOfSeat[seat] = cid
        link?.send(cid, JSONObject().put("t", "seat").put("seat", seat).toString())
        e.seatJoin(seat, name)
        if (!e.started) broadcastLobby()
        SettingsUi.toast(this, "$name به بازی اضافه شد.")
    }

    /** Host only: the table goes to another player; this phone then joins him as a player. */
    private fun handoffAsk() {
        val e = engine ?: return
        if (!e.started) {
            SettingsUi.toast(this, "هنوز بازی شروع نشده است.")
            return
        }
        val who = (0 until e.seats).filter { it != mySeat && e.human[it] && linkOfSeat[it] != null }
        if (who.isEmpty()) {
            SettingsUi.toast(this, "بازیکن دیگری در بازی نیست.")
            return
        }
        SettingsUi.list(
            this, "میزبانی به کدام بازیکن داده شود؟",
            who.map { s ->
                e.displayName(s) to {
                    SettingsUi.confirm(this, "«" + e.displayName(s) + "» میزبان شود؟ شما در بازی می‌مانید و به او وصل می‌شوید.") {
                        startHandoff(s, false)
                    }
                }
            }
        )
    }

    /** The host leaves: if somebody else is playing, the table goes to him; otherwise the game ends. */
    private fun hostExit() {
        val e = engine
        val target = if (e == null || !e.started) null
        else (0 until e.seats).filter { it != mySeat && e.human[it] && linkOfSeat[it] != null }.minOrNull()
        if (e == null || target == null) {
            leaveGame()
            return
        }
        SettingsUi.confirm(
            this,
            "مطمئنید؟ میزبانی به «" + e.displayName(target) + "» منتقل می‌شود و ربات جای شما بازی می‌کند."
        ) { startHandoff(target, true) }
    }

    private fun startHandoff(seat: Int, leave: Boolean) {
        val e = engine ?: return
        val old = mySeat
        val snap = e.snapshot()
        val msg = JSONObject().put("t", "handoff").put("s", snap).put("room", room).put("hostSeat", old)
            .put("seat", seat).put("n", gameN).toString()
        for (id in seatOfLink.keys) link?.send(id, msg)
        // give the messages time to leave, then stop hosting
        ui.postDelayed({
            if (role != 1) return@postDelayed
            e.stop()
            engine = null
            link?.shutdown()
            link = null
            seatOfLink.clear()
            linkOfSeat.clear()
            pendingConn.clear()
            waitingSeats.clear()
            waiting.clear()
            if (leave) {
                teardown()
                finish()
                return@postDelayed
            }
            // join the new host as an ordinary player, on the same seat
            val l = makeLink()
            link = l
            role = 2
            active = true
            guestSeat = old
            snapStr = snap
            snapRoom = room
            snapHostSeat = old
            handoffSeat = seat
            rejoinElected = false
            rejoining = true
            rejoinAttempts = 0
            localBusy = true
            note("میزبانی به بازیکن دیگری داده شد. در حال وصل شدن به او...")
            l.startScan()
            attemptRejoin()
        }, 1200)
    }

    /** Guest only: connected, but the host has not given this player a seat yet. */
    private fun showWaiting(msg: String) {
        inGame = false
        val col = newCol()
        heading(col, "منتظر بمانید")
        val t = label(17f, false)
        t.text = msg
        col.addView(t, matchWrap())
        col.addView(button("خروج") { showSetup() }, matchWrap().also { it.topMargin = dp(12) })
        status(col)
        setStatus(msg)
        setScreen(col)
    }

    /** Host only: choose a player to remove (a robot takes his seat). */
    private fun kickAsk() {
        val e = engine ?: return
        val who = (0 until e.seats).filter { it != mySeat && e.human[it] && linkOfSeat[it] != null }
        if (who.isEmpty()) {
            SettingsUi.toast(this, "بازیکن دیگری در بازی نیست.")
            return
        }
        SettingsUi.list(
            this, "کدام بازیکن از بازی حذف شود؟",
            who.map { s -> e.displayName(s) to { kickSeat(s) } }
        )
    }

    private fun kickSeat(seat: Int) {
        val e = engine ?: return
        val id = linkOfSeat[seat] ?: return
        link?.send(id, JSONObject().put("t", "kicked").toString())
        seatOfLink.remove(id)
        linkOfSeat.remove(seat)
        link?.drop(id)
        e.seatLeave(seat)
        if (!e.started) broadcastLobby()
    }

    /** Host only: keeps the whole table in "بازی‌های قبلی". Whoever opens it later becomes the host again. */
    private fun saveGame() {
        val e = engine ?: return
        if (!e.started) {
            SettingsUi.toast(this, "هنوز بازی شروع نشده است.")
            return
        }
        val st = lastState
        val sc = idsOf(st?.optJSONArray("sc"))
        val title = "بازی چندنفره" + if (sc.size == 2) "، امتیاز " + CardText.fa(sc[mySeat % 2]) + " به " + CardText.fa(sc[1 - mySeat % 2]) else ""
        val data = JSONObject().put("snap", e.snapshot()).put("room", room).put("seat", mySeat).put("n", e.seats).toString()
        Slots.add(this, "mp", title, data)
        SettingsUi.toast(this, "بازی ذخیره شد.")
    }

    /** A saved multi-phone game was chosen in "بازی‌های قبلی": host it again, the others join with the room code. */
    private fun resumeSlot(id: Long) {
        val sl = Slots.find(this, id)
        val o = try { JSONObject(sl?.data ?: "") } catch (e: Exception) { null }
        if (o == null) {
            showSetup()
            setStatus("این بازی ذخیره‌شده باز نشد.")
            return
        }
        mode = Prefs.net(this)
        showSetup()
        setStatus("در حال آماده‌سازی بازی ذخیره‌شده...")
        ensureReady { hostFromSave(o) }
    }

    private fun hostFromSave(o: JSONObject) {
        val l = makeLink()
        link = l
        role = 1
        gameN = if (o.optInt("n", 4) == 2) 2 else 4
        mySeat = o.optInt("seat", 0).coerceIn(0, gameN - 1)
        room = o.optString("room").ifEmpty { (1000 + Random.nextInt(9000)).toString() }
        val eng = newEngine()
        engine = eng
        if (!eng.restore(o.optString("snap"))) {
            leaveWith("این بازی ذخیره‌شده باز نشد.")
            return
        }
        for (x in 0 until eng.seats) {
            eng.human[x] = x == mySeat
            if (x != mySeat) eng.names[x] = ""
        }
        eng.names[mySeat] = myName
        waitingSeats.clear()
        l.startHost(3, room, myName)
        localBusy = false
        eng.resume("بازی ذخیره‌شده ادامه پیدا کرد. جای بقیه را ربات می‌گیرد تا بازیکن‌ها دوباره بپیوندند.")
    }

    // ------------------------------------------------------------------ reading aids and sound

    /** The cards on the table now (or of the trick that just ended). */
    private fun readTable() {
        val o = lastState ?: return
        var tb = pairsOf(o.optJSONArray("table"))
        if (tb.isEmpty()) tb = pairsOf(o.optJSONArray("last"))
        msgView.text = if (tb.isNotEmpty()) {
            "روی زمین: " + tb.joinToString("، ") { seatLabel(o, it[0]) + " " + CardText.cardName(cardOf(it[1])) } + "."
        } else "روی زمین کارتی نیست."
    }

    private fun readLastTrick() {
        val o = lastState ?: return
        val l = pairsOf(o.optJSONArray("last"))
        if (l.isEmpty()) {
            msgView.text = "هنوز دستی بازی نشده."
            return
        }
        msgView.text = "دست قبل: " + l.joinToString("، ") { seatLabel(o, it[0]) + " " + CardText.cardName(cardOf(it[1])) } +
            ". برنده: " + seatLabel(o, o.optInt("lastWin")) + "."
    }

    private fun readStatus() {
        val o = lastState ?: return
        val me = o.optInt("seat")
        val team = me % 2
        val sc = idsOf(o.optJSONArray("sc"))
        val tk = idsOf(o.optJSONArray("tk"))
        val sb = StringBuilder()
        val trump = o.optInt("trump", -1)
        if (trump in 0..3) sb.append("حکم: ").append(CardText.SUIT_NAMES[trump]).append(". ")
        if (sc.size == 2 && tk.size == 2) {
            sb.append("امتیاز: شما ").append(CardText.fa(sc[team])).append("، حریف ").append(CardText.fa(sc[1 - team])).append(". ")
            sb.append("دست‌ها: شما ").append(CardText.fa(tk[team])).append("، حریف ").append(CardText.fa(tk[1 - team])).append(". ")
        }
        val tb = pairsOf(o.optJSONArray("table"))
        if (tb.isNotEmpty()) {
            sb.append("روی میز: ").append(tb.joinToString("، ") { seatLabel(o, it[0]) + " " + CardText.cardName(cardOf(it[1])) }).append(". ")
        }
        val hand = idsOf(o.optJSONArray("hand"))
        if (hand.isNotEmpty()) sb.append("کارت‌های شما: ").append(hand.joinToString("، ") { CardText.cardName(cardOf(it)) }).append(".")
        msgView.text = sb.toString()
    }

    private fun showSoundDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))
        val on = CheckBox(this)
        on.text = "صدا و موسیقی"
        on.isChecked = snd.on
        on.setOnCheckedChangeListener { _, b -> snd.setOn(b) }
        box.addView(on)
        fun slider(title: String, value: Float, change: (Float) -> Unit) {
            val t = TextView(this)
            t.text = title
            t.setPadding(0, dp(12), 0, 0)
            box.addView(t)
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = Math.round(value * 100)
            sb.contentDescription = title
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) change(p / 100f)
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
            box.addView(sb)
        }
        slider("صدای آهنگ", snd.volMusic) { snd.setMusicVolume(it) }
        slider("صدای افکت‌ها", snd.volFx) { snd.setFxVolume(it) }
        AlertDialog.Builder(this).setTitle("صدا").setView(box).setPositiveButton("بستن", null).show()
    }
}
