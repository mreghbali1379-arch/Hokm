package com.example.hokm

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.widget.LinearLayout
import android.widget.TextView

/** The game report: everything that was announced, newest first, one entry per line so a screen reader can browse it. */
class GameLog(private val ctx: Context) {
    private val max = 80
    private var last = ""
    val view = LinearLayout(ctx)

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    init {
        view.orientation = LinearLayout.VERTICAL
        val head = TextView(ctx)
        head.text = "گزارش بازی"
        head.textSize = 18f
        head.setTextColor(Color.WHITE)
        head.setTypeface(null, Typeface.BOLD)
        if (Build.VERSION.SDK_INT >= 28) head.isAccessibilityHeading = true
        view.addView(head)
    }

    fun add(text: String) {
        val t = text.trim()
        if (t.isEmpty() || t == last) return
        last = t
        val tv = TextView(ctx)
        tv.text = t
        tv.textSize = 15f
        tv.setTextColor(Color.WHITE)
        tv.setPadding(0, dp(4), 0, dp(4))
        view.addView(tv, 1)
        while (view.childCount > max + 1) view.removeViewAt(view.childCount - 1)
    }

    fun clear() {
        while (view.childCount > 1) view.removeViewAt(1)
        last = ""
    }
}
