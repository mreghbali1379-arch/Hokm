package com.example.hokm.engine

/** s = suit (0 ♠, 1 ♥, 2 ♦, 3 ♣), r = rank (2..10, 11 J, 12 Q, 13 K, 14 A). */
data class Card(val s: Int, val r: Int) {
    /** Unique number of the card: suit * 20 + rank. */
    val id: Int get() = s * 20 + r
}

/** Removes and returns the last element (the top of the deck). */
fun <T> MutableList<T>.pop(): T = removeAt(size - 1)

object Deck {
    /** The 52 cards in order (a new list every time). */
    fun all(): MutableList<Card> {
        val d = ArrayList<Card>(52)
        for (s in 0..3) for (r in 2..14) d.add(Card(s, r))
        return d
    }

    /** Suits in order, high cards first inside a suit. */
    fun sortHand(h: MutableList<Card>) {
        h.sortWith(Comparator { a, b -> if (a.s != b.s) a.s - b.s else b.r - a.r })
    }
}

/** Persian names of suits and ranks, for texts read out to the player. */
object CardText {
    val SUIT_SYMBOLS = arrayOf("♠", "♥", "♦", "♣")
    val SUIT_NAMES = arrayOf("پیک", "دل", "خشت", "گشنیز")
    val SEAT_NAMES = arrayOf("شما", "حریف ۱", "یار", "حریف ۲")

    fun fa(n: Int): String {
        val digits = "۰۱۲۳۴۵۶۷۸۹"
        val sb = StringBuilder()
        for (ch in n.toString()) sb.append(if (ch in '0'..'9') digits[ch - '0'] else ch)
        return sb.toString()
    }

    fun rankName(r: Int): String = when (r) {
        11 -> "سرباز"
        12 -> "بی‌بی"
        13 -> "شاه"
        14 -> "آس"
        else -> fa(r)
    }

    fun cardName(c: Card): String = rankName(c.r) + " " + SUIT_NAMES[c.s]
}
