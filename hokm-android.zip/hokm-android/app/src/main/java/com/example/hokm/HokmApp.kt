package com.example.hokm

import android.app.Activity
import android.app.Application
import android.os.Bundle

/**
 * Starts the background music when the app first appears (also on the main menu, like the old version) and pauses
 * it only when no screen of the app is visible any more (home button, another app, app closed).
 */
class HokmApp : Application() {
    private var visible = 0

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) {
                visible++
                if (visible == 1) Sound.get(this@HokmApp).hold(false)
            }

            override fun onActivityStopped(a: Activity) {
                visible--
                if (visible <= 0) {
                    visible = 0
                    Sound.get(this@HokmApp).hold(true)
                }
            }

            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}
