package com.example.hokm.engine

import kotlin.random.Random

/** One card played in a 4-player trick. */
class Entry(val seat: Int, val c: Card)

/** What was on the table when a card was played (the bots use this to judge the other players). */
class PlayRec(val seat: Int, val c: Card, val len: Int, val led: Int, val bs: Int, val bc: Card?)

enum class Phase { IDLE, PICK, PLAY, END }

class HandResult(
    /** Winning team (0 = you + partner, 1 = the opponents). */
    val team: Int,
    val bam: Boolean,
    /** True for a kot (2 points for the hakem's team, 3 against the hakem). */
    val kot: Boolean,
    val points: Int,
    val gameOver: Boolean
)

class PlayResult(
    val trickDone: Boolean,
    /** Seat that took the trick (only when [trickDone]). */
    val winner: Int,
    /** Not null when this card ended the hand. */
    val hand: HandResult?
)

/**
 * 4-player Hokm: seats 0..3 go round the table; seat 0 = you, 2 = your partner; teams = seat % 2.
 * Pure rules and state, no screen code.
 */
class Game4(var hakem: Int = Random.nextInt(4)) {
    val hands: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    var trump = -1
    var deck: MutableList<Card> = ArrayList()
    var turn = 0
    var trick: MutableList<Entry> = ArrayList()
    val tk = intArrayOf(0, 0)

    /** Team that took 7 tricks while the other had none (-1 = nobody yet). */
    var kt = -1
    val sc = intArrayOf(0, 0)
    var phase = Phase.IDLE

    /** Ids of cards already played in this hand. */
    val seen = HashSet<Int>()

    /** voids[seat] = suits that seat has shown it does not have. */
    val voids: Array<MutableSet<Int>> = Array(4) { HashSet<Int>() }
    var lastTrick: List<Entry> = emptyList()
    var winSeat = -1
    val plays = ArrayList<PlayRec>()

    fun beats(c: Card, b: Card): Boolean = if (c.s == b.s) c.r > b.r else c.s == trump

    fun bestOf(t: List<Entry>): Entry {
        var b = t[0]
        for (x in t) if (beats(x.c, b.c)) b = x
        return b
    }

    fun legal(s: Int): List<Card> {
        val h = hands[s]
        if (trick.isEmpty()) return h
        val led = trick[0].c.s
        val f = h.filter { it.s == led }
        return if (f.isNotEmpty()) f else h
    }

    /** New match: scores to zero. */
    fun newMatch(firstHakem: Int) {
        sc[0] = 0
        sc[1] = 0
        hakem = firstHakem
        phase = Phase.IDLE
    }

    /** Shuffles and deals the first five cards to everybody; the hakem now picks the trump. */
    fun newHand() {
        val d = Deck.all()
        d.shuffle()
        deck = d
        for (h in hands) h.clear()
        trump = -1
        trick = ArrayList()
        tk[0] = 0
        tk[1] = 0
        kt = -1
        seen.clear()
        for (v in voids) v.clear()
        winSeat = -1
        lastTrick = emptyList()
        plays.clear()
        for (i in 0..3) for (k in 0..4) hands[i].add(deck.pop())
        for (i in 0..3) Deck.sortHand(hands[i])
        phase = Phase.PICK
    }

    /** The hakem chose the trump: everybody gets the rest of their 13 cards and the hakem leads. */
    fun setTrump(s: Int) {
        trump = s
        for (i in 0..3) while (hands[i].size < 13) hands[i].add(deck.pop())
        for (h in hands) Deck.sortHand(h)
        phase = Phase.PLAY
        turn = hakem
        trick = ArrayList()
    }

    /** Plays card c for seat s. The caller makes sure it is legal and that it is s's turn. */
    fun play(s: Int, c: Card): PlayResult {
        val bb = if (trick.isNotEmpty()) bestOf(trick) else null
        plays.add(PlayRec(s, c, trick.size, if (trick.isNotEmpty()) trick[0].c.s else -1, bb?.seat ?: -1, bb?.c))
        if (trick.isNotEmpty() && c.s != trick[0].c.s) voids[s].add(trick[0].c.s)
        seen.add(c.id)
        hands[s].remove(c)
        trick.add(Entry(s, c))
        if (trick.size < 4) {
            turn = (s + 1) % 4
            return PlayResult(false, -1, null)
        }
        val w = bestOf(trick).seat
        tk[w % 2]++
        winSeat = w
        lastTrick = ArrayList(trick)
        trick = ArrayList()
        turn = w
        val hs = if (tk[0] >= 7) 0 else if (tk[1] >= 7) 1 else -1
        if (hs >= 0) {
            if (tk[1 - hs] == 0 && kt == -1) kt = hs
            if (tk[1 - hs] > 0 || tk[hs] == 13) return PlayResult(true, w, finishHand())
        }
        return PlayResult(true, w, null)
    }

    private fun finishHand(): HandResult {
        val t = if (tk[0] >= 7) 0 else 1
        val hk = hakem % 2
        val bam = tk[t] == 13
        val kot = bam || kt == t
        val pts = if (kot) (if (t == hk) 2 else 3) else 1
        sc[t] += pts
        if (bam) sc[t] = maxOf(sc[t], 7)
        phase = Phase.END
        val over = sc[t] >= 7
        // when the hakem's team loses the hand, the hakem seat moves on
        if (t != hk) hakem = (hakem + 1) % 4
        return HandResult(t, bam, kot, pts, over)
    }
}
