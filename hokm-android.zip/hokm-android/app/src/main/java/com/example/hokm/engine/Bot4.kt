package com.example.hokm.engine

import kotlin.random.Random

/**
 * The computer player of the four-player game: it guesses the hidden hands many times (respecting what has
 * been seen and who ran out of a suit), then solves the end of the hand exactly or plays it out quickly,
 * and picks the card that wins the whole game most often. Not thread-safe; read the game on the same thread.
 */
class Bot4(private val g: Game4, private val rng: Random = Random.Default) {
    // Strength settings. The defaults are the ones the game has always used.
    var trumpMs: Long = 150
    var botMs: Long = 150
    var exCards: Int = 5
    var exNodes: Int = 15000
    var minN: Int = 16

    /** when > 0: exactly this many sampled worlds per decision and no time limit (used by tests) */
    var fixN: Int = 0
    var useLr: Boolean = true
    var useBias: Boolean = true
    var useMw: Boolean = true
        set(v) {
            field = v
            rv = ResultValues(v)
        }

    private class SearchAbort : RuntimeException(null, null, false, false)

    private class TP(val seat: Int, val id: Int)

    private class TtEntry(var lo: Double, var hi: Double)

    // ---------------------------------------------------------------- value of a hand result

    private var rv = ResultValues(true)
    private val lv: DoubleArray get() = rv.lv

    private fun setLV(me: Int) = rv.set(me, g.sc)

    private fun value(c: Card): Int = c.r + (if (c.s == g.trump) 100 else 0)

    // ---------------------------------------------------------------- exact search (cards as ints: suit*20+rank)

    private var nodes = 0
    private var lim = 0
    private var deadline = 0L
    private val u = IntArray(4)
    private val tt = HashMap<String, TtEntry>()

    private fun sid(i: Int) = i / 20

    private fun beatsI(a: Int, b: Int): Boolean =
        if (sid(a) == sid(b)) a % 20 > b % 20 else sid(a) == g.trump

    private fun ttKey(hh: Array<IntArray>, turn: Int, t: IntArray): String {
        val sb = StringBuilder(64)
        sb.append(turn).append('|').append(t[0]).append('|').append(t[1]).append('|')
        if (t[2] == -1) sb.append('n') else sb.append(t[2])
        val m = IntArray(4)
        for (p in 0 until 4) {
            m[0] = 0; m[1] = 0; m[2] = 0; m[3] = 0
            for (i in hh[p]) m[sid(i)] = m[sid(i)] or (1 shl (i % 20))
            sb.append('|').append(m[0]).append(',').append(m[1]).append(',').append(m[2]).append(',').append(m[3])
        }
        return sb.toString()
    }

    private fun sv(
        hh: Array<IntArray>, trk: List<TP>, turn: Int, t: IntArray, team: Int,
        alIn: Double, beIn: Double
    ): Double {
        if (++nodes > lim || ((nodes and 255) == 0 && System.currentTimeMillis() > deadline)) throw SearchAbort()
        var al = alIn
        var be = beIn
        if (trk.size == 4) {
            var b = trk[0]
            for (x in trk) if (beatsI(x.id, b.id)) b = x
            val t2 = t.copyOf()
            Scoring.adv(t2, b.seat % 2)
            val p = Scoring.points(t2, team, g.hakem % 2)
            if (p != Scoring.NONE) return lv[p + 7]
            val u0 = u[0]; val u1 = u[1]; val u2 = u[2]; val u3 = u[3]
            for (x in trk) u[sid(x.id)] = u[sid(x.id)] and (1 shl (x.id % 20)).inv()
            val r = sv(hh, emptyList(), b.seat, t2, team, al, be)
            u[0] = u0; u[1] = u1; u[2] = u2; u[3] = u3
            return r
        }
        var key: String? = null
        var ent: TtEntry? = null
        val al0 = al
        val be0 = be
        if (trk.isEmpty() && hh[turn].size > 1) {
            key = ttKey(hh, turn, t)
            ent = tt[key]
            if (ent != null) {
                if (ent.lo >= be) return ent.lo
                if (ent.hi <= al) return ent.hi
                if (ent.lo > al) al = ent.lo
                if (ent.hi < be) be = ent.hi
                if (al >= be) return if (ent.lo >= be0) ent.lo else ent.hi
            }
        }
        val hand = hh[turn]
        val led = if (trk.isNotEmpty()) sid(trk[0].id) else -1
        var L: List<Int> = hand.asList()
        if (led >= 0) {
            val f = hand.filter { sid(it) == led }
            if (f.isNotEmpty()) L = f
        }
        if (L.isEmpty()) return lv[7]
        val trumpSuit = g.trump
        fun vv(i: Int): Int = (if (sid(i) == trumpSuit) 100 else 0) + i % 20
        var bid = -1
        if (trk.isNotEmpty()) {
            bid = trk[0].id
            for (x in trk) if (beatsI(x.id, bid)) bid = x.id
        }
        val bidF = bid
        L = if (bidF >= 0) {
            // cheapest winning cards first, then cheapest losing cards
            L.sortedByDescending { if (beatsI(it, bidF)) 2000 - vv(it) else -vv(it) }
        } else {
            L.sortedByDescending { vv(it) }
        }
        val mx = turn % 2 == team
        var best = if (mx) -9.0 else 9.0
        val prev = intArrayOf(-1, -1, -1, -1)
        for (id in L) {
            val sd = sid(id)
            val pv = prev[sd]
            prev[sd] = id
            if (pv >= 0) {
                val lo = minOf(pv, id) % 20
                val hi = maxOf(pv, id) % 20
                // two cards with no unplayed card between them are equal: try only one
                if ((u[sd] and (((1 shl hi) - 1) and ((1 shl (lo + 1)) - 1).inv())) == 0) continue
            }
            hh[turn] = hand.filter { it != id }.toIntArray()
            val v = sv(hh, trk + TP(turn, id), (turn + 1) % 4, t, team, al, be)
            hh[turn] = hand
            if (mx) {
                if (v > best) best = v
                if (best > al) al = best
            } else {
                if (v < best) best = v
                if (best < be) be = best
            }
            if (al >= be) break
        }
        if (key != null) {
            val e = ent ?: TtEntry(-9.0, 9.0)
            if (best <= al0) e.hi = minOf(e.hi, best)
            else if (best >= be0) e.lo = maxOf(e.lo, best)
            else {
                e.lo = best
                e.hi = best
            }
            tt[key] = e
        }
        return best
    }

    /** Exact value (for [s]'s team) of playing [c] in the sampled world [hs]; null if the node limit was hit. */
    private fun evalExact(hs: Array<MutableList<Card>>, s: Int, c: Card, limit: Int): Double? {
        val hh = Array(4) { p -> IntArray(hs[p].size) { hs[p][it].id } }
        val id = c.id
        hh[s] = hh[s].filter { it != id }.toIntArray()
        val trk = ArrayList<TP>()
        for (t in g.trick) trk.add(TP(t.seat, t.c.id))
        trk.add(TP(s, id))
        u.fill(0)
        for (a in hh) for (i in a) u[sid(i)] = u[sid(i)] or (1 shl (i % 20))
        for (x in trk) u[sid(x.id)] = u[sid(x.id)] or (1 shl (x.id % 20))
        nodes = 0
        lim = limit
        tt.clear()
        return try {
            sv(hh, trk, (s + 1) % 4, intArrayOf(g.tk[0], g.tk[1], g.kt), s % 2, -9.0, 9.0)
        } catch (e: SearchAbort) {
            null
        }
    }

    // ---------------------------------------------------------------- guessing the hidden hands

    // A guess is less likely when a player played a card that a sensible player would not have played.
    private fun weightOf(hs: Array<MutableList<Card>>, s: Int): Double {
        var w = 1.0
        val trump = g.trump
        val plays = g.plays
        for (i in plays.indices) {
            val e = plays[i]
            val x = e.seat
            if (x == s || e.len == 0) continue
            val hand = ArrayList<Card>(hs[x])
            for (k in i until plays.size) if (plays[k].seat == x) hand.add(plays[k].c)
            val bc = e.bc ?: continue
            if (e.c.s == e.led) {
                val pwin = (x + 2) % 4 == e.bs
                val wins = !pwin && g.beats(e.c, bc)
                val better = hand.any { c ->
                    c.s == e.led && c.r < e.c.r && (if (wins) g.beats(c, bc) else true)
                }
                if (better) w *= if (x == 0) 0.6 else 0.3
            } else if (e.c.s != trump && (x + 2) % 4 != e.bs && hand.any { c -> c.s == trump && g.beats(c, bc) }) {
                w *= if (x == 0) 0.5 else 0.2
            }
        }
        return w
    }

    private class Item(val c: Card, val al: List<Int>)

    // Deals the unseen cards randomly to the three other players, respecting suits they have run out of.
    private fun sampleWorld(s: Int, un: List<Card>, others: List<Int>, useVoids: Boolean): Array<MutableList<Card>>? {
        val attempts = if (useVoids) 8 else 1
        for (at in 0 until attempts) {
            val need = IntArray(4)
            for (o in others) need[o] = g.hands[o].size
            val hs: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
            hs[s].addAll(g.hands[s])
            val shuffled = ArrayList(un)
            shuffled.shuffle(rng)
            val items = ArrayList<Item>(shuffled.size)
            for (c in shuffled) {
                items.add(Item(c, if (useVoids) others.filter { !g.voids[it].contains(c.s) } else others))
            }
            if (useVoids) items.sortBy { it.al.size } // stable: most restricted cards first
            var ok = true
            for (item in items) {
                var tot = 0
                for (o in item.al) if (need[o] > 0) tot += need[o]
                if (tot <= 0) {
                    ok = false
                    break
                }
                var r = rng.nextDouble() * tot
                var pk = -1
                for (o in item.al) {
                    if (need[o] > 0) {
                        r -= need[o]
                        if (r < 0) {
                            pk = o
                            break
                        }
                    }
                }
                if (pk < 0) pk = item.al.first { need[it] > 0 }
                hs[pk].add(item.c)
                need[pk]--
            }
            if (ok) return hs
        }
        return null
    }

    // ---------------------------------------------------------------- quick play-outs

    /** The simple policy used inside play-outs. */
    private fun rp(hand: List<Card>, seat: Int, trk: List<Entry>): Card {
        val led = if (trk.isNotEmpty()) trk[0].c.s else -1
        var L = hand
        if (led >= 0) {
            val f = hand.filter { it.s == led }
            if (f.isNotEmpty()) L = f
        }
        if (trk.isEmpty()) {
            var b: Card? = null
            var bv = -99
            for (c in hand) {
                val v = c.r + (if (c.s == g.trump) -50 else 0)
                if (v > bv) {
                    bv = v
                    b = c
                }
            }
            return b!!
        }
        val b = g.bestOf(trk)
        var lc = L[0]
        for (c in L) if (value(c) < value(lc)) lc = c
        if (b.seat % 2 == seat % 2) return lc
        var w: Card? = null
        for (c in L) if (g.beats(c, b.c) && (w == null || value(c) < value(w))) w = c
        return w ?: lc
    }

    private fun rollout(h0: Array<MutableList<Card>>, s: Int, c: Card): Double {
        val hh = Array(4) { ArrayList(h0[it]) }
        hh[s].remove(c)
        val t = intArrayOf(g.tk[0], g.tk[1], g.kt)
        val trk = ArrayList<Entry>(g.trick)
        trk.add(Entry(s, c))
        var turn = (s + 1) % 4
        while (true) {
            if (trk.size == 4) {
                val w = g.bestOf(trk).seat
                Scoring.adv(t, w % 2)
                trk.clear()
                turn = w
                val pp = Scoring.points(t, s % 2, g.hakem % 2)
                if (pp != Scoring.NONE) return lv[pp + 7]
            }
            if (hh[turn].isEmpty()) break
            val pc = rp(hh[turn], turn, trk)
            hh[turn].remove(pc)
            trk.add(Entry(turn, pc))
            if (trk.size < 4) turn = (turn + 1) % 4
        }
        val p = Scoring.points(t, s % 2, g.hakem % 2)
        return lv[(if (p == Scoring.NONE) 0 else p) + 7]
    }

    private fun full(h0: Array<MutableList<Card>>, hk: Int): Double {
        val hh = Array(4) { ArrayList(h0[it]) }
        val t = intArrayOf(0, 0, -1)
        val trk = ArrayList<Entry>()
        var turn = hk
        while (true) {
            if (trk.size == 4) {
                val w = g.bestOf(trk).seat
                Scoring.adv(t, w % 2)
                trk.clear()
                turn = w
                val p = Scoring.points(t, hk % 2, g.hakem % 2)
                if (p != Scoring.NONE) return lv[p + 7]
            }
            val pc = rp(hh[turn], turn, trk)
            hh[turn].remove(pc)
            trk.add(Entry(turn, pc))
            if (trk.size < 4) turn = (turn + 1) % 4
        }
    }

    // ---------------------------------------------------------------- decisions

    /** Picks the trump for the hakem [hk] from his first five cards. */
    fun chooseTrump(hk: Int): Int {
        val mine = ArrayList(g.hands[hk])
        val own = HashSet<Int>()
        for (c in mine) own.add(c.id)
        val un = ArrayList<Card>()
        for (x in 0 until 4) for (r in 2..14) if (!own.contains(x * 20 + r)) un.add(Card(x, r))
        val sc3 = DoubleArray(4)
        val old = g.trump
        val t0 = System.currentTimeMillis()
        try {
            setLV(hk % 2)
            var n = 0
            while (n < 600 && (n < 150 || System.currentTimeMillis() - t0 < trumpMs)) {
                val pool = ArrayList(un)
                pool.shuffle(rng)
                var pos = 0
                val hs: Array<MutableList<Card>> = Array(4) { o ->
                    val l = ArrayList<Card>()
                    if (o == hk) l.addAll(mine)
                    val take = if (o == hk) 8 else 13
                    for (k in 0 until take) l.add(pool[pos++])
                    l
                }
                for (x in 0 until 4) {
                    g.trump = x
                    sc3[x] += full(hs, hk)
                }
                n++
            }
        } finally {
            g.trump = old
        }
        var b = 0
        for (i in 0 until 4) if (sc3[i] > sc3[b]) b = i
        return b
    }

    // how likely the hakem is to hold this many cards of the trump suit, given he chose it (from simulation)
    private val hkLr = doubleArrayOf(0.15, 0.2, 0.3, 0.78, 1.37, 2.0, 2.6, 3.1, 3.5, 4.0, 3.0, 2.0, 1.5, 1.5)

    /** Plain fallback: the cheapest sensible legal card. */
    fun safePick(s: Int): Card? {
        val L = g.legal(s)
        if (L.isEmpty()) return null
        try {
            val c = rp(g.hands[s], s, g.trick)
            if (L.contains(c)) return c
        } catch (e: Exception) {
        }
        return L.reduce { m, c -> if (value(c) < value(m)) c else m }
    }

    /** The best card for [s] by sampling, or null when it cannot decide. */
    fun choose(s: Int): Card? {
        val h = g.hands[s]
        val L = g.legal(s)
        if (L.size == 1) return L[0]
        setLV(s % 2)
        val inTrick = HashSet<Int>()
        for (t in g.trick) inTrick.add(t.c.id)
        fun inert(x: Int, r: Int): Boolean =
            h.any { it.s == x && it.r == r } || (g.seen.contains(x * 20 + r) && !inTrick.contains(x * 20 + r))

        fun eqv(d: Card, c: Card): Boolean {
            for (r in d.r + 1 until c.r) if (!inert(c.s, r)) return false
            return true
        }
        // cards that are equal in practice (nothing unplayed lies between them) are tried only once
        val cand = L.filter { c -> L.none { d -> d.s == c.s && d.r < c.r && eqv(d, c) } }
            .sortedBy { value(it) }
        if (cand.size == 1) return cand[0]
        val un = ArrayList<Card>()
        for (x in 0 until 4) for (r in 2..14) {
            if (!g.seen.contains(x * 20 + r) && h.none { it.s == x && it.r == r }) un.add(Card(x, r))
        }
        val others = (0 until 4).filter { it != s }
        if (un.size != others.sumOf { g.hands[it].size }) return null
        val trump = g.trump
        val cnt = h.size
        val bamZone = g.kt != -1 || (minOf(g.tk[0], g.tk[1]) == 0 && maxOf(g.tk[0], g.tk[1]) >= 5)
        val exact = cnt <= (if (bamZone) exCards + 1 else exCards)
        val budget = botMs * (if (bamZone) 1.5 else 1.0)
        val t0 = System.currentTimeMillis()
        // small penalty for three patterns that are almost always wrong for the last player of a trick;
        // only matters when the simulation shows no clear difference
        val lastSeat = g.trick.size == 3
        val bb0 = if (g.trick.isNotEmpty()) g.bestOf(g.trick) else null
        val pwin = bb0 != null && bb0.seat == (s + 2) % 4
        fun bias(c: Card): Double {
            if (!useBias || !lastSeat || bb0 == null) return 0.0
            val cw = g.beats(c, bb0.c)
            var p = 0.0
            if (pwin && cw) p += 0.012
            if (pwin && c.s == trump && bb0.c.s != trump) p += 0.012
            if (!pwin && !cw && c.s == g.trick[0].c.s && L.any { g.beats(it, bb0.c) }) p += 0.012
            return p
        }

        val sc2 = DoubleArray(cand.size)
        deadline = if (fixN > 0) Long.MAX_VALUE else t0 + (budget * 2.5).toLong()
        var n = 0
        while (n < 4000 && (if (fixN > 0) n < fixN else
                ((n < minN || System.currentTimeMillis() - t0 < budget) &&
                    (n < 3 || System.currentTimeMillis() - t0 < budget * 2.5)))
        ) {
            val hs = sampleWorld(s, un, others, true) ?: sampleWorld(s, un, others, false) ?: return null
            var w = weightOf(hs, s)
            if (useLr && s != g.hakem && trump != -1) {
                val k = hs[g.hakem].count { it.s == trump }
                w *= hkLr[minOf(13, k)]
            }
            for (i in cand.indices) {
                val c = cand[i]
                var v: Double? = null
                if (exact) v = evalExact(hs, s, c, exNodes)
                if (v == null) v = rollout(hs, s, c)
                sc2[i] += w * (v - 0.0008 * (c.r / 14.0 + (if (c.s == trump) 0.3 else 0.0)) - bias(c))
            }
            n++
        }
        var bi = 0
        for (i in sc2.indices) if (sc2[i] > sc2[bi]) bi = i
        return cand[bi]
    }

    /** What the computer plays for [s]: the best card, or the safe fallback if anything goes wrong. */
    fun pick(s: Int): Card {
        val L = g.legal(s)
        var p: Card? = try {
            choose(s)
        } catch (e: Exception) {
            null
        }
        if (p == null || !L.contains(p)) p = safePick(s)
        return p ?: L[0]
    }
}
