package com.example.hokm

import android.content.Context
import com.example.hokm.engine.Card
import com.example.hokm.engine.Entry2
import com.example.hokm.engine.Game2
import com.example.hokm.engine.Phase2
import org.json.JSONArray
import org.json.JSONObject

/**
 * Keeps the two-player game so it can be continued later. Two kinds of save:
 *  - "round": only the match (scores, hakem, the two deuces that are out); the round is dealt again on resume.
 *    Saved at the start of every round, so leaving during the discard / trump / drawing steps repeats the round.
 *  - "play": the complete table, saved after every card once the 13 tricks have started.
 */
object DuoSaveStore {
    private const val KEY = "duo"
    const val NONE = 0
    const val ROUND = 1
    const val PLAY = 2

    private fun prefs(c: Context) = c.getSharedPreferences("hokm_save", Context.MODE_PRIVATE)

    fun exists(c: Context): Boolean = prefs(c).getString(KEY, null) != null

    fun clear(c: Context) {
        prefs(c).edit().remove(KEY).apply()
    }

    fun saveRound(c: Context, g: Game2) = put(c, base(g, "round"))

    fun raw(c: Context): String? = prefs(c).getString(KEY, null)

    /** Fills [g] from a saved text (also used for the multi-phone snapshot): NONE, ROUND or PLAY. */
    fun loadInto(g: Game2, json: String): Int = try {
        fromJson(g, json)
    } catch (e: Exception) {
        NONE
    }

    fun putRaw(c: Context, json: String) {
        prefs(c).edit().putString(KEY, json).apply()
    }

    /** The game as JSON text for a manual save slot ("play" = the whole table, otherwise only the match). */
    fun dump(g: Game2, full: Boolean): String = (if (full) buildFull(g) else base(g, "round")).toString()

    fun saveFull(c: Context, g: Game2) {
        try {
            put(c, buildFull(g))
        } catch (e: Exception) {
        }
    }

    private fun buildFull(g: Game2): JSONObject {
        val o = base(g, "play")
        o.put("trump", g.trump)
        o.put("tk", ints(g.tk))
        o.put("kt", g.kt)
        o.put("turn", g.turn)
        o.put("step", g.step)
        o.put("ch", g.ch)
        val hs = JSONArray()
        for (h in g.hands) hs.put(ids(h))
        o.put("hands", hs)
        o.put("deck", ids(g.deck))
        o.put("trick", entries(g.trick))
        o.put("last", entries(g.lastTrick))
        o.put("played", JSONArray(g.played.toList()))
        o.put("gone", JSONArray(g.gone.toList()))
        val vs = JSONArray()
        for (v in g.vo) vs.put(JSONArray(v.toList()))
        o.put("vo", vs)
        return o
    }

    /** Fills [g]; returns NONE, ROUND or PLAY. [g] is untouched when nothing valid is saved. */
    fun load(c: Context, g: Game2): Int {
        val s = prefs(c).getString(KEY, null) ?: return NONE
        return try {
            fromJson(g, s)
        } catch (e: Exception) {
            NONE
        }
    }

    // ------------------------------------------------------------------ JSON

    private fun put(c: Context, o: JSONObject) {
        try {
            prefs(c).edit().putString(KEY, o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    private fun base(g: Game2, mode: String): JSONObject {
        val o = JSONObject()
        o.put("v", 1)
        o.put("mode", mode)
        o.put("sc", ints(g.sc))
        o.put("hk", g.hk)
        o.put("out", ids(g.outCards))
        return o
    }

    private fun ids(l: List<Card>): JSONArray {
        val a = JSONArray()
        for (c in l) a.put(c.id)
        return a
    }

    private fun cards(a: JSONArray): MutableList<Card> {
        val l = ArrayList<Card>()
        for (i in 0 until a.length()) {
            val id = a.getInt(i)
            l.add(Card(id / 20, id % 20))
        }
        return l
    }

    private fun entries(l: List<Entry2>): JSONArray {
        val a = JSONArray()
        for (e in l) a.put(JSONArray().put(e.p).put(e.c.id))
        return a
    }

    private fun entriesFrom(a: JSONArray): MutableList<Entry2> {
        val l = ArrayList<Entry2>()
        for (i in 0 until a.length()) {
            val p = a.getJSONArray(i)
            val id = p.getInt(1)
            l.add(Entry2(p.getInt(0), Card(id / 20, id % 20)))
        }
        return l
    }

    private fun ints(a: IntArray): JSONArray {
        val j = JSONArray()
        for (x in a) j.put(x)
        return j
    }

    private fun intSet(a: JSONArray): HashSet<Int> {
        val s = HashSet<Int>()
        for (i in 0 until a.length()) s.add(a.getInt(i))
        return s
    }

    private fun fromJson(g: Game2, s: String): Int {
        val o = JSONObject(s)
        if (o.getInt("v") != 1) return NONE
        val mode = o.getString("mode")
        val hk = o.getInt("hk")
        val sc = o.getJSONArray("sc")
        if (hk !in 0..1 || sc.length() != 2) return NONE
        val out = cards(o.getJSONArray("out"))
        if (mode == "round") {
            g.sc[0] = sc.getInt(0)
            g.sc[1] = sc.getInt(1)
            g.hk = hk
            g.outCards = out
            g.phase = Phase2.IDLE
            return ROUND
        }
        if (mode != "play") return NONE
        val trump = o.getInt("trump")
        val tk = o.getJSONArray("tk")
        val kt = o.getInt("kt")
        val turn = o.getInt("turn")
        if (trump !in 0..3 || tk.length() != 2 || kt !in -1..1 || turn !in 0..1) return NONE
        val hj = o.getJSONArray("hands")
        if (hj.length() != 2) return NONE
        val hands = ArrayList<MutableList<Card>>()
        for (i in 0 until 2) {
            val h = cards(hj.getJSONArray(i))
            if (h.size > 13) return NONE
            hands.add(h)
        }
        val trick = entriesFrom(o.getJSONArray("trick"))
        if (trick.size > 1) return NONE
        val last = entriesFrom(o.getJSONArray("last"))
        val deck = cards(o.getJSONArray("deck"))
        val played = intSet(o.getJSONArray("played"))
        val gone = intSet(o.getJSONArray("gone"))
        val vj = o.getJSONArray("vo")
        if (vj.length() != 2) return NONE
        val vo0 = intSet(vj.getJSONArray(0))
        val vo1 = intSet(vj.getJSONArray(1))
        val step = o.getInt("step")
        val ch = o.getInt("ch")
        // everything parsed: now apply
        g.sc[0] = sc.getInt(0)
        g.sc[1] = sc.getInt(1)
        g.hk = hk
        g.outCards = out
        g.trump = trump
        g.tk[0] = tk.getInt(0)
        g.tk[1] = tk.getInt(1)
        g.kt = kt
        g.turn = turn
        g.step = step
        g.ch = ch
        g.hands[0] = hands[0]
        g.hands[1] = hands[1]
        g.deck = deck
        g.trick = trick
        g.lastTrick = last
        g.played.clear()
        g.played.addAll(played)
        g.gone.clear()
        g.gone.addAll(gone)
        g.vo[0].clear()
        g.vo[0].addAll(vo0)
        g.vo[1].clear()
        g.vo[1].addAll(vo1)
        g.up = null
        g.dn = null
        g.phase = Phase2.PLAY
        return PLAY
    }
}
