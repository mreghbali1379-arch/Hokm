package com.example.hokm.engine

import kotlin.random.Random

/** One card played in a 2-player trick (p = 0 you, 1 the opponent). */
class Entry2(val p: Int, val c: Card)

enum class Phase2 { IDLE, DISC, TRUMP, DRAW, PLAY, END }

class Result2(
    /** Winning player (0 = you, 1 = the opponent). */
    val team: Int,
    val bam: Boolean,
    val kot: Boolean,
    val points: Int,
    val gameOver: Boolean
)

class PlayResult2(val trickDone: Boolean, val winner: Int, val hand: Result2?)

/**
 * 2-player Hokm. Two deuces are taken out of the deck once per match. Every round both players get
 * five cards, throw away two (keeping three), the hakem names the trump, then 20 times one of them
 * (hakem first, then alternating) sees two cards, a face-up one and a face-down one, and keeps one of
 * them; the other is thrown away. That makes 13 cards each.
 */
class Game2 {
    val sc = intArrayOf(0, 0)

    /** Hakem: 0 = you, 1 = the opponent. */
    var hk = 0
    var deck: MutableList<Card> = ArrayList()
    val hands: Array<MutableList<Card>> = arrayOf(ArrayList(), ArrayList())
    var trump = -1
    val tk = intArrayOf(0, 0)
    var trick: MutableList<Entry2> = ArrayList()
    var lastTrick: List<Entry2> = emptyList()

    /** Ids of cards played this round. */
    val played = HashSet<Int>()

    /** Ids of cards known to be out of the game (the two deuces, the opponent's own thrown cards). */
    val gone = HashSet<Int>()
    val vo: Array<MutableSet<Int>> = arrayOf(HashSet(), HashSet())
    var step = 0
    var kt = -1
    var turn = 0
    var phase = Phase2.IDLE

    /** The two cards offered in the current draw step and who chooses (0 = you, 1 = opponent). */
    var up: Card? = null
    var dn: Card? = null
    var ch = 0

    /** The two deuces that stay out all match. */
    var outCards: List<Card> = emptyList()

    fun beats(c: Card, b: Card): Boolean = if (c.s == b.s) c.r > b.r else c.s == trump

    fun legal(p: Int): List<Card> {
        val h = hands[p]
        if (trick.isNotEmpty()) {
            val f = h.filter { it.s == trick[0].c.s }
            if (f.isNotEmpty()) return f
        }
        return h
    }

    fun newMatch(firstHakem: Int) {
        sc[0] = 0
        sc[1] = 0
        hk = firstHakem
        val s = (0..3).shuffled()
        outCards = listOf(Card(s[0], 2), Card(s[1], 2))
        phase = Phase2.IDLE
    }

    /** Shuffles, takes the two deuces out and deals five cards to each player (hakem first). */
    fun startRound() {
        val d = Deck.all()
        d.shuffle()
        if (outCards.isNotEmpty()) {
            d.removeAll(outCards.toSet())
        } else {
            var rm = 0
            d.removeAll { c -> if (c.r == 2 && rm < 2) { rm++; true } else false }
        }
        deck = d
        for (h in hands) h.clear()
        trump = -1
        tk[0] = 0
        tk[1] = 0
        trick = ArrayList()
        lastTrick = emptyList()
        played.clear()
        gone.clear()
        for (c in outCards) gone.add(c.id)
        vo[0].clear()
        vo[1].clear()
        step = 0
        kt = -1
        up = null
        dn = null
        for (k in 0 until 5) hands[hk].add(deck.pop())
        for (k in 0 until 5) hands[1 - hk].add(deck.pop())
        phase = Phase2.DISC
    }

    /** You throw away two cards. */
    fun humanDiscard(cards: List<Card>) {
        hands[0].removeAll(cards.toSet())
    }

    /** The opponent keeps [keep] (three cards) and throws away the rest; it remembers what it threw. */
    fun botKeep(keep: List<Card>) {
        for (c in hands[1]) if (!keep.contains(c)) gone.add(c.id)
        hands[1] = ArrayList(keep)
    }

    /** Starts the drawing steps. */
    fun beginDraw() {
        phase = Phase2.DRAW
        step = 0
    }

    /** Lays out the next two cards. Returns false when all 20 steps are done (then call [startPlay]). */
    fun nextPair(): Boolean {
        if (step >= 20) return false
        ch = if (step % 2 == 0) hk else 1 - hk
        up = deck.pop()
        dn = deck.pop()
        phase = Phase2.DRAW
        return true
    }

    /**
     * Player p keeps the face-up card (face = true) or the face-down one; the other is thrown away.
     * When [botKnows] the opponent remembers its own thrown card. Returns the card thrown away.
     */
    fun take(p: Int, face: Boolean, botKnows: Boolean = true): Card {
        val u = up!!
        val d = dn!!
        val got = if (face) u else d
        val thrown = if (face) d else u
        hands[p].add(got)
        if (p == 1 && botKnows) gone.add(thrown.id)
        step++
        return thrown
    }

    fun startPlay() {
        phase = Phase2.PLAY
        turn = hk
        trick = ArrayList()
    }

    fun play(p: Int, c: Card): PlayResult2 {
        if (trick.isNotEmpty() && c.s != trick[0].c.s) vo[p].add(trick[0].c.s)
        hands[p].remove(c)
        played.add(c.id)
        trick.add(Entry2(p, c))
        if (trick.size < 2) {
            turn = 1 - p
            return PlayResult2(false, -1, null)
        }
        val a = trick[0]
        val b = trick[1]
        val w = if (beats(b.c, a.c)) b.p else a.p
        tk[w]++
        lastTrick = ArrayList(trick)
        trick = ArrayList()
        turn = w
        val hs = if (tk[0] >= 7) 0 else if (tk[1] >= 7) 1 else -1
        if (hs >= 0) {
            if (tk[1 - hs] == 0 && kt == -1) kt = hs
            if (tk[1 - hs] > 0 || tk[hs] == 13) return PlayResult2(true, w, finishHand())
        }
        return PlayResult2(true, w, null)
    }

    private fun finishHand(): Result2 {
        val t = if (tk[0] >= 7) 0 else 1
        val bam = tk[t] == 13
        val kot = bam || kt == t
        val pts = if (kot) (if (t == hk) 2 else 3) else 1
        sc[t] += pts
        if (bam) sc[t] = maxOf(sc[t], 7)
        phase = Phase2.END
        val over = sc[t] >= 7
        if (t != hk) hk = 1 - hk
        return Result2(t, bam, kot, pts, over)
    }

    companion object {
        /** The hakem of the first round is drawn by the ceremony; this is a stand-in for tests. */
        fun randomHakem(): Int = Random.nextInt(2)
    }
}
