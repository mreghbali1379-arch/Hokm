package com.example.hokm

import android.content.Context
import android.view.View
import android.view.ViewGroup

/** Small movements (cards appear, a card lands on the table, faces change). They follow the animation speed setting. */
object Anim {
    private fun k(ctx: Context): Float = when (Prefs.anim(ctx)) {
        "slow" -> 1.8f
        "norm" -> 1f
        else -> 0.6f
    }

    /** The view grows a little and fades in. */
    fun pop(v: View) {
        val f = k(v.context)
        v.scaleX = 0.85f
        v.scaleY = 0.85f
        v.alpha = 0.35f
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration((260 * f).toLong()).start()
    }

    /** Every card of [grid] slides up and fades in, one after the other (a new deal). */
    fun dealIn(grid: ViewGroup) {
        val f = k(grid.context)
        val dy = 28f * grid.resources.displayMetrics.density
        for (i in 0 until grid.childCount) {
            val v = grid.getChildAt(i)
            v.alpha = 0f
            v.translationY = dy
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay((i * 45 * f).toLong()).setDuration((220 * f).toLong()).start()
        }
    }
}
