package com.example.hokm

import android.content.Context
import com.example.hokm.engine.CardText
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date

/** Games the player saved by hand ("ذخیره"): shown in "بازی‌های قبلی". kind = "4", "2" or "mp". */
object Slots {
    class Slot(val id: Long, val kind: String, val title: String, val time: Long, val data: String)

    private const val KEY = "slots"
    private const val MAX = 30

    private fun prefs(c: Context) = c.getSharedPreferences("hokm_slots", Context.MODE_PRIVATE)

    /** Newest first. */
    fun all(c: Context): List<Slot> {
        val out = ArrayList<Slot>()
        try {
            val a = JSONArray(prefs(c).getString(KEY, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Slot(o.getLong("id"), o.getString("kind"), o.getString("title"), o.getLong("time"), o.getString("data")))
            }
        } catch (e: Exception) {
        }
        return out.sortedByDescending { it.time }
    }

    private fun write(c: Context, l: List<Slot>) {
        val a = JSONArray()
        for (s in l) {
            a.put(JSONObject().put("id", s.id).put("kind", s.kind).put("title", s.title).put("time", s.time).put("data", s.data))
        }
        prefs(c).edit().putString(KEY, a.toString()).apply()
    }

    fun add(c: Context, kind: String, title: String, data: String): Slot {
        val s = Slot(System.currentTimeMillis(), kind, title, System.currentTimeMillis(), data)
        write(c, (listOf(s) + all(c)).take(MAX))
        return s
    }

    fun delete(c: Context, id: Long) {
        write(c, all(c).filter { it.id != id })
    }

    fun find(c: Context, id: Long): Slot? = all(c).firstOrNull { it.id == id }

    /** Persian (Jalali) date and time, like ۱۴۰۵/۰۷/۲۶ ۱۰:۳۰. */
    fun dateText(t: Long): String {
        return try {
            val pc = android.icu.util.PersianCalendar(Date(t))
            fun two(n: Int) = CardText.fa(n).let { if (n < 10) "۰$it" else it }
            CardText.fa(pc.get(android.icu.util.Calendar.YEAR)) + "/" + two(pc.get(android.icu.util.Calendar.MONTH) + 1) + "/" +
                two(pc.get(android.icu.util.Calendar.DAY_OF_MONTH)) + " " +
                two(pc.get(android.icu.util.Calendar.HOUR_OF_DAY)) + ":" + two(pc.get(android.icu.util.Calendar.MINUTE))
        } catch (e: Exception) {
            Date(t).toString()
        }
    }
}
