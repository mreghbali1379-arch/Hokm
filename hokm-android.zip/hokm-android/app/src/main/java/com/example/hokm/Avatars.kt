package com.example.hokm

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.ColorFilter
import android.graphics.drawable.Drawable
import android.os.Handler
import android.widget.TextView

/**
 * A small cartoon face for every player at the table. The look comes from the name (skin, hair, shirt) and from
 * whether the player is a woman or a man; the mood is one of "wait", "happy", "joy" or "sad".
 */
class AvatarDrawable(name: String, private val female: Boolean, private val mood: String) : Drawable() {
    private val h = name.hashCode() and 0x7fffffff
    private val skin = SKINS[h % SKINS.size].toInt()
    private val hair = HAIRS[(h / 7) % HAIRS.size].toInt()
    private val shirt = SHIRTS[(h / 13) % SHIRTS.size].toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private fun fill(c: Int) {
        paint.style = Paint.Style.FILL
        paint.color = c
    }

    private fun stroke(c: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.color = c
        paint.strokeWidth = w
        paint.strokeCap = Paint.Cap.ROUND
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val sc = minOf(b.width(), b.height()) / 100f
        if (sc <= 0f) return
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.scale(sc, sc)
        // round badge
        fill(0x40FFFFFF)
        canvas.drawCircle(50f, 50f, 49f, paint)
        path.reset()
        path.addCircle(50f, 50f, 49f, Path.Direction.CW)
        canvas.clipPath(path)
        // long hair behind the head
        if (female) {
            fill(hair)
            canvas.drawOval(RectF(18f, 16f, 82f, 92f), paint)
        }
        // shoulders and neck
        fill(shirt)
        canvas.drawOval(RectF(8f, 76f, 92f, 130f), paint)
        fill(skin)
        canvas.drawRect(43f, 62f, 57f, 82f, paint)
        // head
        canvas.drawCircle(50f, 46f, 27f, paint)
        // hair on top
        fill(hair)
        if (female) {
            canvas.drawArc(RectF(22f, 16f, 78f, 62f), 180f, 180f, true, paint)
        } else {
            canvas.drawArc(RectF(22f, 15f, 78f, 55f), 180f, 180f, true, paint)
        }
        // eyes
        val eye = 0xFF2A2A2A.toInt()
        if (mood == "joy") {
            stroke(eye, 3f)
            canvas.drawArc(RectF(33f, 41f, 46f, 52f), 200f, 140f, false, paint)
            canvas.drawArc(RectF(54f, 41f, 67f, 52f), 200f, 140f, false, paint)
        } else {
            fill(eye)
            canvas.drawCircle(40f, 47f, 3.4f, paint)
            canvas.drawCircle(60f, 47f, 3.4f, paint)
        }
        if (mood == "sad") {
            stroke(hair, 2.6f)
            canvas.drawLine(33f, 41f, 45f, 37f, paint)
            canvas.drawLine(67f, 41f, 55f, 37f, paint)
            fill(0xFF5AA9E6.toInt())
            canvas.drawOval(RectF(34f, 52f, 38f, 60f), paint)
        }
        // cheeks
        if (mood == "joy" || mood == "happy") {
            fill(0x66FF7A8A)
            canvas.drawCircle(32f, 56f, 5f, paint)
            canvas.drawCircle(68f, 56f, 5f, paint)
        }
        // mouth
        path.reset()
        when (mood) {
            "joy" -> {
                path.moveTo(37f, 57f)
                path.quadTo(50f, 78f, 63f, 57f)
                path.close()
                fill(0xFF7A1F1F.toInt())
                canvas.drawPath(path, paint)
            }
            "happy" -> {
                path.moveTo(38f, 58f)
                path.quadTo(50f, 71f, 62f, 58f)
                stroke(0xFF7A1F1F.toInt(), 3f)
                canvas.drawPath(path, paint)
            }
            "sad" -> {
                path.moveTo(40f, 66f)
                path.quadTo(50f, 57f, 60f, 66f)
                stroke(0xFF7A1F1F.toInt(), 3f)
                canvas.drawPath(path, paint)
            }
            else -> {
                path.moveTo(41f, 60f)
                path.quadTo(50f, 64f, 59f, 60f)
                stroke(0xFF7A1F1F.toInt(), 3f)
                canvas.drawPath(path, paint)
            }
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        private val SKINS = longArrayOf(0xFFF6D3B3, 0xFFE9B88A, 0xFFD39A6A, 0xFFB87A4F, 0xFF8D5A3B, 0xFFFFE0C2)
        private val HAIRS = longArrayOf(0xFF2B1B12, 0xFF4A2C17, 0xFF7A4A24, 0xFF111111, 0xFFB5651D, 0xFF5B5B5B)
        private val SHIRTS = longArrayOf(0xFF3B6EA8, 0xFFA83B5B, 0xFF3BA87A, 0xFF8A3BA8, 0xFFA8873B, 0xFF3BA8A8)
    }
}

object Avatars {
    /** The name without the "(یار)" mark that is added to a partner's name. */
    fun clean(label: String): String = label.replace(" (یار)", "").trim()

    /** Puts the face at the start of [tv] (a card picture at its end stays). Screen readers do not read it. */
    fun apply(tv: TextView, name: String, female: Boolean, mood: String) {
        val ctx = tv.context
        val d = AvatarDrawable(name, female, mood)
        val px = (40 * ctx.resources.displayMetrics.density).toInt()
        d.setBounds(0, 0, px, px)
        val c = tv.compoundDrawablesRelative
        tv.setCompoundDrawablesRelative(d, c[1], c[2], c[3])
        if (tv.compoundDrawablePadding == 0) tv.compoundDrawablePadding = (8 * ctx.resources.displayMetrics.density).toInt()
    }
}

/** The mood of every seat; a mood given with a time goes back to "wait" after it. [refresh] redraws one seat. */
class AvatarBoard(private val ui: Handler, n: Int, private val refresh: (Int) -> Unit) {
    private val mood = Array(n) { "wait" }

    fun get(s: Int): String = if (s in mood.indices) mood[s] else "wait"

    fun set(s: Int, m: String, ms: Long = 0) {
        if (s !in mood.indices) return
        mood[s] = m
        refresh(s)
        if (ms > 0) {
            ui.postDelayed({
                if (mood[s] == m) {
                    mood[s] = "wait"
                    refresh(s)
                }
            }, ms)
        }
    }

    fun reset() {
        for (i in mood.indices) mood[i] = "wait"
    }
}
