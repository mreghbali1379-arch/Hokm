package com.example.hokm

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.CheckBox
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import com.example.hokm.engine.Bot4
import com.example.hokm.engine.Card
import com.example.hokm.engine.CardText
import com.example.hokm.engine.Entry
import com.example.hokm.engine.Game4
import com.example.hokm.engine.HakemDraw
import com.example.hokm.engine.HandResult
import com.example.hokm.engine.Phase
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

/**
 * Four-player Hokm against three robots, built from ordinary Android views.
 * Seat 0 = you, 1 = right opponent, 2 = your partner, 3 = left opponent.
 * All game state is changed on the main thread only; the robots think on a background thread while the
 * screen waits (the hand buttons are disabled then).
 */
class SoloGameActivity : Activity() {

    private val g = Game4()
    private val bot = Bot4(g)
    private val ui = Handler(Looper.getMainLooper())
    private val pool: ExecutorService = Executors.newSingleThreadExecutor()
    private var gen = 0
    private var busy = true
    private var over = false

    private lateinit var scoreView: TextView
    private lateinit var msgView: TextView
    private lateinit var tableViews: Array<TextView>
    private lateinit var handGrid: GridLayout
    private lateinit var pickRow: LinearLayout
    private lateinit var newGameBtn: Button
    private lateinit var skipBtn: Button
    private lateinit var snd: Sound
    private lateinit var log: GameLog
    private lateinit var board: AvatarBoard
    private var lastHand = 0
    private lateinit var narrator: DrawNarrator

    /** Cards shown on the table (the current trick, or the finished trick for a moment). */
    private var shown: List<Entry> = emptyList()
    private var shownWinner = -1

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private var rootView: View? = null
    private var seatNames = arrayOf("شما", "حریف ۱", "یار", "حریف ۲")
    private var robotNames: List<String> = listOf("حریف ۱", "یار", "حریف ۲")

    private fun who(seat: Int): String = seatNames[seat]

    /** [raw] = the names of seats 1, 2 (your partner) and 3. */
    private fun setSeatNames(raw: List<String>) {
        robotNames = raw
        seatNames = arrayOf("شما", raw[0], raw[1] + " (یار)", raw[2])
    }

    private fun handText(): String = g.hands[0].joinToString("، ") { CardText.cardName(it) }

    // ------------------------------------------------------------------ screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        snd = Sound.get(this)
        log = GameLog(this)
        board = AvatarBoard(ui, 4) { s -> avatarFor(s, true) }
        narrator = DrawNarrator(ui, snd)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(12))
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL

        scoreView = label(16f, true)
        col.addView(scoreView, matchWrap())

        msgView = label(18f, false)
        SettingsUi.applyA11y(this, msgView)
        msgView.setBackgroundColor(0x33000000)
        msgView.setPadding(dp(8), dp(8), dp(8), dp(8))
        col.addView(msgView, matchWrap().also { it.topMargin = dp(8) })

        val table = LinearLayout(this)
        table.orientation = LinearLayout.VERTICAL
        table.setPadding(dp(8), dp(8), dp(8), dp(8))
        table.setBackgroundColor(0x22FFFFFF)
        tableViews = Array(4) { label(17f, false) }
        for (s in 0 until 4) table.addView(tableViews[s], matchWrap())
        col.addView(table, matchWrap().also { it.topMargin = dp(8) })

        pickRow = LinearLayout(this)
        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.visibility = View.GONE
        for (t in 0 until 4) {
            val b = Button(this)
            b.isAllCaps = false
            b.text = CardText.SUIT_NAMES[t] + " " + CardText.SUIT_SYMBOLS[t]
            b.contentDescription = "حکم " + CardText.SUIT_NAMES[t]
            b.setTextColor(if (t == 1 || t == 2) Color.RED else Color.BLACK)
            b.setOnClickListener { pickTrump(t) }
            pickRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(pickRow, matchWrap().also { it.topMargin = dp(8) })

        handGrid = GridLayout(this)
        handGrid.columnCount = 5
        col.addView(handGrid, matchWrap().also { it.topMargin = dp(8) })

        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(tool("دست قبل") { readLastTrick() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("وضعیت") { readStatus() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("گزینه‌ها") { showOptions() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tools.addView(tool("منو") { finish() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(tools, matchWrap().also { it.topMargin = dp(12) })
        col.addView(tool("کارت‌های بازی‌شده در این دست") { readTable() }, matchWrap().also { it.topMargin = dp(4) })

        skipBtn = tool("رد کردن پخش کارت‌ها") {
            snd.skipDeal()
            narrator.skip()
        }
        skipBtn.visibility = View.GONE
        col.addView(skipBtn, matchWrap().also { it.topMargin = dp(8) })

        newGameBtn = tool("بازی جدید") { startMatch() }
        newGameBtn.visibility = View.GONE
        col.addView(newGameBtn, matchWrap().also { it.topMargin = dp(8) })

        col.addView(log.view, matchWrap().also { it.topMargin = dp(16) })

        val sv = ScrollView(this)
        sv.background = CardArt.background(this)
        rootView = sv
        sv.addView(col)
        setContentView(sv)

        if (intent.getBooleanExtra("resume", false) && SaveStore.load(this, g)) resumeSaved() else startMatch()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun label(size: Float, bold: Boolean): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(Color.WHITE)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun tool(text: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { action() }
        return b
    }

    override fun onDestroy() {
        super.onDestroy()
        gen++
        ui.removeCallbacksAndMessages(null)
        pool.shutdownNow()
        snd.release()
    }

    // ------------------------------------------------------------------ drawing

    private fun say(t: String) {
        msgView.text = t
        log.add(t)
    }

    private fun renderScore() {
        val trumpText = if (g.phase == Phase.PLAY || g.phase == Phase.END) {
            if (g.trump in 0..3) CardText.SUIT_NAMES[g.trump] + " " + CardText.SUIT_SYMBOLS[g.trump] else "—"
        } else "—"
        scoreView.text = "امتیاز: شما " + CardText.fa(g.sc[0]) + "، حریف " + CardText.fa(g.sc[1]) +
            " | دست‌ها: شما " + CardText.fa(g.tk[0]) + "، حریف " + CardText.fa(g.tk[1]) +
            " | حکم: " + trumpText
    }

    private fun femaleOf(s: Int): Boolean =
        if (s == 0) Prefs.gender(this) == "f" else BotNames.isFemale(Avatars.clean(who(s)))

    private fun avatarFor(s: Int, pop: Boolean) {
        if (!::tableViews.isInitialized) return
        Avatars.apply(tableViews[s], Avatars.clean(who(s)), femaleOf(s), board.get(s))
        if (pop) Anim.pop(tableViews[s])
    }

    private fun endMoods(team: Int) {
        for (s in 0 until 4) board.set(s, if (s % 2 == team) "joy" else "sad", 3500)
    }

    private fun renderTable() {
        for (s in 0 until 4) {
            val e = shown.firstOrNull { it.seat == s }
            var t = who(s) + ": " + (if (e != null) CardText.cardName(e.c) else "—")
            if (e != null && s == shownWinner) t += " (برنده)"
            val before = tableViews[s].text.toString()
            tableViews[s].text = t
            CardArt.mark(tableViews[s], e?.c)
            avatarFor(s, false)
            if (e != null && before.endsWith("—")) Anim.pop(tableViews[s])
        }
    }

    private fun renderHand(myTurn: Boolean) {
        handGrid.removeAllViews()
        val legal: List<Card> = if (myTurn) g.legal(0) else emptyList()
        val w = CardArt.cardWidth(this, 5)
        for (c in g.hands[0]) {
            handGrid.addView(CardArt.cardButton(this, c, w, myTurn && legal.contains(c), false) { onCardTapped(c) })
        }
        if (g.hands[0].size - lastHand >= 3) Anim.dealIn(handGrid)
        lastHand = g.hands[0].size
    }

    private fun renderAll(myTurn: Boolean) {
        renderScore()
        renderTable()
        renderHand(myTurn)
    }

    // ------------------------------------------------------------------ game flow

    private fun startMatch() {
        gen++
        over = false
        newGameBtn.visibility = View.GONE
        SaveStore.clear(this)
        log.clear()
        // the draw: the first ace is the hakem, the next ace of another player is his partner; then the seats
        // are rearranged so that the partner sits opposite the hakem (player o moves to seat d.mv[o])
        val raw = BotNames.pick(3)
        val d = HakemDraw.generate(4)
        val labels = listOf("شما", raw[0], raw[1], raw[2])
        val bySeat = arrayOfNulls<String>(4)
        for (o in 0 until 4) bySeat[d.mv[o]] = labels[o]
        setSeatNames(listOf(bySeat[1] ?: raw[0], bySeat[2] ?: raw[1], bySeat[3] ?: raw[2]))
        SaveStore.saveNames(this, robotNames)
        g.newMatch(d.mv[d.h])
        shown = emptyList()
        shownWinner = -1
        busy = true
        skipBtn.visibility = View.VISIBLE
        val my = gen
        narrator.run(d, labels, !snd.willDeal(), { say(it) }) {
            skipBtn.visibility = View.GONE
            if (my == gen) {
                board.set(d.mv[d.h], "joy", 3500)
                if (d.pt >= 0) board.set(d.mv[d.pt], "happy", 3500)
                startHand()
            }
        }
    }

    private fun startHand() {
        gen++
        busy = true
        g.newHand()
        shown = emptyList()
        shownWinner = -1
        snd.sfx("shuffle")
        SaveStore.save(this, g)
        renderAll(false)
        say("کارت‌ها پخش می‌شود...")
        dealThen("deal4a") { beginPick() }
    }

    /** Plays a dealing sound (skippable), then runs [then]; at once when dealing sound is off. */
    private fun dealThen(name: String, then: () -> Unit) {
        if (!snd.willDeal()) {
            then()
            return
        }
        skipBtn.visibility = View.VISIBLE
        val my = gen
        snd.deal(name) {
            skipBtn.visibility = View.GONE
            if (my == gen) then()
        }
    }

    /** The hakem has his first five cards and has to name the trump. */
    private fun beginPick() {
        if (g.hakem == 0) {
            say("شما حاکم هستید. پنج کارت اول شما: " + handText() + ". حکم را انتخاب کنید.")
            pickRow.visibility = View.VISIBLE
            busy = false
        } else {
            say(who(g.hakem) + " حاکم است و حکم را انتخاب می‌کند...")
            val my = gen
            val hk = g.hakem
            try {
                pool.execute {
                    val t = try { bot.chooseTrump(hk) } catch (e: Exception) { 0 }
                    ui.post { if (my == gen) trumpChosen(t) }
                }
            } catch (e: Exception) {
                // activity is closing
            }
        }
    }

    private fun resumeSaved() {
        val saved = SaveStore.loadNames(this)
        if (saved != null && saved.size == 3) setSeatNames(saved) else setSeatNames(BotNames.pick(3))
        gen++
        over = false
        newGameBtn.visibility = View.GONE
        shown = ArrayList(g.trick)
        shownWinner = -1
        when (g.phase) {
            Phase.PICK -> {
                renderAll(false)
                beginPick()
            }
            Phase.PLAY -> {
                say("بازی قبلی ادامه پیدا کرد.")
                nextTurn(true)
            }
            Phase.END -> {
                renderAll(false)
                say("بازی قبلی ادامه پیدا کرد. دست بعد شروع می‌شود.")
                val my = gen
                busy = true
                ui.postDelayed({ if (my == gen) startHand() }, 2500)
            }
            else -> startMatch()
        }
    }

    private fun pickTrump(t: Int) {
        if (g.phase != Phase.PICK || g.hakem != 0 || pickRow.visibility != View.VISIBLE) return
        pickRow.visibility = View.GONE
        busy = true
        trumpChosen(t)
    }

    private fun trumpChosen(t: Int) {
        g.setTrump(t)
        SaveStore.save(this, g)
        val by = if (g.hakem == 0) "" else " (انتخاب " + who(g.hakem) + ")"
        renderAll(false)
        say("حکم: " + CardText.SUIT_NAMES[t] + by + ". کارت‌های شما: " + handText() + ".")
        dealThen("deal4b") { nextTurn(true) }
    }

    private fun nextTurn(afterTrump: Boolean = false) {
        if (g.phase != Phase.PLAY) return
        if (g.turn == 0) {
            busy = false
            renderAll(true)
            val prefix = if (afterTrump) msgView.text.toString() + " " else ""
            say(prefix + "نوبت شماست. " +
                (if (g.trick.isEmpty()) "شما شروع می‌کنید." else "خال زمین: " + CardText.SUIT_NAMES[g.trick[0].c.s] + "."))
            for (i in 0 until handGrid.childCount) {
                val v = handGrid.getChildAt(i)
                if (v.isEnabled) {
                    v.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED)
                    break
                }
            }
            return
        }
        busy = true
        renderAll(false)
        val my = gen
        val s = g.turn
        ui.postDelayed({
            if (my != gen) return@postDelayed
            try {
                pool.execute {
                    val c = bot.pick(s)
                    ui.post { if (my == gen && g.phase == Phase.PLAY && g.turn == s) doPlay(s, c) }
                }
            } catch (e: Exception) {
                // activity is closing
            }
        }, 700)
    }

    private fun onCardTapped(c: Card) {
        if (busy || g.phase != Phase.PLAY || g.turn != 0) return
        if (!g.legal(0).contains(c)) return
        busy = true
        doPlay(0, c)
    }

    private fun doPlay(seat: Int, c: Card) {
        val hkTeam = g.hakem % 2
        if (g.trick.isEmpty()) {
            shown = emptyList()
            shownWinner = -1
        }
        val res = g.play(seat, c)
        snd.card()
        SaveStore.save(this, g)
        val played = who(seat) + " " + CardText.cardName(c) + (if (seat == 0) " بازی کردید" else " بازی کرد") +
            (if (c.s == g.trump) " (حکم)." else ".")
        if (!res.trickDone) {
            shown = ArrayList(g.trick)
            renderAll(false)
            say(played)
            nextTurn()
            return
        }
        val w = res.winner
        snd.sfx(if (w % 2 == 0) "trick" else "tlose")
        board.set(w, "happy", 1800)
        shown = g.lastTrick
        shownWinner = w
        val won = if (w == 0) "شما دست را بردید." else who(w) + " دست را برد."
        val trickMsg = played + " " + won + " دست‌ها: شما " + CardText.fa(g.tk[0]) + "، حریف " + CardText.fa(g.tk[1]) + "."
        renderAll(false)
        val hand = res.hand
        if (hand != null) {
            say(trickMsg + " " + handMessage(hand, hkTeam))
            endSounds(hand)
            endMoods(hand.team)
            val my = gen
            if (hand.gameOver) {
                over = true
                SaveStore.clear(this)
                newGameBtn.visibility = View.VISIBLE
            } else {
                ui.postDelayed({ if (my == gen) startHand() }, 4000)
            }
            return
        }
        say(trickMsg)
        val my = gen
        ui.postDelayed({
            if (my != gen) return@postDelayed
            shown = emptyList()
            shownWinner = -1
            nextTurn()
        }, 1500)
    }

    private fun handMessage(h: HandResult, hk: Int): String {
        val t = h.team
        val bn = if (t == hk) "بام" else "پر بام"
        if (h.bam) {
            return if (t == 0) "تیم شما $bn کرد و بازی را برد!" else "تیم حریف $bn کرد و بازی را برد."
        }
        if (h.gameOver) {
            return if (t == 0) "تیم شما بازی را برد!" else "تیم حریف بازی را برد."
        }
        val who = if (t == 0) "تیم شما" else "تیم حریف"
        val extra = if (h.kot) {
            if (t == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)"
        } else " (۱ امتیاز)"
        return "$who این دست را برد$extra."
    }

    private fun endSounds(h: HandResult) {
        val mine = h.team == 0
        if (h.kot) snd.sfx(if (mine) "kwin" else "klose")
        if (h.gameOver) snd.sfx(if (mine) "fwin" else "flose")
        if (!h.kot && !h.gameOver) snd.sfx(if (mine) "win" else "lose")
    }

    private fun showSoundDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(12), dp(20), dp(4))

        val on = CheckBox(this)
        on.text = "صدا و موسیقی"
        on.isChecked = snd.on
        on.setOnCheckedChangeListener { _, b -> snd.setOn(b) }
        box.addView(on)

        fun slider(title: String, value: Float, change: (Float) -> Unit) {
            val t = TextView(this)
            t.text = title
            t.setPadding(0, dp(12), 0, 0)
            box.addView(t)
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = Math.round(value * 100)
            sb.contentDescription = title
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) change(p / 100f)
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
            box.addView(sb)
        }
        slider("صدای آهنگ", snd.volMusic) { snd.setMusicVolume(it) }
        slider("صدای افکت‌ها", snd.volFx) { snd.setFxVolume(it) }
        snd.addDealSpeedControl(this, box)

        AlertDialog.Builder(this)
            .setTitle("صدا")
            .setView(box)
            .setPositiveButton("بستن", null)
            .show()
    }

    // ------------------------------------------------------------------ options, save, look

    private fun applyLook() {
        rootView?.background = CardArt.background(this)
        SettingsUi.applyA11y(this, msgView)
    }

    private fun showOptions() {
        SettingsUi.list(
            this, "گزینه‌های بیشتر",
            listOf(
                "بازی جدید" to { SettingsUi.confirm(this, "بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.") { startMatch() } },
                "تغییر نام" to { SettingsUi.nameDialog(this, true) {} },
                "ذخیره" to { saveSlot() },
                SettingsUi.a11yLabel(this) to { SettingsUi.a11yToggle(this) { applyLook() } },
                "سرعت انیمیشن" to { SettingsUi.animDialog(this) },
                "سرعت پخش کارت‌ها" to { SettingsUi.speedDialog(this, snd) },
                "تنظیمات صدا" to { SettingsUi.soundDialog(this, snd) },
                "تنظیمات تصویر زمینه" to { SettingsUi.bgDialog(this) { applyLook() } },
                "تنظیمات پشت کارت" to { SettingsUi.backDialog(this) { renderAll(!busy && g.phase == Phase.PLAY && g.turn == 0) } },
                "خروج" to { finish() }
            ),
            "بستن"
        )
    }

    /** Saves the game as a named entry of "بازی‌های قبلی". */
    private fun saveSlot() {
        if (g.phase == Phase.IDLE) {
            SettingsUi.toast(this, "هنوز بازی شروع نشده است.")
            return
        }
        val data = JSONObject().put("g", SaveStore.toJson(g)).put("n", JSONArray(robotNames)).toString()
        Slots.add(this, "4", "بازی چهارنفره با ربات، امتیاز " + CardText.fa(g.sc[0]) + " به " + CardText.fa(g.sc[1]), data)
        SettingsUi.toast(this, "بازی ذخیره شد.")
    }

    // ------------------------------------------------------------------ reading aids

    /** The cards on the table now (or of the trick that just ended). */
    private fun readTable() {
        val dt = if (g.trick.isNotEmpty()) g.trick else shown
        say(
            if (dt.isNotEmpty()) "روی زمین: " + dt.joinToString("، ") { who(it.seat) + " " + CardText.cardName(it.c) } + "."
            else "روی زمین کارتی نیست."
        )
    }

    private fun readLastTrick() {
        if (g.lastTrick.isEmpty()) {
            say("هنوز دستی بازی نشده.")
            return
        }
        say("دست قبل: " + g.lastTrick.joinToString("، ") { who(it.seat) + " " + CardText.cardName(it.c) } +
            ". برنده: " + who(g.winSeat) + ".")
    }

    private fun readStatus() {
        val sb = StringBuilder()
        if (g.phase == Phase.PLAY || g.phase == Phase.END) {
            if (g.trump in 0..3) sb.append("حکم: ").append(CardText.SUIT_NAMES[g.trump]).append(". ")
        }
        sb.append("امتیاز: شما ").append(CardText.fa(g.sc[0])).append("، حریف ").append(CardText.fa(g.sc[1])).append(". ")
        sb.append("دست‌ها: شما ").append(CardText.fa(g.tk[0])).append("، حریف ").append(CardText.fa(g.tk[1])).append(". ")
        if (g.trick.isNotEmpty()) {
            sb.append("روی میز: ")
                .append(g.trick.joinToString("، ") { who(it.seat) + " " + CardText.cardName(it.c) }).append(". ")
        }
        if (g.hands[0].isNotEmpty()) sb.append("کارت‌های شما: ").append(handText()).append(".")
        say(sb.toString())
    }

    override fun onBackPressed() {
        finish()
    }
}
