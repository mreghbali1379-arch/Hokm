package com.example.hokm.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class EngineTest {

    @Test
    fun scoringRules() {
        // team 0 has 7, team 1 has 3, nobody had a kot: 1 point (hakem is team 0 or 1, no difference)
        assertEquals(1, Scoring.points(intArrayOf(7, 3, -1), 0, 0))
        assertEquals(-1, Scoring.points(intArrayOf(7, 3, -1), 1, 0))
        // kot: hakem's team 2 points, against the hakem 3 points
        assertEquals(2, Scoring.points(intArrayOf(7, 1, 0), 0, 0))
        assertEquals(3, Scoring.points(intArrayOf(7, 1, 0), 0, 1))
        // 13-0 is a bam: 7 points
        assertEquals(Scoring.BAM, Scoring.points(intArrayOf(13, 0, 0), 0, 0))
        // undecided
        assertEquals(Scoring.NONE, Scoring.points(intArrayOf(5, 4, -1), 0, 0))
        assertEquals(Scoring.NONE, Scoring.points(intArrayOf(8, 0, 0), 0, 0))
    }

    @Test
    fun matchValuesAreSane() {
        val rv = ResultValues(true)
        rv.set(0, intArrayOf(0, 0))
        // winning more points is never worse than winning fewer
        for (p in 0 until 7) assertTrue(rv.lv[p + 8] >= rv.lv[p + 7])
        // at 6-6 one point decides the match
        rv.set(0, intArrayOf(6, 6))
        assertTrue(rv.lv[1 + 7] > 0.99)
        assertTrue(rv.lv[-1 + 7] < 0.01)
    }

    @Test
    fun fourPlayerDeal() {
        val g = Game4(2)
        g.newHand()
        for (i in 0..3) assertEquals(5, g.hands[i].size)
        assertEquals(32, g.deck.size)
        g.setTrump(1)
        for (i in 0..3) assertEquals(13, g.hands[i].size)
        assertEquals(2, g.turn)
        val all = HashSet<Card>()
        for (h in g.hands) all.addAll(h)
        assertEquals(52, all.size)
    }

    @Test
    fun fourPlayerMustFollowSuit() {
        val g = Game4(0)
        g.newHand()
        g.setTrump(0)
        val lead = g.hands[g.turn][0]
        val s0 = g.turn
        g.play(s0, lead)
        val s1 = g.turn
        val legal = g.legal(s1)
        if (g.hands[s1].any { it.s == lead.s }) assertTrue(legal.all { it.s == lead.s })
    }

    @Test
    fun fourBotsPlayAFullHand() {
        val g = Game4(1)
        val bot = Bot4(g).apply {
            trumpMs = 5
            botMs = 5
            minN = 4
        }
        g.newHand()
        g.setTrump(bot.chooseTrump(1))
        var result: HandResult? = null
        var moves = 0
        while (result == null) {
            val s = g.turn
            val c = bot.pick(s)
            assertTrue(g.legal(s).contains(c))
            result = g.play(s, c).hand
            moves++
            assertTrue(moves <= 52)
        }
        assertTrue(moves >= 32)
        assertTrue(g.sc[result.team] >= 1)
        assertEquals(Phase.END, g.phase)
    }

    @Test
    fun twoPlayerFullRoundWithBot() {
        val g = Game2()
        val bot = Bot2(g).apply { bot2Ms = 5 }
        g.newMatch(1)
        g.startRound()
        assertEquals(5, g.hands[0].size)
        assertEquals(5, g.hands[1].size)
        assertEquals(40, g.deck.size)
        // the opponent is hakem: it names the trump and keeps three cards
        val ch = bot.choose2Hakem(g.hands[1], 1)
        g.trump = ch.trump
        g.botKeep(ch.keep)
        g.humanDiscard(g.hands[0].take(2))
        assertEquals(3, g.hands[0].size)
        assertEquals(3, g.hands[1].size)
        g.beginDraw()
        while (g.nextPair()) {
            val face = if (g.ch == 1) bot.drawFace() else Random.nextBoolean()
            g.take(g.ch, face)
        }
        assertEquals(13, g.hands[0].size)
        assertEquals(13, g.hands[1].size)
        assertEquals(0, g.deck.size)
        g.startPlay()
        var result: Result2? = null
        var moves = 0
        while (result == null) {
            val p = g.turn
            val c = if (p == 1) bot.pickCard() else g.legal(0).random()
            assertTrue(g.legal(p).contains(c))
            result = g.play(p, c).hand
            moves++
            assertTrue(moves <= 26)
        }
        assertNotNull(result)
        assertTrue(g.sc[result.team] >= 1)
    }
}
