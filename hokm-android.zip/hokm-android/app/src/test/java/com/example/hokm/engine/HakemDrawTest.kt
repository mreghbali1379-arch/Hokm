package com.example.hokm.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class HakemDrawTest {
    @Test
    fun fourPlayerDrawGivesPartnerOppositeAfterReseat() {
        val rnd = Random(5)
        repeat(300) {
            val d = HakemDraw.generate(4, rnd)
            assertEquals(14, d.seq[d.i1].c.r)
            assertEquals(14, d.seq[d.i2].c.r)
            assertEquals(d.h, d.seq[d.i1].p)
            assertEquals(d.pt, d.seq[d.i2].p)
            assertTrue(d.h != d.pt)
            assertEquals(d.seq.size - 1, d.i2)
            // player 0 never moves; the partner sits opposite the hakem
            assertEquals(0, d.mv[0])
            assertEquals((d.mv[d.h] + 2) % 4, d.mv[d.pt])
            assertEquals(setOf(0, 1, 2, 3), d.mv.toSet())
            // no ace before the first ace
            for (i in 0 until d.i1) assertTrue(d.seq[i].c.r != 14)
        }
    }

    @Test
    fun twoPlayerDrawEndsAtFirstAce() {
        val rnd = Random(9)
        repeat(200) {
            val d = HakemDraw.generate(2, rnd)
            assertEquals(d.seq.size - 1, d.i1)
            assertEquals(14, d.seq.last().c.r)
            assertEquals(d.h, d.seq.last().p)
            for (i in 0 until d.i1) assertTrue(d.seq[i].c.r != 14)
        }
    }
}
