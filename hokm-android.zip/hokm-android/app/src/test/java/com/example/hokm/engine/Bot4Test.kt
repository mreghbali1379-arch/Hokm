package com.example.hokm.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class Bot4Test {
    @Test
    fun botsPlayWholeMatch() {
        val g = Game4(0)
        val bot = Bot4(g, Random(11)).apply {
            trumpMs = 0
            fixN = 3
            exNodes = 2000
        }
        g.newMatch(0)
        var hands = 0
        while (g.sc[0] < 7 && g.sc[1] < 7) {
            assertTrue(hands++ < 60)
            g.newHand()
            val t = bot.chooseTrump(g.hakem)
            assertTrue(t in 0..3)
            g.setTrump(t)
            var plays = 0
            while (g.phase == Phase.PLAY) {
                val s = g.turn
                val c = bot.pick(s)
                assertTrue(g.legal(s).contains(c))
                g.play(s, c)
                plays++
            }
            assertEquals(Phase.END, g.phase)
            assertEquals(4 * (g.tk[0] + g.tk[1]), plays)
            assertTrue(g.tk[0] >= 7 || g.tk[1] >= 7)
        }
        assertTrue(g.sc[0] >= 7 || g.sc[1] >= 7)
    }
}
