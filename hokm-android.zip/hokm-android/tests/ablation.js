// کدام تغییر واقعاً تصمیم ربات را عوض می‌کند؟ هر ویژگی خاموش می‌شود و درصد تصمیم‌های متفاوت روی وضعیت‌های یکسان (با بذر ثابت) شمرده می‌شود.
// همچنین یک آزمون قطعی برای باگ هم‌ارزی قدیمی. استفاده: node tests/ablation.js [--positions 150]
const path=require('path'),vm=require('vm');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const P=+arg('positions',150),html=path.join(__dirname,'../legacy-webview/index.html'),base=path.join(__dirname,'baseline/index_before.html');
const rnd=n=>Math.floor(Math.random()*n);
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
function seeded(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const realR=Math.random,pick=(f,seed)=>{Math.random=seeded(seed);try{return f()}finally{Math.random=realR}};
const {load}=require('./lib/ctx4');
// ---- ۱) باگ هم‌ارزی: حریف شاه پیک آورده، ما آس و بی‌بی پیک داریم و آخرین بازیکنیم ----
function bugCase(ctx,seat2){ // seat2: ما دومین بازیکن دستیم؛ وگرنه آخرین
  const H=[[{s:0,r:14},{s:0,r:12},{s:1,r:3},{s:1,r:4}],[{s:1,r:5},{s:3,r:6},{s:3,r:7},{s:2,r:6}],[{s:2,r:5},{s:3,r:8},{s:3,r:9},{s:2,r:7}],[{s:3,r:5},{s:2,r:8},{s:2,r:9},{s:3,r:10}]];
  const trick=seat2?[{seat:3,c:{s:0,r:13}}]:[{seat:1,c:{s:0,r:13}},{seat:2,c:{s:0,r:3}},{seat:3,c:{s:0,r:4}}];
  const seen=seat2?[13]:[13,3,4];
  ctx.__set({H,trump:2,hakem:1,trick,tk:[2,2],kt:null,seen,voids:[[],[],[],[]],plays:[],sc:[0,0]});
  let ace=0;for(let i=0;i<20;i++){const m=pick(()=>ctx.__move(0),i+1);if(m&&m.r===14)ace++}return ace;
}
const o=load(base),n=load(html);
console.log(`باگ هم‌ارزی (آس‌گرفتنِ شاه حریف، ۲۰ بار) نفر دوم دست: قدیمی ${bugCase(o,true)}/20 بار آس زد، جدید ${bugCase(n,true)}/20 | نفر آخر: قدیمی ${bugCase(o,false)}/20، جدید ${bugCase(n,false)}/20`);
// ---- ۲) تفاوت تصمیم هر ویژگی ----
const ctx=load(html);vm.runInContext('FIX_N=40;',ctx);
const feats=['USE_LR','USE_MW','USE_BIAS'],diff={USE_LR:0,USE_MW:0,USE_BIAS:0},tot={USE_LR:0,USE_MW:0,USE_BIAS:0};
let n0=0;
while(n0<P){
  const d=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)d.push({s,r});shuffle(d);
  const H=[0,1,2,3].map(i=>d.slice(i*13,i*13+13)),tr=rnd(4),hk=rnd(4);
  let trick=[],tk=[0,0],kt=null,seen=[],voids=[[],[],[],[]],plays=[],turn=hk,k=0,got=false;
  const beats=(c,b)=>c.s===b.s?c.r>b.r:c.s===tr,bestOf=t=>{let b=t[0];for(const x of t)if(beats(x.c,b.c))b=x;return b},target=rnd(36)+6;
  while(true){
    const hand=H[turn],led=trick.length?trick[0].c.s:-1;let L=hand;if(led>=0){const f=hand.filter(c=>c.s===led);if(f.length)L=f}
    if(k>=target&&L.length>1){
      const st={H,trump:tr,hakem:hk,trick,tk,kt,seen,voids,plays,sc:[rnd(6),rnd(6)]};
      ctx.__set(st);const a=pick(()=>ctx.__move(turn),n0+1);
      for(const f of feats){vm.runInContext(f+'=false;',ctx);ctx.__set(st);const b=pick(()=>ctx.__move(turn),n0+1);vm.runInContext(f+'=true;',ctx);
        // USE_BIAS/MW تنها در شرایط خاص اثر دارند؛ همهٔ وضعیت‌ها را می‌شماریم
        tot[f]++;if(!a||!b||a.s!==b.s||a.r!==b.r)diff[f]++}
      n0++;break;
    }
    if(k>=52)break;
    const c=L[rnd(L.length)],bb=trick.length?bestOf(trick):null;
    plays.push({seat:turn,c,len:trick.length,led,bs:bb?bb.seat:-1,bc:bb?bb.c:null});
    if(trick.length&&c.s!==trick[0].c.s)voids[turn].push(trick[0].c.s);
    seen.push(c.s*20+c.r);H[turn]=H[turn].filter(x=>x!==c);trick.push({seat:turn,c});k++;
    if(trick.length<4){turn=(turn+1)%4;continue}
    const w=bestOf(trick).seat;tk[w%2]++;trick=[];turn=w;if(tk[0]>=7||tk[1]>=7)break;
  }
}
const nm={USE_LR:'استنباط انتخاب حکم حاکم (HK_LR)',USE_MW:'ارزش بر پایهٔ شانس بردن کل بازی (setLV/MW)',USE_BIAS:'جریمهٔ الگوهای غلط نفر آخر (bias)'};
for(const f of feats)console.log(`${nm[f]}: ${diff[f]}/${tot[f]} تصمیم (${(100*diff[f]/tot[f]).toFixed(1)}٪) با خاموش‌کردنش فرق کرد`);
// ---- ۳) ۲ نفره: انتخاب حکم/کارت نگه‌داشتنی با شبیه‌سازی در برابر قاعدهٔ قدیمی ----
const {load:l2}=require('./lib/ctx2'),c2=l2(html);vm.runInContext('BOT2_MS=150;',c2);
let dT=0,dK=0,M=60;
for(let t=0;t<M;t++){
  const dk=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)if(!(r===2&&s<2))dk.push({s,r});shuffle(dk);
  const h=dk.slice(0,5).map(c=>({s:c.s,r:c.r}));
  c2.__h=h;const r=vm.runInContext('(function(){const g=new Set([2,22]);const a=choose2Heur(__h),b=mc2Trump(__h,1,g);return [a.T,b.T,a.keep.map(idc).sort().join(),b.keep.map(idc).sort().join()]})()',c2);
  if(r[0]!==r[1])dT++;if(r[2]!==r[3])dK++;
}
console.log(`۲ نفره: شبیه‌سازی حکم/کارت نگه‌داشتنی در ${dT}/${M} دست حکم متفاوت و در ${dK}/${M} دست کارت‌های نگه‌داشتنی متفاوت از قاعدهٔ قدیمی انتخاب کرد`);
