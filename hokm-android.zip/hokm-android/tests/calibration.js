// آزمون کیفیت استنباط: میانگین تعداد خال حکم در دست حاکم، پیش‌بینی ربات (نمونه‌گیری) در برابر واقعیت
// بدون وزن‌دهی استنباطی و با آن. استفاده: node tests/calibration.js [--deals 4000]
const path=require('path'),vm=require('vm');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const D=+arg('deals',4000),html=arg('file',path.join(__dirname,'../legacy-webview/index.html'));
const {load}=require('./lib/ctx4'),ctx=load(html);
const rnd=n=>Math.floor(Math.random()*n);
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=rnd(i+1);[a[i],a[j]]=[a[j],a[i]]}return a};
let truth=0,predU=0,predW=0,maeU=0,maeW=0;
for(let t=0;t<D;t++){
  const d=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)d.push({s,r});shuffle(d);
  const H=[0,1,2,3].map(i=>d.slice(i*13,i*13+13)),first5=H[0].slice(0,5);
  let bT=0,bv=-1;for(let s=0;s<4;s++){let v=0;for(const c of first5)if(c.s===s)v+=3+c.r/6;if(v>bv+1e-9||(Math.abs(v-bv)<1e-9&&rnd(2))){bv=v;bT=s}}
  const k=H[0].filter(c=>c.s===bT).length;
  ctx.__set({H,trump:bT,hakem:0,trick:[],tk:[0,0],kt:null,seen:[],voids:[[],[],[],[]],plays:[],sc:[0,0]});
  const r=vm.runInContext(`(function(){const s=1,others=[0,2,3],un=[];for(let x=0;x<4;x++)for(let r=2;r<=14;r++)if(!H[s].some(c=>c.s===x&&c.r===r))un.push({s:x,r});
   let su=0,sw=0,sk=0;for(let i=0;i<60;i++){const hs=sampleWorld(s,un,others,true);const c=hs[0].reduce((a,y)=>a+(y.s===trump?1:0),0);su+=c;const w=HK_LR[Math.min(13,c)];sw+=w;sk+=w*c}return [su/60,sk/sw]})()`,ctx);
  truth+=k;predU+=r[0];predW+=r[1];maeU+=Math.abs(r[0]-k);maeW+=Math.abs(r[1]-k);
}
const f=x=>(x/D).toFixed(2);
console.log(`میانگین واقعی تعداد حکم در دست حاکم: ${f(truth)}\nپیش‌بینی ربات بدون استنباط: ${f(predU)} (خطای مطلق ${f(maeU)})\nپیش‌بینی ربات با استنباط انتخاب حکم: ${f(predW)} (خطای مطلق ${f(maeW)})`);
