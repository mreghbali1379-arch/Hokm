// استفاده: node tests/run2.js --a <index جدید> --b <index قدیم | random | heur> --deals 100 [--ms 450]
// --only play : فقط بازی (حکم و برداشتن برای هر دو طرف قدیمی)، --only setup : فقط انتخاب حکم/برداشتن جدید و بازی قدیمی
const path=require('path'),vm=require('vm');
const {load,rival}=require('./lib/ctx2'),{mkDeal,deal,playRound,newStats,rnd}=require('./lib/arena2');
const arg=(k,d)=>{const i=process.argv.indexOf('--'+k);return i>0?process.argv[i+1]:d};
const root=path.join(__dirname,'..');
const A=arg('a',path.join(root,'legacy-webview/index.html')),Bs=arg('b',path.join(__dirname,'baseline/index_before.html'));
const N=+arg('deals',50),MS=arg('ms',null);
const ca=load(A);if(MS)vm.runInContext('BOT2_MS='+MS,ca);
let cb;if(Bs==='random'||Bs==='heur')cb=rival(ca,Bs);else cb=load(Bs);
ca.side=0;cb.side=1;
const st=newStats();let win=0,tot=0,pts=0;const t0=Date.now();
for(let d=0;d<N;d++){
  const D=mkDeal();
  for(const par of [0,1]){ // A روی صندلی par
    const bots=[par===0?ca:cb,par===1?ca:cb];
    const dl=deal(bots,D,st);
    const r=playRound(bots,dl,st);const aw=r.t===par;win+=aw;tot++;pts+=aw?r.pts:-r.pts;
  }
  if((d+1)%10===0)console.error('..',d+1,'/',N,((Date.now()-t0)/1000|0)+'s');
}
const q=(a,p)=>{if(!a.length)return 0;const s=a.slice().sort((x,y)=>x-y);return s[Math.min(s.length-1,Math.floor(p*s.length))]};
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const p=win/tot;
const tm=i=>({playMean:+avg(st.ms[i]).toFixed(0),playP95:+q(st.ms[i],.95).toFixed(0),playMax:+q(st.ms[i],1).toFixed(0),setupMax:+q(st.setupMs[i],1).toFixed(0)});
console.log(JSON.stringify({A:path.basename(A),B:Bs,rounds:tot,A_roundWinPct:+(100*p).toFixed(1),ci95:+(196*Math.sqrt(p*(1-p)/tot)).toFixed(1),A_avgPointsPerRound:+(pts/tot).toFixed(3),
 timeMs:{A:tm(0),B:tm(1)},illegalMoves:st.illegal,exceptions:st.exc,missedWinPer1000:{A:st.dec[0]?+(1000*st.err[0].missedWin/st.dec[0]).toFixed(1):0,B:st.dec[1]?+(1000*st.err[1].missedWin/st.dec[1]).toFixed(1):0}},null,1));
